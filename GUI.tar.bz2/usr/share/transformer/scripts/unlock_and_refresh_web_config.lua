#!/usr/bin/lua
local a=require("uci"):cursor()local d
local e,e
local function l(e,a)local t
if not a then
return nil
end
for t,a in ipairs(a)do
if a==e then
return true
end
end
d=true
return nil
end
local t={}a:foreach('web','ruleset',function(a)if a['.name']=='ruleset_main'then
for e,a in pairs(a.rules)do
t[#t+1]=a
end
end
end)local e={{name='error',target='/error.lua'},{name='applicationsmodal',target='/modals/applications-modal.lp'},{name='diagnosticsxdslgraphicsmodal',target='/modals/diagnostics-xdsl-graphics-modal.lp'},{name='mwanmodal',target='/modals/mwan-modal.lp'},{name='fastcacheoptionmodal',target='/modals/fast-cache-option-modal.lp'},{name='dosprotectmodal',target='/modals/dosprotect-modal.lp'},{name='mmpbxdectmodal',target='/modals/mmpbx-dect-modal.lp'},{name='modemstatsmodal',target='/modals/modem-stats-modal.lp'},{name='upnpmodal',target='/modals/upnp-modal.lp'},{name='dmzmodal',target='/modals/dmz-modal.lp'},{name='wolsmodal',target='/modals/wol-modal.lp'},{name='custodnssmodal',target='/modals/custodns-modal.lp'},{name='dyndnssmodal',target='/modals/dyndns-modal.lp'},{name='speedservicemodal',target='/modals/speedservice-modal.lp'},{name='toddndmodal',target='/modals/tod_dnd-modal.lp'},{name='nfcmodal',target='/modals/nfc-modal.lp'},{name='stats',target='/stats.lp'},{name='cards',target='/cards.lp'},{name='ajaxinfotrafficcard',target='/ajax/traffic_graph.lua'},{name='ecomodal',target='/modals/eco-modal.lp'},{name='modguimodal',target='/modals/modgui-modal.lp'},{name='ajaxgatewaytab',target='/ajax/cpuload.lua'},{name='ajaxinternet',target='/ajax/internet.lua'},{name='ajaxinfoconndevicecard',target='/ajax/connected_device.lua'},{name='ajaxinfoportscard',target='/ajax/port_status.lua'},{name='ajaxinfommpbxstatuscard',target='/ajax/mmpbx_status.lua'},{name='ajaxcommandlogread',target='/ajax/commandlogread.lua'},{name='commandlogreadmodal',target='/modals/command-log-read-modal.lp'},{name='ajaxgetcard',target='/ajax/get_card.lua'},{name='diagnosticsledsmodal',target='/modals/diagnostics-leds-modal.lp'},{name='systeminitmodal',target='/modals/system-init-modal.lp'},{name='systemcronmodal',target='/modals/system-cron-modal.lp'},}local r={{name='telstra_broadband',target='/telstra-modals/broadband.lp'},{name='telstra_contentsharing_refresh',target='/telstra-modals/contentsharing.lp'},{name='telstra_device',target='/telstra-modals/device.lp'},{name='telstra_dyndns',target='/telstra-modals/dyndns.lp'},{name='telstra_home',target='/telstra-gui.lp'},{name='telstra_parental',target='/telstra-modals/parental-modal.lp'},{name='telstra_portforwarding',target='/telstra-modals/portforwarding.lp'},{name='telstra_remoteaccess',target='/telstra-modals/remoteaccess.lp'},{name='telstra_tod',target='/telstra-modals/tod.lp'},{name='telstra_traffic',target='/telstra-modals/traffic.lp'},{name='telstra_user',target='/telstra-modals/user.lp'},{name='telstra_wifi',target='/telstra-modals/wifi.lp'},{name='telstra_wifiguest',target='/telstra-modals/wifiguest.lp'},{name='telstra_helpbroadband',target='/telstra-helpfiles/help_broadband.lp'},{name='telstra_helpcontentsharing',target='/telstra-helpfiles/help_contentsharing.lp'},{name='telstra_helpdyndns',target='/telstra-helpfiles/help_dyndns.lp'},{name='telstra_helphome',target='/telstra-helpfiles/help_home.lp'},{name='telstra_helpportforwarding',target='/telstra-helpfiles/help_portforwarding.lp'},{name='telstra_helpremoteaccess',target='/telstra-helpfiles/help_remoteaccess.lp'},{name='telstra_helpservices',target='/telstra-helpfiles/help_services.lp'},{name='telstra_helptod',target='/telstra-helpfiles/help_tod.lp'},{name='telstra_helptraffic',target='/telstra-helpfiles/help_traffic.lp'},{name='telstra_helpusersetting',target='/telstra-helpfiles/help_usersetting.lp'},{name='telstra_helpwifi',target='/telstra-helpfiles/help_wifi.lp'},}for r,e in pairs(e)do
if not l(e.name,t)then
a:set('web',e.name,'rule')a:set('web',e.name,'target',e.target)a:set('web',e.name,'roles',{'admin','engineer'})t[#t+1]=e.name
end
end
for r,e in pairs(r)do
if not l(e.name,t)then
a:set('web',e.name,'rule')a:set('web',e.name,'target',e.target)a:set('web',e.name,'roles',{'admin','engineer'})t[#t+1]=e.name
end
end
local r={}a:foreach('web','ruleset',function(a)r[#r+1]=a['.name']end)local e={{name='gateway_card',card='001_gateway.lp',modal='gatewaymodal'},{name='modgui_card',card='001_modgui.lp',modal='modguimodal'},{name='boradband_card',card='002_broadband.lp',modal='broadbandmodal'},{name='internet_card',card='003_internet.lp',modal='internetmodal'},{name='wireless_card',card='004_wireless.lp',modal='wirelessmodal'},{name='lan_card',card='005_LAN.lp',modal='ethernetmodal'},{name='devices_card',card='006_Devices.lp',modal='devicemodal'},{name='wanservices_card',card='007_wanservices.lp',modal='wanservices'},{name='firewall_card',card='008_firewall.lp',modal='firewallmodal'},{name='qos_card',card='008_qos.lp',modal='qosqueuemodal'},{name='telephony_card',card='008_telephony.lp',modal='mmpbxglobalmodal'},{name='diagnostics_card',card='009_diagnostics.lp',modal='diagnosticspingmodal'},{name='extensions_card',card='009_extensions.lp',modal='applicationsmodal'},{name='assistance_card',card='010_assistance.lp',modal='assistancemodal'},{name='lte_card',card='010_lte.lp',modal='ltemodal'},{name='usermgr_card',card='011_usermgr.lp',modal='usermgrmodal'},{name='contentsharing_card',card='012_contentsharing.lp',modal='contentsharing'},{name='printersharing_card',card='012_printersharing.lp',modal='printersharing'},{name='parental_card',card='013_parental.lp',modal='parentalmodal'},{name='iproutes_card',card='015_iproutes.lp',modal='iproutesmodal'},{name='tod_card',card='015_tod.lp',modal='todmodal'},{name='nfc_card',card='016_nfc.lp',modal='nfcmodal'},{name='relaysetup_card',card='018_relaysetup.lp',modal='relaymodal'},{name='eco_card',card='020_eco.lp',modal='ecomodal'},{name='cwmpconf_card',card='090_cwmpconf.lp',modal='cwmpconf'},{name='system_card',card='091_system.lp',modal='systemmodal'},{name='natalghelper_card',card='092_natalghelper.lp',modal='natalghelper'},{name='xdsl_card',card='093_xdsl.lp',modal='xdsllowmodal'},}for t,e in pairs(e)do
if not l(e.name,r)then
a:set('web',e.name,'card')a:set('web',e.name,'card',e.card)a:set('web',e.name,'modal',e.modal)a:set('web',e.name,'hide','0')end
end
a:set('web','usr_admin','role','engineer')local e
local function r()local e={}a:foreach('web','user',function(a)e[#e+1]=a.role
end)return e
end
a:foreach('web','rule',function(t)e={}if type(t.roles)=="table"then
for t,a in pairs(t.roles)do
e[#e+1]=a
end
elseif type(t.roles)=="string"then
e[#e+1]=t.roles
end
if not l("engineer",e)then
e[#e+1]="engineer"end
if not l("admin",e)then
e[#e+1]="admin"end
if t['.name']=="ajaxgetcard"then
e=r()end
a:set('web',t['.name'],'roles',e)end)if d then
a:set('web','ruleset_main','rules',t)a:commit('web')end