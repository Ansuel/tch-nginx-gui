local s=require("modgui")local i={{"mmpbxrvsipnet","sip_profile_0","password"},{"mmpbxrvsipnet","sip_profile_1","password"},{"mmpbxrvsipnet","sip_profile_2","password"},{"cwmpd","cwmpd_config","connectionrequest_password"},{"cwmpd","cwmpd_config","acs_pass"},}local o=require("uci").cursor()local e=s.isEncrypted
local r=s.decryptPassword
local p
for i,s in pairs(i)do
p=o:get(s[1],s[2],s[3])if e(p)then
o:set(s[1],s[2],s[3],r(p))o:commit(s[1])end
end