#!/usr/bin/env lua
local e=require("uci")local e=e.cursor()local d=require("ubus").connect()if not d then
error("Failed to connect to ubusd")end
local i={on='1',off='0',['1']="on",['0']="off"}local function r(n,e)if((e~=nil)and type(e)=="table")then
for t,e in ipairs(e)do
if(e==n)then
return true
end
end
end
return false
end
function get_all_profiles(n)e:foreach("mmpbx","service",function(e)if(e.type=="DND")then
local e=e["profile"]if#e>=1 then
for t,e in ipairs(e)do
n[#n+1]=e
end
end
end
end)end
function update_current_state(o,t)d:send("mmpbx.profile.dnd",{profile=o,dnd=t})e:foreach("mmpbx","service",function(n)if(n["type"]=="DND")and((r(o,n["profile"]))==true)then
current_state=e:get("mmpbx",n['.name'],"activated")if(current_state~=nil)and(current_state~=i[t])then
e:set("mmpbx",n['.name'],"activated",i[t])end
end
end)e:commit("mmpbx")end
function update_ringing_schedule()local t=e:get("tod","voicednd","enabled")local o=e:get("tod","global","time_change_monfreq")local i=e:get("tod","voicednd","timerandactionmodified")local n={}if(t==nil)then
return
end
get_all_profiles(n)if(#n<1)then
return
end
if(t=="0")then
if(i=="1")then
os.execute("sleep "..tonumber(o))e:set("tod","voicednd","timerandactionmodified","0")e:commit("tod")e:unload("tod")end
for n,e in pairs(n)do
update_current_state(e,"off")end
elseif(t=="1")then
os.execute("/usr/bin/lua /usr/share/transformer/scripts/voice_tod.lua")end
end
update_ringing_schedule()