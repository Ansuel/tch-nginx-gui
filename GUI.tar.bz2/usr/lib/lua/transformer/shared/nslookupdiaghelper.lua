local t={}local i=io.open
local n=require("transformer.mapper.ucihelper")local r=pairs
local a={}local l={}local o=0
local e={}local function u(e,o,t)n.set_on_uci(e,o,t)a[e.config]=true
end
function t.clear_nslookupdiag_results(e)os.remove("/tmp/nslookupdiag_"..e)end
function t.read_nslookupdiag_results(e)local t={}if o~=0 then return"0"end
local n=i("/tmp/nslookupdiag_"..e)if not n then
return"0"end
local i=tonumber(n:read())local o=0
for e in n:lines()do
local e={e:match("(%S*)%,(%S*)%,(%S*)%,(%S*)%,(%S*)%,(%d*)")}t[o+1]={Status=e[1],AnswerType=e[2],HostNameReturned=e[3],IPAddresses=e[4],DNSServerIP=e[5],ResponseTime=e[6],}o=o+1
end
n:close()return t,i
end
function t.startup(o,t)e[o]=t
local t=i("/etc/config/nslookupdiag")if not t then
t=i("/etc/config/nslookupdiag","w")if not t then
error("could not create /etc/config/nslookupdiag")end
t:write("config user '"..o.."'\n")t:close()n.set_on_uci(e[o]["NumberOfRepetitions"],3)n.set_on_uci(e[o]["Timeout"],5000)else
local t=n.get_from_uci({config="nslookupdiag",sectionname=o})if t==''then
n.set_on_uci({config="nslookupdiag",sectionname=o},"user")n.set_on_uci(e[o]["NumberOfRepetitions"],3)n.set_on_uci(e[o]["Timeout"],5000)end
end
n.set_on_uci(e[o]["DiagnosticsState"],"None")n.commit({config="nslookupdiag"})return o
end
function t.uci_nslookupdiag_get(o,s)local c
local i="nslookupdiag"if e[o]==nil then
e[o]={DiagnosticsState={config=i,sectionname=o,option="state"},Interface={config=i,sectionname=o,option="interface"},HostName={config=i,sectionname=o,option="hostname"},DNSServer={config=i,sectionname=o,option="dnsserver"},NumberOfRepetitions={config=i,sectionname=o,option="repetitions"},Timeout={config=i,sectionname=o,option="timeout"},}end
if e[o][s]then
c=n.get_from_uci(e[o][s])if s=="DiagnosticsState"and c=="InProgress"then
c="Requested"end
else
c=t.read_nslookupdiag_results(o,s)end
return c
end
function t.uci_nslookupdiag_set(o,c,t,i)if c=="DiagnosticsState"then
if(t~="Requested"and t~="None")then
return nil,"invalid value"end
l[o]=true
u(e[o]["DiagnosticsState"],t,i)else
local n=n.get_from_uci(e[o]["DiagnosticsState"])if(n~="Requested"and n~="None")then
u(e[o]["DiagnosticsState"],"None",i)end
u(e[o][c],t,i)end
end
local function e(n)l={}for e,o in r(a)do
local e={config=e}n(e)end
a={}end
local function o()for e,n in r(l)do
t.clear_nslookupdiag_results(e)end
end
function t.uci_nslookupdiag_commit()o()e(n.commit)end
function t.uci_nslookupdiag_revert()e(n.revert)end
return t