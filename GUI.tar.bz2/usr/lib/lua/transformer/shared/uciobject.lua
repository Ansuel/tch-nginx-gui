local n=require'transformer.mapper.ucihelper'local e={}local o={}local function i(n)o[n]=true
end
local function c(e)for n,c in pairs(o)do
e{config=n}end
o={}end
function e.commit()c(n.commit)end
function e.revert()c(n.revert)end
local t={}e.GeneratedKey=t
local function l(e,c,t)local o=0
local a=c.."_(%d+)"n.foreach_on_uci(e,function(n)local n=tonumber(n['.name']:match(a)or"0")if n and(n>o)then
o=n
end
end)local a=e.sectionname
local o=(c.."_%d"):format(o+1)e.sectionname=o
n.set_on_uci(e,a,t)i(e.config)return o
end
function e.create(e,a,i,o,c)local e={config=e,sectionname=a,}local i=l(e,i,c)for i,o in pairs(o or{})do
e.option=i
if o==t then
o=e.sectionname
end
n.set_on_uci(e,o,c)end
return i
end
function e.delete(e,o,c)n.delete_on_uci({config=e,sectionname=o},c)i(e)end
function e.is_dynamic(e,o)local e={config=e,sectionname=o,option="dev2_dynamic"}return n.get_from_uci(e)=="1"end
return e