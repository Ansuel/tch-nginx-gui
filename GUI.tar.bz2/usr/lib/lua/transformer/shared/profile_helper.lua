local c={}local e=io.open
local f,p,b,_=string.format,string.match,string.lower,string.sub
local i=pairs
local s,d=table.sort,table.concat
local n=require("transformer.mapper.ucihelper")local a=require("transformer.shared.servicedefault")local m=a.outgoingmap_order
local r=a.services
local g=a.naming_rule
local u=a.dial_plan_entry_default
local y=a.dial_plan_pattern_generator
local t=n.set_on_uci
local e=n.commit
local e={config="mmpbx"}local x={config="mmpbx",sectionname="service"}local l={config="mmpbxrvsipnet"}local v=a.services.named_service_section
local o={}local function w(a,i,r,l)e.sectionname="incoming_map"e.option=nil
o.config="mmpbx"o.sectionname=nil
local c
n.foreach_on_uci(e,function(e)if e.profile==a then
o.sectionname=e[".name"]c=e["device"]return true
end
end)if not o.sectionname then
if#i==0 then
return false
else
e.sectionname="incoming_map_"..a
t(e,"incoming_map",l)e.option="profile"t(e,a,l)end
elseif#i==0 then
e.option=nil
e.sectionname=o.sectionname
n.delete_on_uci(e,l)r[e.config]=true
return true
elseif type(c)=='table'then
s(c)s(i)if d(c)==d(i)then
return false
end
end
if(o.sectionname~=nil)then
e.sectionname=o.sectionname
end
e.option="device"t(e,i,l)r[e.config]=true
return true
end
local function h(l,o,i,n)e={config="mmpbx"}e.sectionname="outgoing_map_"..o
t(e,"outgoing_map",n)e.option="device"t(e,o,n)e.option="profile"t(e,{l},n)e.option="priority"t(e,{"1"},n)i[e.config]=true
end
local function s(o)local e,n=o:match("(.*)_(%d+)")if not e then
e,n=o,0
end
return m[e],n
end
local function k(r,t,d,a)local c={}for o,n in ipairs(t)do
c[n]=true
end
e.sectionname="outgoing_map"e.option=nil
o.config="mmpbx"n.foreach_on_uci(e,function(t)local e,l
if type(t.priority)=="table"and type(t.profile)=="table"then
e={}l={}local n=0
for i,o in i(t.profile)do
if o==r then
if c[t.device]then
e=nil
l=nil
break
end
else
e[#e+1]=o
l[#l+1]=t["priority"][i]local e=tonumber(t["priority"][i])if e>n then
n=e
end
end
end
if e and#e==#t["profile"]then
if c[t.device]then
e[#e+1]=r
l[#l+1]=tonumber(n+1)else
e=nil
l=nil
end
end
elseif c[t.device]then
e={r}l={"1"}end
if e then
o.sectionname=t[".name"]if#e>0 then
o.option="profile"if m then
table.sort(e,function(e,n)local e,i=s(e)local n,o=s(n)if e and n and(e<n or(e==n)and i<o)then
return true
elseif not e then
return true
end
return false
end)end
n.set_on_uci(o,e,a)o.option="priority"n.set_on_uci(o,l,a)d[o.config]=true
elseif#e==0 then
o.option=nil
n.delete_on_uci(o,a)d[o.config]=true
end
end
if t.device then
c[t.device]=nil
end
end)for e,n in i(c)do
h(r,e,d,a)end
end
function c.port_set(n,o,e,i)local t=w(n,o,e,i)if t then
k(n,o,e,i)end
end
local function m()local e=-1
l.sectionname="profile"n.foreach_on_uci(l,function(n)local n=tonumber(n['.name']:match("(%d+)$"))if(e<n)then
e=n
end
end)return e+1
end
local function s()local o={}l.sectionname="profile"n.foreach_on_uci(l,function(e)local e=e['.name']:match("(%d+)$")o[e]=true
end)local e=0
while o[tostring(e)]do
e=e+1
end
return e
end
local function h(a,d,o)local c={}if r then
c.config="mmpbx"local l={}for o,e in i(r.append or{})do
if not e["servicetype"]or e["servicetype"]=="profile"then
l[o]=e
end
end
n.foreach_on_uci(x,function(e)if l[e["type"]]and not e.device then
local n=e["profile"]or{}n[#n+1]=a
c.sectionname=e[".name"]c.option="profile"t(c,n,o)l[e["type"]]=nil
end
end)for n,e in i(r.add or{})do
if not e["servicetype"]or e["servicetype"]=="profile"then
l[n]=e
end
end
for l,c in i(l)do
if(a:match("sip_profile_(.*)$"))then
if(v==true)then
local n=a:match("sip_profile_(.*)$")e.sectionname="service".."_"..b(l).."_"..n
e.option=nil
else
e.sectionname="service"local n=n.add_on_uci(e)e.sectionname=n
end
t(e,"service",o)e.option="type"t(e,l,o)e.option="profile"t(e,{a},o)for n,i in i(c)do
if n~="servicetype"then
e.option=n
t(e,i,o)end
end
end
end
end
d[e.config]=true
end
function c.add_sip_dial_plan_entry(o,o,r,l)e.sectionname="dial_plan"e.option=nil
local o,c
local c={config="mmpbx"}n.foreach_on_uci(e,function(e)if type(e["network"])=="table"and p(d(e["network"]," "),"sip_net")then
o=e[".name"]return false
end
end)local c=0
if o then
e.sectionname="dial_plan_entry"n.foreach_on_uci(e,function(e)if(e['.name'])then
if(e['.name']:match("dial_plan_entry_generic"))then
local e=tonumber((e['.name']:match("dial_plan_entry_generic_(.*)$")))if e>c then
c=e
end
end
end
end)e.sectionname="dial_plan_entry_generic_"..c+1
t(e,"dial_plan_entry",l)local n=n.generate_key()e.option="_key"t(e,n)n="dial_plan_entry".."|"..n
e.option="dial_plan"t(e,o,l)for o,n in i(a.dial_plan_entry_table)do
e.option=o
t(e,n,l)end
r[e.config]=true
return n
end
end
local function b(l,c,a,o)e.sectionname="dial_plan"e.option=nil
local t
n.foreach_on_uci(e,function(e)if type(e["network"])=="table"and p(d(e["network"]," "),c)then
t=e[".name"]return false
end
end)if t then
e.sectionname="dial_plan_entry"local t=n.add_on_uci(e)a[e.config]=true
e.sectionname=t
e.option='pattern'local t=y(l)n.set_on_uci(e,t,o)e.option='forced_profile'local t=f("sip_profile_%s",l)n.set_on_uci(e,t,o)for i,t in i(u)do
e.option=i
n.set_on_uci(e,t,o)end
end
end
local function a()local e=0
local o={config="tod",sectionname="voicednd"}n.foreach_on_uci(o,function(n)local n=tonumber(n['.name']:match("profile(%d+)")or"0")if(e<n)then
e=n
end
end)return e+1
end
local function d(l,c,o)local e={config="tod",sectionname="tod"}local t=false
n.foreach_on_uci(e,function(e)if e[".name"]=="voicednd"then
t=true
end
end)if t==true then
local t=a()local t=f("profile%s",t)e.sectionname=t
e.option=nil
n.set_on_uci(e,"voicednd",o)local l={l}e.option="profile"n.set_on_uci(e,l,o)e.sectionname="dnd_"..t
e.option=nil
n.set_on_uci(e,"action",o)local t={enabled="1",script="voicedndscript",object="voicednd."..t,timers={""},}for i,t in i(t)do
e.option=i
n.set_on_uci(e,t,o)end
c[e.config]=true
end
end
function c.profile_add(r,a,o)local c
if g=="firstAvailableId"then
c=s()else
c=m()end
local t=f("sip_profile_%s",c)l.sectionname=t
l.option=nil
n.set_on_uci(l,"profile",o)if r then
local e=f("profile%s",c+1)local e={network="sip_net",uri=e,user_name=e,password=e,display_name=e,enabled="0",}for i,e in i(e)do
l.option=i
n.set_on_uci(l,e,o)end
end
a[l.config]=true
e.sectionname=t
e.option=nil
n.set_on_uci(e,"profile",o)e.option="config"n.set_on_uci(e,"mmpbxrvsipnet",o)h(t,a,o)d(t,a,o)if u then
b(c,"sip_net",a,o)end
a[e.config]=true
return t
end
local function s(d,c,a)e.sectionname="service"local o={config="mmpbx"}local l={}n.foreach_on_uci(e,function(e)if type(e.profile)=="table"then
local t={}for n,e in i(e.profile)do
if e~=d then
t[#t+1]=e
end
end
if#t==0 and r and r["add"][e["type"]]then
l[#l+1]=e[".name"]else
o.sectionname=e[".name"]o.option="profile"n.set_on_uci(o,t,a)c[o.config]=true
end
end
end)for i,o in i(l)do
e.sectionname=o
n.delete_on_uci(e,a)c[e.config]=true
end
end
function c.delete_sip_dial_plan_entry(i,l,t)e.sectionname="dial_plan_entry"e.option=nil
local o=false
n.foreach_on_uci(e,function(e)if e[".name"]==i then
o=true
return o
end
end)if o then
e.sectionname=i
n.delete_on_uci(e,t)l[e.config]=true
return true
end
end
local function f(l,c,t)e.sectionname="dial_plan_entry"e.option=nil
local o={}n.foreach_on_uci(e,function(e)if e["forced_profile"]==l then
o[#o+1]=e[".name"]end
end)for i,o in i(o)do
e.sectionname=o
n.delete_on_uci(e,t)c[e.config]=true
end
end
local function d(r,a,l)local e={config="tod",sectionname="voicednd"}local c={}n.foreach_on_uci(e,function(t)if type(t.profile)=="table"then
local o={}for n,e in i(t.profile)do
if e~=r then
o[#o+1]=e
end
end
if#o==0 then
c[#c+1]=t[".name"]elseif#t.profile~=#o then
e.sectionname=t[".name"]e.option="profile"n.set_on_uci(e,o,l)a[e.config]=true
end
end
end)for o,t in i(c)do
e.sectionname="action"n.foreach_on_uci(e,function(o)if o.object=="voicednd."..t then
if o.timers and type(o.timers)=="table"then
for i,o in i(o.timers)do
if o~=""then
e.sectionname=o
n.delete_on_uci(e,l)end
end
end
e.sectionname=o[".name"]n.delete_on_uci(e,l)end
end)e.sectionname=t
n.delete_on_uci(e,l)a[e.config]=true
end
end
function c.profile_delete(o,i,t)l.sectionname=o
l.option=nil
n.delete_on_uci(l,t)i[l.config]=true
e.sectionname=o
e.option=nil
n.delete_on_uci(e,t)i[e.config]=true
s(o,i,t)if u then
f(o,i,t)end
d(o,i,t)c.port_set(o,{},i,t)end
function c.find_device_support(e)local i,l,t=0,0,0
o.config="mmpbx"o.sectionname="device"n.foreach_on_uci(o,function(e)if e['.name']:sub(1,1)=="f"then
i=i+1
end
if e['.name']:sub(1,1)=="d"then
l=l+1
end
if e['.name']:sub(1,1)=="s"then
t=t+1
end
end)return i,l,t
end
function c.validateDigitMapString(e)if not e or e==""then
return true
end
if#e>256 then
return false
end
local l=""local n=1
local t=1
local o=1
local i=""local c=""local a={['(']=")",['[']="]",['{']="}",}local r={[')']=true,[']']=true,['}']=true,}while o<=#e do
i=_(e,o,o)if not p(i,'[-+|0-9TXx%[%]%.#%*(){}]')then
return false
end
if r[i]then
t=t-1
end
if a[i]then
t=t+1
l=a[i]c=_(e,#e,#e)n=o
local i=""while n and n<=#e do
i=_(e,n,n)if r[i]then
break
end
if i==l or n==#e then
endPatternIndex=n
setString=string.sub(e,o,endPatternIndex)local e=1
local n=0
while e and e<=#setString do
setChar=_(setString,e,e)if setChar==l or c==l then
n=1
end
e=e+1
end
if n==0 then
return false
end
break
end
n=n+1
end
end
o=o+1
end
if t~=1 then
return false
end
return true
end
return c