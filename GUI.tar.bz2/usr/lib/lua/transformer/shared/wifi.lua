local t={}local l,o,d=string.gmatch,ipairs,table.concat
local c=require("transformer.mapper.ucihelper")local r={config="wireless"}local function i(n,r,t)local e={}for n in l(n,r)do
if t and not n:match(t)then
return nil,"Invalid Value"end
e[n]=true
end
return e
end
local function a(r,e,t)local n={}for e in l(r,e)do
if t and not e:match(t)then
return nil,"Invalid Value"end
n[#n+1]=e
end
return n
end
function t.setBasicRateset(e,n)local n=string.gsub(n,"%d*%.*%d*%(b%)[,%s]?","")n=a(n,"([^,%s]+)")local e,t=i(e,"([^,%s]+)","^%d+%.?%d*$")if not e then
return nil,t
end
for r,t in o(n)do
if e[t]then
n[r]=t.."(b)"e[t]=nil
end
end
for e in pairs(e)do
n[#n+1]=e.."(b)"end
return d(n," ")end
function t.setOperationalRateset(n,e)local t
local e=i(e,"([^,%s]+)%(b%),?")n,t=a(n,"([^,%s]+)","^%d+%.?%d*$")if not n then
return nil,t
end
for r,t in o(n)do
if e[t]then
n[r]=t.."(b)"e[t]=nil
end
end
for e in pairs(e)do
n[#n+1]=e.."(b)"end
return d(n," ")end
function t.isSupportedMode(n,e)r.sectionname=n
r.option="supported_security_modes"local n=c.get_from_uci(r)for n in n:gmatch('([^%s]+)')do
if n==e then
return true
end
end
return false
end
function t.getSignalStrength(n)local e=1
if n then
if n<=-127 then
e="1"elseif n<-85 and n>-127 then
e="2"elseif n==-85 then
e="3"elseif n<-75 and n>-85 then
e="4"else
e="5"end
end
return e
end
return t