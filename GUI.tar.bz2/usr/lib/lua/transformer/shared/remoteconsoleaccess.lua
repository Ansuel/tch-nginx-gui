local e=string
local _=pairs
local n=os
local i=require("transformer.mapper.ucihelper")local w=i.get_from_uci
local c=i.set_on_uci
local R=i.foreach_on_uci
local b=e.match
local U=e.find
local p=e.format
local E=e.lower
local y=require("lfs")local A=require("transformer.mapper.ubus").connect()local P=io.open
local v=n.remove
local q=require("modgui").execute
local I={}local t={}local n={}local e={config="dropbear"}local r={config="firewall"}local o={config="clash"}local J={["0"]="0",["300"]="1",["900"]="2",["1800"]="3",["3600"]="4",["21600"]="5",["43200"]="6",["86400"]="7",["259200"]="8",["604800"]="9"}local a={}for n,e in _(J)do
a[e]=n
end
local s="0"local T="1"local g="2"local d="3"local m="4"local h="5"local f="6"function n.getRemoteConsoleType()local o=s
local n,t,l,a
e.sectionname="dropbear"e.option=nil
R(e,function(e)if e.Port=="22"and e.Interface=="lan"then
n=e.enable=="1"elseif e.Port=="22"and e.Interface=="wan"then
t=e.enable=="1"elseif e.Port=="23"and e.Interface=="lan"then
l=e.enable=="1"elseif e.Port=="23"and e.Interface=="wan"then
a=e.enable=="1"end
end)if not n and not t and not l and not a then
o=s
elseif n and not t and not l and not a then
o=T
elseif not n and t and not l and not a then
o=g
elseif n and t then
o=d
elseif not n and not t and l and not a then
o=m
elseif not n and not t and not l and a then
o=h
elseif not n and not t and l and a then
o=f
end
return o
end
local function C(t,o)local n
e.sectionname="dropbear"e.option=nil
R(e,function(e)if e.Interface==t and e.Port==o then
n=e[".name"]return false
end
end)return n or""end
local function u(n,o,t)e.sectionname=C(n,o)e.option=t
return w(e)end
local function l(a,l,r,o,n)e.sectionname=C(a,l)e.option=r
c(e,o,n)t[e.config]=true
end
local function x(n,a,l,e)o.sectionname=n
o.option=a
c(o,l,e)t[o.config]=true
end
local function C(e)local o=false
local n=P("/etc/passwd","r")if n then
for t in n:lines()do
if e and t:match("^"..e..":")then
o=true
break
end
end
n:close()end
return e,o
end
local function P()local n
o.sectionname="user"o.option=nil
R(o,function(e)if e[".name"]~="superuser"then
n=e[".name"]return false
end
end)return C(n)end
local function C(o,n,l,a)r.sectionname="rule"r.option=nil
R(r,function(e)if e.src==o and e.dest_port==n then
r.sectionname=e[".name"]r.option="target"c(r,l,a)t[r.config]=true
return false
end
end)end
local function R(e,t,n)o.sectionname=e
i.rename_on_uci(o,t,n)return true
end
local function r(n,e,a)local l="/etc/clash/history"..e..".txt"local n="/etc/clash/history"..n..".txt"o.sectionname=e
o.option="historyfile"c(o,l,a)v(n)t[o.config]=true
end
local function v(o,n,t)if not o or not n then
return nil,"cannot change user account without proper info"end
o=E(o)n=E(n)e.sectionname="global"e.option="restrictRoot"if E(n)=="root"then
n=w(e)end
if y.attributes("/usr/sbin/usermod","mode")~="file"or
y.attributes("/usr/sbin/groupmod","mode")~="file"then
return nil,"could not find required tools"end
local e
e=q(p("usermod -l %s %s",n,o))if e~=0 then
return nil,"could not change username"end
e=q(p("groupmod -n %s %s",n,o))if e~=0 then
return nil,"could not change group name"end
local e=R(o,n,t)if not e then
return nil,"could not change clash user section"end
r(o,n,t)return true
end
local r={"qwerty","uiop[]","asdfgh","jkl;'","zxcvbn","m,./"}local function R(e)local n=(#e>=8)and
b(e,"%l+")and
b(e,"%u+")and
b(e,"%d+")and
not b(e,"%s+")if not n then
return false
end
local o=E(e)for t,e in ipairs(r)do
if U(o,e,1,true)then
n=false
break
end
end
return n
end
function n.getRemoteConsoleUserName()e.sectionname="global"e.option="AdminUser"return w(e)end
function n.getRemoteConsolePassword()e.sectionname="global"e.option="hPass"return w(e)end
function n.getRemoteConsoleIdleTimeout()local e=n.getRemoteConsoleType()local n
if e==s or
e==T or
e==d then
n=u("lan","22","IdleTimeout")elseif e==m or
e==f then
n=u("lan","23","IdleTimeout")elseif e==h then
n=u("wan","23","IdleTimeout")else
n=u("wan","22","IdleTimeout")end
return J[n]or"0"end
function n.getRemoteTelnetEnable()local e=u("wan","23","enable")return e~=""and e or"0"end
function n.getRemoteTelnetIdleTimeout()local e=u("wan","23","IdleTimeout")return J[e]or"0"end
local o={[s]={"0","0","0","0"},[T]={"1","0","0","0"},[g]={"0","1","0","0"},[d]={"1","1","0","0"},[m]={"0","0","1","0"},[h]={"0","0","0","1"},[f]={"0","0","1","1"},}local r={[s]={"REJECT","REJECT","REJECT"},[T]={"REJECT","REJECT","REJECT"},[g]={"ACCEPT","REJECT","REJECT"},[d]={"ACCEPT","REJECT","REJECT"},[m]={"REJECT","REJECT","ACCEPT"},[h]={"REJECT","ACCEPT","REJECT"},[f]={"REJECT","ACCEPT","ACCEPT"},}local s={[s]="0",[T]="0",[g]="0",[d]="0",[m]="1",[h]="1",[f]="1",}function n.setRemoteConsoleType(e,n)local t,a=P()l("lan","22","enable",o[e][1],n)l("wan","22","enable",o[e][2],n)l("lan","23","enable",o[e][3],n)l("wan","23","enable",o[e][4],n)x(t,"telnet",s[e],n)C("wan","22",r[e][1],n)C("wan","23",r[e][2],n)C("lan","23",r[e][3],n)return true
end
function n.setRemoteConsoleUserName(o,l)local n,a=P()if not n or not a then
return nil,p("user account %s not found, cannot change username",n)end
e.sectionname="global"e.option="AdminUser"c(e,o,l)t[e.config]=true
if E(o)~="superuser"then
return v(n,o,l)else
return nil,"username not allowed"end
end
function n.setRemoteConsolePassword(n,a)local l,o=P()if not l or not o then
return nil,p("user account %s not found, cannot change passwd",l)end
if R(n)then
local o=io.popen("chpasswd","w")if o then
o:write(p("%s:%s",l,n))o:close()end
e.sectionname="global"e.option="hPass"n=n:gsub("(%S)","*")c(e,n,a)t[e.config]=true
else
return nil,"password doesn't meet the requirements"end
return true
end
function n.setRemoteConsoleIdleTimeout(e,n)l("lan","22","IdleTimeout",a[e]or"0",n)l("wan","22","IdleTimeout",a[e]or"0",n)l("lan","23","IdleTimeout",a[e]or"0",n)l("wan","23","IdleTimeout",a[e]or"0",n)A:send("shellremoteaccess",{access="start",timeout=a[e]or"0"})return true
end
local o={['0']="REJECT",['1']="ACCEPT"}function n.setRemoteTelnetEnable(e,n)l("wan","23","enable",e,n)return C("wan","23",o[e],n)end
function n.setRemoteTelnetTimeout(e,n)l("wan","23","IdleTimeout",a[e]or"0",n)A:send("shellremoteaccess",{access="start",timeout=a[e]or"0"})end
function n.commit_remoteconsole_data()for e in _(t)do
I.config=e
i.commit(I)end
t={}end
function n.revert_remoteconsole_data()for e in _(t)do
I.config=e
i.revert(I)end
t={}end
return n