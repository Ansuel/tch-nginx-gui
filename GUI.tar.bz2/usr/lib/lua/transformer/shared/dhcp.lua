local o={}local l=require("transformer.mapper.ucihelper")local n=ipairs
local f="4294967295"local a=l.get_from_uci
local r=l.getall_from_uci
local s=l.set_on_uci
local e={config="dhcp",option="dhcp_option",default={}}local c={config="network"}local t=require("transformer.mapper.nwcommon")local i=require"tch.inet"local d=require("bit")local d=require("math").min
function o.getRouteIPAddress(o)local e
for o,n in n(o)do
e=n:match("3,(%d+.%d+.%d+.%d+)")if e then
break
end
end
return e
end
function o.setDefaultRoute(t,o)local l=false
e.sectionname=o
local o=a(e)t="3,"..t
for e,n in n(o)do
if n:match("3,(%d+.%d+.%d+.%d+)")then
o[e]=t
l=true
break
end
end
if not l then
o[#o+1]=t
end
s(e,o,commitapply)end
function o.convertTimeStringToSeconds(o)if not o or o==""then
return"43200"end
if o==f then
return"-1"end
local e=1
local t=-2
local l
local n=o:sub(-1,-1)if n=="s"then
e=1
elseif n=="m"then
e=60
elseif n=="h"then
e=3600
elseif n=="d"then
e=86400
elseif n=="w"then
e=604800
else
t=-1
end
l=tonumber(o:sub(1,t))or-1
return tostring(e*l)end
function o.parseDNSServersFromUCI(e)local o
for n,e in n(e)do
if(e:find("^6,")==1)then
o=e:sub(3)break
elseif e:find("^option:dns")then
o=e:sub(19)break
end
end
return o
end
function o.parseDNSServersFromDatamodel(t,l)local o={}for e in t:gmatch("([^,]+)")do
o[#o+1]=e
end
for o,n in n(o)do
local e,n=i.isValidIPv4(n)if not e then
return nil,n
end
end
e.sectionname=l
local l=a(e)local e={}local t="6"for o,n in n(l)do
if not((n:find("^6,")==1)or(n:find("^option:dns")==1))then
e[#e+1]=n
end
end
for o,n in n(o)do
t=t..","..n
end
e[#e+1]=t
return e
end
function o.parseDHCPData(a,o)local i={}if not o then
local o=t.findLanWanInterfaces(false)for t,n in n(o)do
o[n]=true
end
e.sectionname="dhcp"l.foreach_on_uci(e,function(e)if o[e.interface]then
i[e['.name']]=e.interface
end
end)end
o=o or i[a]c.sectionname=o
local n=r(c)e.sectionname=a
local o=r(e)local e=n.netmask and t.ipv4ToNum(n.netmask)local n=n.ipaddr and t.ipv4ToNum(n.ipaddr)local a=tonumber(o["start"]or"100")local r=tonumber(o["limit"]or"150")if not n then
n=0
end
if not e then
e=0
end
local n=t.extractNetworkAddress(n,e)local i=n+1
local l=t.extractBroadcastAddress(n,e)-1
local e=t.getStartAddress(n+a,n,e)local t=d(e+r-1,l)return{ipStart=e,ipEnd=t,network=n,ipMin=i,ipMax=l,name=o[".name"]or""}end
local function a()local n={}e.sectionname="dnsmasq"l.foreach_on_uci(e,function(e)n[#n+1]=e.leasefile
end)return n
end
function o.getDhcpInfo(t)local o={}for n,e in n(a())do
local n=io.open(e,"r")if n then
for e in n:lines()do
local n,e,l,t=e:match("^(%d+)%s+(%x%x:%x%x:%x%x:%x%x:%x%x:%x%x)%s+(%S+)%s+(%S+)%s+")if e then
o[e]={leasetime=n,macaddr=e,ip=l,hostname=t,}end
end
n:close()end
end
return t and o[t]or o
end
return o