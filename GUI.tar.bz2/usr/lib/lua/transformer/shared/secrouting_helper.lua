local n={}local e=require("transformer.mapper.ucihelper")local o=e.foreach_on_uci
local i={config="network",sectionname="interface"}local a={}local e=require("transformer.mapper.nwcommon")local l=e.get_ubus_interface_status
function n.getRoutingTables()local n={"main"}local t={}o(i,function(e)if e.ip4table and e.ip4table~="main"then
a[e[".name"]]=e.ip4table
if not t[e.ip4table]then
t[e.ip4table]=true
n[#n+1]=e.ip4table
end
end
end)return n
end
function n.getCachedSecRouteMap()return a
end
function getDeviceRtTableMap(e)local n={}for e,a in pairs(e)do
local e=l(e)if e and e.device then
n[e.device]=a
end
if e and e.l3_device then
n[e.l3_device]=a
end
end
return n
end
function n.getRoutesforRtTable(l,e,t)local n={}local n={}local a
local t=getDeviceRtTableMap(t)for i,e in ipairs(e)do
a=e.deviceName~=''and e.deviceName or e.ifname
if(l=="main"and not t[a])or t[a]==l then
n[#n+1]=e
end
end
return n
end
return n