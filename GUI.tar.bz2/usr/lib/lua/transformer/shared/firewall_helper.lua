local o={}local e,a,s,t,l=require,ipairs,math,pairs,type
local e=e'transformer.mapper.ucihelper'local f={config="firewall",sectionname="dmzredirect"}local function r(n)return e.get_from_uci({config="firewall",sectionname="fwconfig",option="defaultincoming_"..n,default="DROP"})end
local function d(n)return e.get_from_uci({config="firewall",sectionname="fwconfig",option="defaultoutgoing_"..n,default="ACCEPT"})end
function o.setincomingpolicyto(o,i)e.foreach_on_uci({config="firewall",sectionname="zone"},function(n)if n["name"]=="wan"then
e.set_on_uci({config="firewall",sectionname=n[".name"],option="forward"},o,i)e.set_on_uci({config="firewall",sectionname=n[".name"],option="input"},o,i)return false
end
end)e.commit({config="firewall"})end
function o.setoutgoingpolicyto(n,o)e.set_on_uci({config="firewall",sectionname="defaultoutgoing",option="target"},n,o)end
function o.get_firewall_mode()local e=e.get_from_uci({config="firewall",sectionname="fwconfig",option="level"})return e~=""and e or"normal"end
function o.set_firewall_mode(i,n)local c={lax={"laxrules","0"},normal={"normalrules","0"},high={"highrules","0"},user={"userrules","0"}}if not c[i]then
return nil,"invalid value"end
c[i][2]="1"for i,o in t(c)do
e.set_on_uci({config="firewall",sectionname=o[1],option="enabled"},o[2],n)end
if i=="user"then
e.set_on_uci({config="firewall",sectionname="userrules_v6",option="enabled"},"1",n)e.set_on_uci({config="firewall",sectionname="userrules_pxsservices",option="enabled"},"1",n)else
e.set_on_uci({config="firewall",sectionname="userrules_v6",option="enabled"},"0",n)e.set_on_uci({config="firewall",sectionname="userrules_pxsservices",option="enabled"},"0",n)end
if i=="user"or i=="high"then
e.set_on_uci({config="firewall",sectionname="pinholerules",option="enabled"},"0",n)else
e.set_on_uci({config="firewall",sectionname="pinholerules",option="enabled"},"1",n)end
local t=d(i)o.setoutgoingpolicyto(t,n)t=r(i)o.setincomingpolicyto(t,n)local o=o.get_blocked_redirects(i)local t=o["dmzredirects"]and"0"or e.get_from_uci({config="firewall",sectionname="fwconfig",option="dmz",default="0"})e.set_on_uci({config="firewall",sectionname="dmzredirects",option="enabled"},t,n)e.set_on_uci({config="firewall",sectionname="userredirects",option="enabled"},o["userredirects"]and"0"or"1",n)local t=e.get_from_uci({config="firewall",sectionname="fwconfig",option="blocked_redirects_user"})if t~=""then
e.set_on_uci({config="firewall",sectionname="guiredirects",option="enabled"},o["guiredirects"]and"0"or"1",n)e.set_on_uci({config="firewall",sectionname="cliredirects",option="enabled"},o["cliredirects"]and"0"or"1",n)e.set_on_uci({config="firewall",sectionname="acsredirects",option="enabled"},o["acsredirects"]and"0"or"1",n)end
e.set_on_uci({config="firewall",sectionname="fwconfig",option="level"},i,n)e.set_on_uci({config="firewall",sectionname="fwconfig",option="acs_admin_config"},"",n)e.commit({config="firewall"})end
function o.dmz_blocked()local e=o.get_blocked_redirects(o.get_firewall_mode())return e["dmzredirects"]or false
end
function o.get_blocked_redirects(n)local n=e.get_from_uci({config="firewall",sectionname="fwconfig",option="blocked_redirects_"..n})local e={}if l(n)=="table"then
for o,n in a(n)do
e[n]=true
end
end
return e
end
function o.set_dmz_enable(i,n)e.set_on_uci({config="firewall",sectionname="fwconfig",option="dmz"},i,n)if not o.dmz_blocked()then
e.set_on_uci({config="firewall",sectionname="dmzredirects",option="enabled"},i,n)e.foreach_on_uci(f,function(o)e.set_on_uci({config="firewall",sectionname=o[".name"],option="enabled"},i,n)end)end
e.commit({config="firewall"})end
local function c(n)local o={}if not n or not n.config or not n.sectionname then
return{}end
e.foreach_on_uci(n,function(e)o[e['.name']]=e['.name']end)return o
end
function o.generate_unused_section(i)local n
local o
local e
o=s.random(0,65534)e=o
local t=c(i)local i=i.sectionname
repeat
if e>=65535 then
e=0
else
e=e+1
end
if e==o then
return nil,"Failed to generate an unique name for the new object"end
n=i..string.format("%04X",e)until t[n]==nil
return n
end
function o.ip2mac(r,e,i,o)local n
local c
if not(r and(e=="ipv4"or e=="ipv6")and i)then
return nil
end
c=r:call("hostmanager.device","get",{[e.."-address"]=i})if(c)then
for r,c in t(c)do
if l(c[e])=="table"then
for t,e in t(c[e])do
if e["address"]==i and(e["state"]=="connected"or e["state"]=="stale")then
if o and e["configuration"]~=o then
return nil
end
n=c["mac-address"]break
end
end
if n then
break
end
end
end
if not n then
local r,c=next(c,nil)if c and l(c[e])=="table"then
for t,e in t(c[e])do
if e["address"]==i then
if o and e["configuration"]~=o then
return nil
end
n=c["mac-address"]break
end
end
end
end
end
return n
end
return o