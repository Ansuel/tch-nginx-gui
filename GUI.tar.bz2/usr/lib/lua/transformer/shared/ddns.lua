local l={}local t=io.open
local i="/var/run/ddns/"local a="/var/log/ddns/"local e=string
local n,u,f=e.find,e.lower,e.match
local o={["fail"]="Connection",["nohost"]="Connection",["401"]="Authenticating",["badauth"]="Authenticating",["ERR Not authenticated"]="Authenticating",["500"]="Authenticating",["notify NG"]="Authenticating",["200 OK"]="Updated",["good"]="Updated",["nochg"]="Updated",["HTTP Basic: Access denied"]="Protocol",["No error received from server"]="Connecting",["Domain's IP updated"]="Updated",}local d={Authenticating="AUTHENTICATION_ERROR",Connection="CONNECTION_ERROR",Updated="NO_ERROR",Connecting="NO_ERROR",Protocol="PROTOCOL_ERROR",Error="MISCONFIGURATION_ERROR",}local function c(e)local e=t(e)if e then
local n=e:read("*a")e:close()return n
end
return
end
local function h(e)local n={}local e=t(a..e..".log")if e then
for t in e:lines()do
n[#n+1]=t
end
e:close()end
return n
end
local function s(e)local a="No error received from server"local o=false
local t=false
local r=false
local e=h(e)for a=#e,1,-1 do
local e=e[a]if n(e,"last update:")then
break
end
if n(u(e),"error")or n(u(e),"fail")then
break
end
if n(e,"Update successful")or n(e,"Forced update successful")then
r=true
break
end
if f(e,".+Waiting %d+ seconds %(Check Interval%)")then
o=true
end
if n(e,"Detect registered/public IP")then
t=true
end
if o and t then
break
end
end
if r or(o and t)then
a="Domain's IP updated"end
return a
end
function l.getDdnsInfo(n)local e=c(i..n..".err")if e and e:match("nslookup")then
return"Error","CONNECTION_ERROR"end
e=c(i..n..".dat")if e then
for t,n in pairs(o)do
if e:match(t)then
return n,d[n]end
end
end
local e=s(n)return o[e],d[o[e]]end
return l