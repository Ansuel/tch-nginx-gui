local n=require("transformer.mapper.ucihelper")local i=n.get_from_uci
local o=string.format
local n=tonumber
local t={}local v=tostring
local d=os
local function c(e,l)local a=l
if n(e)==1 or n(e)==3 or n(e)==5 or n(e)==7 or
n(e)==8 or n(e)==10 or n(e)==12 then
if l>31 then
a=l-7
end
else
if n(e)~=2 then
if l>30 then
a=l-7
end
else
if l>28 then
a=l-7
end
end
end
return a
end
local function s(l)local o=d.date("%Y")local e
local t,l,a=l:match("M([^.]+).([^.]+).([^.]+)")if not(n(l)>=1 and n(l)<=5)or not(n(a)>=0 and n(a)<=6)then
return nil,"Invalid value"else
local d=d.date("*t",d.time{year=o,month=t,day=1}).wday-1
if d~=0 then
e=7*n(l)-d+1+n(a)e=c(t,e)else
e=7*(n(l)-1)+1+n(a)e=c(t,e)end
if n(e)<10 then
e="0"..n(e)end
return e
end
end
local function c(t)local e=t
local e,d=e:gsub(":",":")if d>2 then
return nil
end
local a,l,e
if d==2 then
a,l,e=t:match("^(%d+):(%d+):(%d+)$")elseif d==1 then
a,l=t:match("^(%d+):(%d+)$")e="00"else
a=t:match("^(%d+)$")l="00"e="00"end
t=nil
if a and l and e then
a=n(a)l=n(l)e=n(e)if a>=0 and a<=23 and l>=0 and l<=59 and e>=0 and e<=59 then
a=a<10 and"0"..a or a
l=l<10 and"0"..l or l
e=e<10 and"0"..e or e
t=a..":"..l..":"..e
end
end
return t
end
function t.getStartEndDay(e)local o=e
local r,l=o:gsub(",",",")if l~=2 then
return nil,"Invalid value"else
local e,t=e:match("[^,]+,([^,]+),([^,]+)")if not(e and t)then
return nil,"Invalid value"end
local h,i="00:00:00","00:00:00"local f,u
o=e
r,l=o:gsub("/","/")if l>1 then
return nil,"Invalid value"end
if l==1 then
e,h=e:match("([^/]+)/([^/]+)")end
if not e then
return nil,"Invalid value"end
local a,v,m=e:match("M([^.]+)%.([^.]+)%.([^.]+)")if not(n(a)and n(v)and n(m))or not(n(a)>=1 and n(a)<=12)then
return nil,"Invalid value"end
local m=d.date("%Y")if n(a)<10 then
a="0"..n(a)end
local a=a
local e=s(e)if not e then
return nil,"Invalid value"end
local a=m.."-"..a.."-"..e
local e=c(h)if not e then
return nil,"Invalid value"end
f=a.."T"..e.."Z"o=t
r,l=o:gsub("/","/")if l>1 then
return nil,"Invalid value"end
if l==1 then
t,i=t:match("([^/]+)/([^/]+)")end
if not t then
return nil,"Invalid value"end
local e,a,l=t:match("M([^.]+)%.([^.]+)%.([^.]+)")if not(n(e)and n(a)and n(l))then
return nil,"Invalid value"end
local l=d.date("%Y")if n(e)<10 then
e="0"..n(e)end
local e=e
local n=s(t)if not n then
return nil,"Invalid value"end
local e=l.."-"..e.."-"..n
local n=c(i)if not n then
return nil,"Invalid value"end
u=e.."T"..n.."Z"return f,u
end
end
function t.parse_dateTime(e)local l="(%d%d%d%d)%-(%d%d)%-(%d%d)T(%d%d):(%d%d):(%d%d)"local t,o,d,a,e,l=e:match(l)return n(t),n(o),n(d),n(a),n(e),n(l)end
local function r(n)local n,e,l=t.parse_dateTime(n)local n=d.date("*t",d.time{year=n,month=e,day=l}).yday-1
return n
end
local function d(a)local e,l=a:match("(%d+):(%d+)$")e=e or a:match("(%d+)$")local a=false
if e and(n(e)>=0 and n(e)<=23)then
a=true
end
if l and not(n(l)>=0 and n(l)<=59)then
a=false
end
return a
end
function t.getLocaltimezoneWithoutSDTDST(l)local a=false
local n,e=l:match("^%a+([-+]?%d+:?%d*)%a+([-+]?%d+:?%d*)$")if not n then
n,e=l:match("^%a+([-+]?%d+:?%d*)%s?%a+$")end
if not n then
n=l:match("^%a+([-+]?%d+:?%d*)$")end
if not n then
n=l:match("^%a+")a=true
end
if not n then
return nil,"Invalid value"end
if not a and not d(n)then
return nil,"Invalid value"end
if e then
if not d(e)then
return nil,"Invalid value"end
end
return n,e
end
local function m(n)local d=i(n)local l,n,e
local a=string.find(d,",")if a~=nil then
l=string.sub(d,1,a-1)n,e=t.getLocaltimezoneWithoutSDTDST(l)else
n,e=t.getLocaltimezoneWithoutSDTDST(l)end
return n,e
end
function t.getTZString(h,e,u,s,f)local e=i(e)local a,e,l=e:match("([%+%-]?)(%d+):(%d%d)")if e==nil then
a="+"e="00"l="00"end
e=a..e
local c=o("<%+03d%s>",e,l)local a=n(e)*(-1)local d=o("%+03d:%s",a,l)local a
local u=i(u)if u=="1"then
local n=n(e)+1
local l=o("<%+03d%s>",n,l)local e,n=m(h)if n~=nil then
local e=string.find(n,":")if e==nil then
n=v(n)..":00"end
local a,n,e=n:match("([%+%-]?)(%d+):(%d%d)")if n==nil then
a="+"n="00"e="00"end
n=a..n
l=o("<%+03d%s>",n,e)end
local u=o("%s%s%s",c,d,l)local n=i(s)local e=i(f)if(n=="")then n="1970-01-01T00:00:00"end
if(e=="")then e="1970-01-01T00:00:00"end
local l,l,l,h,i=t.parse_dateTime(n)local l,l,l,d,c=t.parse_dateTime(e)local l,t
l=r(n)t=r(e)a=o("%s,%d/%d:%d,%d/%d:%d\n",u,l,h,i,t,d,c)else
a=o("%s%s\n",c,d)end
return a
end
return t