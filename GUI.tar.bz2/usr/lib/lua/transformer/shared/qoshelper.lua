local e={}local o,t=string.match,string.format
local r={["EF"]="46",["BE"]="0",["AF11"]="10",["AF12"]="12",["AF13"]="14",["AF21"]="18",["AF22"]="20",["AF23"]="22",["AF31"]="26",["AF32"]="28",["AF33"]="30",["AF41"]="34",["AF42"]="36",["AF43"]="38",["CS1"]="8",["CS2"]="16",["CS3"]="24",["CS4"]="32",["CS5"]="40",["CS6"]="48",["CS7"]="56",}function e.mapDSCP(n,e)if n==""or n=="-1"then
if e:match('^rpc.')then
return"0"end
return"-1"end
return r[n]and r[n]or tostring(tonumber(n,16))end
local function c(t)local n
for r,e in pairs(r)do
if t==e then
n=r
break
end
end
return n
end
function e.convertToHexDscp(r,e)local n=c(r)if not n then
n=t("0x%x",r)end
if o(e or"","^!")then
n="!"..n
end
return n
end
return e