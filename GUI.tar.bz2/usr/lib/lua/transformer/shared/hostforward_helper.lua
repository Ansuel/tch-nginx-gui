local a={}local l=require("transformer.mapper.nwcommon")local e=require("transformer.mapper.ucihelper")local o=e.getall_from_uci
local d=e.foreach_on_uci
local r=string.lower
local t=require("transformer.mapper.ubus").connect()local e=require("uci").cursor(UCI_CONFIG,"/var/state")function a.set_volatile_destip(i,a)local n=i.config
local i=i.sectionname
if n then
if a and a~="0.0.0.0"and a~="::"then
e:load(n)e:revert(n,i)e:set(n,i,"dest_ip",a)e:save(n)e:unload(n)end
end
end
function a.remove_volatile_destip(a)local n=a.config
local a=a.sectionname
if a then
e:load(n)e:revert(n,a)e:unload(n)end
end
function a.generate_unique_sectionname(a)if not a or not a.config or not a.sectionname then
return nil,"fw_binding or it's option is nil"end
local i=math.random(0,65534)local e=i
local n
repeat
if e>=65535 then
e=0
else
e=e+1
end
if e==i then
return nil,"Failed to generate an unique name for the new object"end
n=a.sectionname..string.format("%04X",e)d(a,function(e)if e['.name']==n then
n=nil
return false
end
end)until n~=nil
return n
end
function a.ubus_ipmac_retrieval(a,i,n)local e={}local a=o(a)if not a.family then
a.family="ipv4"end
if a.target~="SNAT"then
if i=="dest_mac"and l.isMAC(n)then
e={mac=r(n),family=a.family}elseif i=="dest_ip"and n~=""and n~="0.0.0.0"and n~="::"then
e={ip=n,family=a.family}end
end
local l={}if next(e)~=nil then
local a=t:call("hostmanager.device","get",e.ip and{[e.family.."-address"]=e.ip}or{["mac-address"]=e.mac})if a~=nil then
local i=nil
local n
repeat
i,n=next(a,i)if(n~=nil and n[e.family]~=nil)then
local t,a,i
if not e.ip and n["mac-address"]==e.mac then
a=e.mac
end
for o,t in pairs(n[e.family])do
if e.ip and t["address"]==e.ip then
a=n["mac-address"]end
if t["redirect-dest"]then
i=t["address"]end
if a and i then
l={destmac=a,destip=i}break
end
end
end
until n==nil or next(l)end
end
return l
end
return a