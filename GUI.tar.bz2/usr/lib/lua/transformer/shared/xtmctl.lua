local n=require("modgui").popen
local u=require("modgui").execute
local e=string.match
local a,i=tostring,commitapply
local o=require("transformer.mapper.ucihelper")local d=o.foreach_on_uci
local c=o.set_on_uci
local o=require("modgui")local o=o.getRightLoggerModule()local f=o.new("mapper.xtmctl",2)local r=require("luabcm")local o={}function o.getXtmDeviceStatus(o)local n=n("xtmctl operate conn --show "..o)if not n then
return""end
local l=""local t=""for o in n:lines()do
if e(o,"^ATM")or e(o,"^PTM")then
l=e(o,"enabled")or e(o,"disabled")or""t=e(o,"aal%d")break
end
end
n:close()return l,t
end
function o.enableXtmDevice(e,o)local o=o and"enable"or"disable"if u("xtmctl operate conn --state "..e.." "..o)~=0 then
f:error("enable/disable XTM Device failed")return false
end
end
function o.getBondingStatus()local o="0"local e=r.getBondingStatus()if a(e)~="-1"then
o=a(e["BondingStatus"])end
return o
end
function o.setNetworkConfig(s,f,u)local r=false
local e={config="network"}local t,n,a,l
e.sectionname="interface"d(e,function(o)t=o['.name']or""n=o.device or o.ifname or""a=o.vpi or""l=o.vci or""if a~=""or l~=""then
if n==s then
e.sectionname=t
e.option="vci"c(e,u,i)e.option="vpi"c(e,f,i)r=true
end
end
end)return r
end
return o