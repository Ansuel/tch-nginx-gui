local i={}local c=pairs
local t=require'transformer.mapper.ucihelper'local e=require'transformer.mapper.nwcommon'local u=e.split_key
local n=require("transformer.shared.common.network")local o=require'transformer.shared.wanconnection'local r={}local a,l
local e={config="tr143"}local d=false
local s={X_0876FF_PeriodOfFullLoading="PeriodOfFullLoading",X_0876FF_TotalBytesReceivedUnderFullLoading="TotalBytesReceivedUnderFullLoading",X_0876FF_TestBytesReceivedUnderFullLoading="TestBytesReceivedUnderFullLoading",X_0876FF_TestBytesSentUnderFullLoading="TestBytesSentUnderFullLoading",}local function f(e)local n=n.getLanInterfaces()for n in c(n)do
if e==n then
return true
end
end
return false
end
local function g(t,n)local e=""if t=="device2"then
e=a("Device.IP.Interface.{i}.",n)else
if f(n)then
e=a('InternetGatewayDevice.LANDevice.{i}.LANHostConfigManagement.IPInterface.{i}.',n)else
local n,t=o.get_connection_key(n)if n and t then
if t.proto=="pppoe"or t.proto=="pppoa"then
e=a("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANPPPConnection.{i}.",n)else
e=a("InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANIPConnection.{i}.",n)end
end
end
end
return e or""end
local function f(n,t,e)if n=="device2"then
local n
n,e=pcall(l,e,"Device.IP.Interface.{i}.")if not n then
return nil,"invalid value"end
else
e=l(e,"InternetGatewayDevice.LANDevice.{i}.LANHostConfigManagement.IPInterface.{i}.","InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANIPConnection.{i}.","InternetGatewayDevice.WANDevice.{i}.WANConnectionDevice.{i}.WANPPPConnection.{i}.")if e and e:match("|")then
local n,t=u(e)if n=="ACTIVE"then
e=t
else
e=n
end
end
end
return e
end
function i.tr143_get(i,r,n)local o=""if n=="UploadTransports"or n=="DownloadTransports"then
return"HTTP,FTP"end
e.sectionname=i
if n=="X_0876FF_ConcurrentSession"or n=="X_000E50_ConcurrentSession"then
local e=t.getall_from_uci(e)if i=="DownloadDiagnostics"then
if e and e.NumberOfConnections and e.DownloadDiagnosticMaxConnections and e.NumberOfConnections<=e.DownloadDiagnosticMaxConnections then
return e.NumberOfConnections
end
return"0"end
if i=="UploadDiagnostics"then
if e and e.NumberOfConnections and e.UploadDiagnosticsMaxConnections and e.NumberOfConnections<=e.UploadDiagnosticsMaxConnections then
return e.NumberOfConnections
end
return"0"end
end
if n=="X_0876FF_Throughput"then
local e=t.getall_from_uci(e)or{}if e.PeriodOfFullLoading and e.PeriodOfFullLoading~="0"and e.TotalBytesReceivedUnderFullLoading then
return tostring(8*(tonumber(e.TotalBytesReceivedUnderFullLoading)/tonumber(e.PeriodOfFullLoading)))end
return"0"end
if n=="DiagnosticsState"then
e.option=n
local e=t.get_from_uci(e)if r=="igd"and e=="Error_Other"then
return"Error_InitConnectionFailed"end
return e
end
e.option=s[n]or n
o=t.get_from_uci(e)if n=="Interface"and o~=""then
o=g(r,o)end
return o or""end
function i.tr143_set(i,l,o,n,a)if o=="Interface"and n~=""then
n=f(l,o,n)if not n then
return nil,"Invalid value"end
end
if o=="UploadURL"or o=="DownloadURL"then
if not string.find(n,"^http://")and not string.find(n,"^ftp://")then
return nil,"Invalid value"end
end
e.sectionname=i
if o=="NumberOfConnections"then
if i=="UploadDiagnostics"then
e.option="UploadDiagnosticsMaxConnections"else
e.option="DownloadDiagnosticMaxConnections"end
local e=t.get_from_uci(e)if tonumber(n)>tonumber(e)then
return nil,"Invalid value"end
end
if o=="DiagnosticsState"then
if n~="Requested"then
return nil,"invalid value"else
e.option="State"t.set_on_uci(e,"Idle",a)end
end
e.option=o
t.set_on_uci(e,n,a)r[e.config]=true
end
function i.tr143_commit()local e={}for n in c(r)do
e.config=n
t.commit(e)end
r={}end
function i.tr143_revert()local e={}for n in c(r)do
e.config=n
t.revert(e)end
r={}end
function i.startup(e,t)local n=require("modgui").execute
a,l=e,t
if d==false then
n("cp /etc/tr143.default /etc/config/tr143")d=true
end
end
return i