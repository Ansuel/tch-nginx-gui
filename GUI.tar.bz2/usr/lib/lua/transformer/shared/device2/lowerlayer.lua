local n=require
local t=pairs
local e=n"transformer.mapper.ucihelper"local o
local i
local r
do
local n={}function o(e)n[e]=true
end
local function o(o)for e in t(n)do
o{config=e}end
n={}end
function i()o(e.commit)end
function r()o(e.revert)end
end
local function l(t,o,n)local n={config="network",sectionname=t,option=o,default=n,}if o then
return e.get_from_uci(n)else
return e.getall_from_uci(n)end
end
local function c(n)local n=l(n)return n['.type'],n
end
local function n(n,t,l)local n={config="network",sectionname=n,option=t,}e.set_on_uci(n,l,commitapply)o(n.config)end
local o={}local function d(e,e,e,n)return nil,("a reference to %s can not be used here"):format(n)end
local function a(e,t)while e~=""do
local o=l(e,"linkedto")if o~=""then
for c,t in ipairs(t)do
n(o,t,l(e,t))end
end
e=o
end
end
local t={"ifname"}local e={}local function u(o,n)e[o]=n
end
local function f(n)return e[n]or t
end
local function t(n,e)a(n,f(e))end
o["Device.Ethernet.Link.{i}."]=function(l,i,e,a)local e=l:getUciKey(e)if c(e)~="dev2_link"then
return nil,"can not attach to hard bound link"end
local l=l:getUciKey(i)n(e,"linkedto",l)t(e,a)end
o["Device.Ethernet.VLANTermination.{i}."]=function(e,a,l,i)local l=e:getUciKey(l)local c,l=c(l)if c~="device"then
return nil,"not a reference to a dynamically linkable VLAN"end
local e=e:getUciKey(a)n(e,"ifname",l.name)t(e,i)end
o["Device.PPP.Interface.{i}."]=function(o,i,e,l)local e=o:getUciKey(e)if c(e)~="ppp"then
return nil,"can not attach to hard bound ppp"end
local o=o:getUciKey(i)n(e,"linkedto",o)n(e,"proto","pppoe")t(e,l)end
local function e(t,e,l,n)local o=o[n]or d
return o(t,e,l,n)end
local function d(l,o,t,n,...)local n,t=tokey(t,n,...)if not n then
return nil,"Not a valid link reference"end
return e(l,o,n,t)end
local function c(o,e)local e=o:getUciKey(e)n(e,"ifname","")a(e,"ifname")if l(e,"proto"):match("^ppp")then
n(e,"proto","")end
local e=o:explicit_link_for(e)if e then
n(o:getUciKey(e),"linkedto","")end
end
local function l(o,n,e,t,...)if e~=""then
return d(o,n,e,t,...)end
return c(o,n)end
return{setLowerLayer=l,set_propagatable_options=u,propagate_options_for=t,commit=i,revert=r,}