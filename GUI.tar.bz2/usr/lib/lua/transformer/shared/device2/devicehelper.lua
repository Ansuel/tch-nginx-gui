local o={}local a=require("transformer.mapper.ucihelper")local n=a.foreach_on_uci
local l={config="ethernet",sectionname="port"}local c={config="network"}local t={config="xtm"}local i={config="wireless"}local r=require("transformer.mapper.ubus").connect()function o.get_devices_for_lowerlayers()local e={}c.sectionname="device"n(c,function(n)if n.type=="8021q"then
e[n.name]="Device.Ethernet.VLANTermination.{i}."end
end)n(l,function(n)e[n[".name"]]="Device.Ethernet.Interface.{i}."end)c.sectionname="interface"n(c,function(n)if n.type=="bridge"and n.ifname then
e[n.ifname]="Device.Bridging.Bridge.{i}.Port.{i}."end
end)t.sectionname="atmdevice"n(t,function(n)e[n[".name"]]="Device.ATM.Link.{i}."end)t.sectionname="ptmdevice"n(t,function(n)e[n[".name"]]="Device.PTM.Link.{i}."end)i.sectionname="wifi-iface"n(i,function(n)e[n[".name"]]="Device.WiFi.SSID.{i}."end)i.sectionname="wifi-device"n(i,function(n)e[n[".name"]]="Device.WiFi.Radio.{i}."end)return e
end
function o.getIntfName(e,i)local n={config="network"}n.sectionname=i:getUciKey(e)n.option="proto"local n=a.get_from_uci(n)if n=="mobiled"then
local e=r:call("network.interface."..i:getUciKey(e),"status",{})if e and e.l3_device then
return e.l3_device
end
end
return i:getDevice(e)end
return o