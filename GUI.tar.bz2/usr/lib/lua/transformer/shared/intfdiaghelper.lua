local i={}local l,r=io.open,pairs
local n=require("transformer.logger")local o=require("transformer.mapper.ucihelper")local t=o.set_on_uci
local c=o.get_from_uci
local e
local n={config="intfdiag"}local a={}local function a(i,n,o)t(i,n,o)e=true
end
function i.startup(i)local e=l("/etc/config/intfdiag","a")e:close()local l
for i,e in r(i)do
n.sectionname=e
local i=c(n)if i==''then
n.sectionname=e
n.option=nil
t(n,"intfdiag")n.option="state"t(n,"None")n.option="interval"t(n,300)n.option="interface"t(n,e)l=true
end
end
if l then
n.sectionname=nil
n.option=nil
o.commit(n)end
return i
end
function i.intfDiagSet(n,e,i)if n.option=="state"then
if e~="Requested"and e~="Canceled"then
return nil,"invalid value"end
if e=="Canceled"then
e="None"end
end
a(n,e,i)n.option="state"local e=c(n)if e~="Requested"and e~="None"then
a(n,"None",i)end
end
function i.intfDiagCommit()if e then
n.sectionname=nil
n.option=nil
o.commit(n)end
e=false
end
function i.intfDiagRevert()if e then
n.sectionname=nil
n.option=nil
o.revert(n)end
e=false
end
return i