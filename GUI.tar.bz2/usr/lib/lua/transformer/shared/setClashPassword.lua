local e={}local n=require("tch.posix")local r=io.open
local n=[[/%.%w]]local o=n
local l=n.."+="function e.listClashUsers()local t={}local n=r("/etc/passwd","r")if n then
for e in n:lines()do
local e=e:match("^(.-):.*shell")if e and e~="root"then
t[e]=true
end
end
n:close()end
return t
end
local function s(n)local e="Invalid encrypted password: "if type(n)~="string"then
return nil,e..type(n)elseif n==""then
return nil,e.."empty"end
local n,r,t=n:match("^%$([56])%$(["..l.."]+)%$(["..o.."]+)$")if n~="5"and n~="6"then
return nil,e.."not SHA256 or SHA512 format"end
if not r or#r~=16 then
return nil,e.."salt is not 16 characters long"end
if not t then
return nil,e.."hash is empty"elseif n=="5"and#t~=43 then
return nil,e.."SHA256 specified, but hash is not 43 characters long"elseif n=="6"and#t~=86 then
return nil,e.."SHA512 specified, but hash is not 86 characters long"end
return true
end
function e.isClashUser(n)return e.listClashUsers()[n]end
function e.validateCredentials(n,e,t)if type(n)~="string"or n==""then
return nil,"Invalid user: "..type(n)end
if t then
local e,n=s(e)if not e then
return nil,n
end
elseif type(e)~="string"then
return nil,"Invalid password: "..type(e)end
return true
end
local function r(t,r,n)local e="/usr/share/transformer/scripts/update_passw.sh '%s' '%s' '%s'"local n=(n and"-e")or""e=e:format(t,r,n)os.execute(e)return true
end
function e.setPassword(n,s)local t,l=e.validateCredentials(n,s)if not t then
return t,l
end
if not e.isClashUser(n)then
return nil,"Attempt to set password for no clash user ("..n..")"end
return r(n,s)end
function e.setCryptedPassword(n,s)local t,l=e.validateCredentials(n,s,true)if not t then
return t,l
end
if not e.isClashUser(n)then
return nil,"Attempt to set encrypted password for no clash user ("..n..")"end
return r(n,s,true)end
return e