local n=string.format
local o=require'transformer.mapper.ucihelper'local l={}local e={ap0="r0",ap1="r1"}local function a(l)local e=e[l]if e then
return{wep_key=n("default_wep_key_%s_s0",e),wpa_psk_key=n("default_key_%s_s0",e),wps_ap_pin=n("default_wps_ap_pin_%s_s0",e),security_mode=n("default_security_mode_%s_s0",e)}end
end
local e={config="env",sectionname="var"}local function r()return o.getall_from_uci(e)end
local function t(e)local n=a(e)if n then
local e={}local o=r()for l,n in pairs(n)do
local n=o[n]if not n then
return
end
e[l]=n
end
return e
end
end
local e={config="wireless"}local function r(l,n,r)e.sectionname=l
for l,n in pairs(n)do
e.option=l
o.set_on_uci(e,n,r)end
return true
end
function l.reset(e,l)local n=t(e)if n then
return r(e,n,l)end
return nil,"no defaults found for this AccessPoint"end
return l