local e={}local r=require("transformer.mapper.ucihelper")local s=require("transformer.mapper.ubus").connect()local n={config="wireless"}local t=require("transformer.shared.bandsteerhelper")local a={config="env",sectionname="var"}local l,i=pairs,tostring
local o
function e.getFromWireless(s,e,t)n.sectionname=s
if e then
n.option=e
n.default=t
return r.get_from_uci(n)end
return r.getall_from_uci(n)end
function e.setOnWireless(e,i,s,t)n.sectionname=e
n.option=i
r.set_on_uci(n,s,t)o=true
end
function e.getAPFromIface(e)local n=e:gsub("_remote","")local e=s:call("wireless.accesspoint","get",{})or{}for t,e in l(e)do
if e.ssid==n then
return t
end
end
return""end
function e.getRadioFromIface(n)local n=n:gsub("_remote","")local e=e.getFromWireless(n,"device")if e==""then
local t=s:call("wireless.ssid","get",{name=n})or{}e=t[n]and t[n].radio or""end
return e
end
local d={["accesspoint"]="wireless.accesspoint",["security"]="wireless.accesspoint.security",["ssid"]="wireless.ssid",["radio"]="wireless.radio",["radiostats"]="wireless.radio.stats",["acs"]="wireless.radio.acs",["upgrade"]="wireless.radio.remote.upgrade",}function e.getWirelessUbus(r,n,o,t)t=t or""if r=="accesspoint"or r=="security"then
n=e.getAPFromIface(n)end
local e=s:call(d[r],"get",{name=n})or{}if o then
return e[n]and i(e[n][o]or t)or t
end
return e[n]or{}end
function e.getBandSteerRelatedNode(s,r)local n=t.getBandSteerPeerIface(r)if not n then
return nil,"Band steering switching node does not exist."end
local e=e.getAPFromIface(n)if e==""then
return nil,"Band steering peer AP is invalid."end
if t.isBaseIface(e)then
return e,s,n,r
else
return s,e,r,n
end
end
function e.setBandSteerID(r,t,s,o,n)if o then
e.setOnWireless(r,"bandsteer_id",s,n)e.setOnWireless(t,"bandsteer_id",s,n)else
e.setOnWireless(r,"bandsteer_id","off",n)e.setOnWireless(t,"bandsteer_id","off",n)end
end
local function d(o,t,s,i)local n
if s then
n=e.getFromWireless(o,"ssid")else
a.option="commonssid_suffix"local r=r.get_from_uci(a)n=e.getFromWireless(t,"ssid")n=n~=""and n..r or""end
e.setOnWireless(t,"ssid",n,i)end
function e.enableBandSteer(n,r)local o=e.getAPFromIface(n)local s,i=t.canEnableBandSteer(o,e.getWirelessUbus("accesspoint",n),n)if not s then
return nil,i
end
local s,t=t.getBandSteerId(n)if not s then
return nil,t
end
local t,n,i,o=e.getBandSteerRelatedNode(o,n)e.setBandSteerID(t,n,s,true,r)d(i,o,true,r)e.setOnWireless(n,"security_mode",e.getFromWireless(t,"security_mode"),r)e.setOnWireless(n,"wpa_psk_key",e.getFromWireless(t,"wpa_psk_key"),r)end
function e.disableBandSteer(n,s)local r=e.getAPFromIface(n)local o,t=t.canDisableBandSteer(r,n)if not o then
return nil,t
end
local t,r,o,n=e.getBandSteerRelatedNode(r,n)e.setBandSteerID(t,r,"off",nil,s)d(o,n,nil,s)end
function e.modifyBSPeerNodeAuthentication(s,i,n,o)local r=e.getAPFromIface(n)local r=t.getApBandSteerId(r)if not r or r==""or r=="off"then
return nil,"Bandsteer id is not available or disabled"end
local r=t.getBandSteerPeerIface(n)if not r then
return nil,"Band steering switching node does not exist."end
if t.isBaseIface(n)then
local n
if s=="ssid"then
n=r
else
local e=e.getAPFromIface(r)n=e
end
e.setOnWireless(n,s,i,o)end
return
end
function e.getStationDataFromIface(n,o,t,r)local a=e.getFromWireless(n,"ssid")local e=e.getAPFromIface(n)local n=s:call("wireless.accesspoint.station","get",{name=e})or{}if n[e]and t then
for n,e in l(n[e])do
if n==o and e.state:match("Associated")and e.last_ssid==a then
return i(e[t]or r)end
end
return r
end
return n[e]or{}end
function e.getDataFromWDS(e,t,r)local e=e:match("[%S+%_]+%_(wds%S+)%_[%da-fA-F:]+$")local n=s:call("wireless.wds","get",{})or{}return n[e]and n[e][t]and i(n[e][t])or r
end
function e.commit()if o then
r.commit(n)o=false
end
end
function e.revert()if o then
r.revert(n)o=false
end
end
return e