local e={}local n={}function e.setDataMaxAge(a,e)n[a]=e
end
function e.getDataMaxAge(e)return n[e]end
return e