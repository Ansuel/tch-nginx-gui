local l={}local e,o=io,math
local f=o.floor
local m=require("modgui").popen
local g=e.open
local r=tostring
function l.getCPUUsage()local o,d,i,u,s,t,c,a,n,e
local l=g("/proc/stat")if l then
local r=l:read("*l")o,d,i,u,s,t,c,a,n,e=r:match("^cpu%s*(%d+)%s*(%d+)%s*(%d+)%s*(%d+)%s*(%d+)%s*(%d+)%s*(%d+)%s*(%d+)%s*(%d+)%s*(%d+)")l:close()end
if not o then
return"0"end
local l=s+u
local o=o+d+i+t+c+a+n+e
local o=l+o
local l=f(((o-l)/o)*100)return r(l)end
function l.getCurrentCPUUsage()local e
local c=m("top -b -n1")local l,n,o
for a in c:lines()do
l,n,o=a:match("^CPU:%s*(%d+)%%%s*u.*%s*(%d+)%%%s*s.*%s*(%d+)%%%s*n.*")if l then
e=tonumber(l)+tonumber(n)+tonumber(o)break
end
end
c:close()return r(e)or"0"end
return l