local n=require
local l={}local e=n'transformer.mapper.ucihelper'local f=n'transformer.shared.models.igd.activedevice'local d={config="network",sectionname="interface"}local e=e.foreach_on_uci
local function n(n,o,e)n[#n+1]={type=o,name=e,}end
local r={config="xdsl",sectionname="xdsl"}local function o(o)e(r,function(e)n(o,"DSL",e[".name"])end)end
local o={ATM="atmdevice",PTM="ptmdevice",}local function c(n)local e=o[n]if not e then
n="ATM"e=o[n]end
return e,n
end
local t={config="xtm"}local function a(l,o)t.sectionname,o=c(o)e(t,function(e)n(l,o,e[".name"])end)end
local c={config="ethernet",sectionname="port"}local function u(o)e(c,function(e)if e['wan']=='1'then
n(o,"ETH",e[".name"])end
end)end
local i={config="gponl3",sectionname="interface"}local function m(l)local t={}local o=false
e(i,function(e)if e.l3dev and not t[e.l3dev]then
for l,n in ipairs(l)do
if n.type=="ETH"and n.name==e.l3dev then
o=true
break
end
end
if not o then
t[e.l3dev]=true
n(l,"ETH",e.l3dev)end
end
end)end
local function t(o)e(d,function(e)if e.proto=="mobiled"then
n(o,"MOB",e[".name"])end
end)end
local function o(o)for l,e in pairs(f.getActiveDevices())do
n(o,"ACTIVE",e)end
end
function l.listDevices()local n={}a(n,"ATM")a(n,"PTM")u(n)m(n)t(n)return n
end
function l.entries()local n={}e(r,function(e)n[#n+1]="DSL|"..e['.name']end)e(c,function(e)if e['wan']=='1'then
n[#n+1]="ETH|"..e['.name']end
end)local t={}local l=false
e(i,function(e)if e.l3dev and not t[e.l3dev]then
local o="ETH|"..e.l3dev
for e,n in ipairs(n)do
if n==o then
l=true
break
end
end
if not l then
t[e.l3dev]=true
n[#n+1]=o
end
end
end)e(d,function(e)if e.proto=="mobiled"then
n[#n+1]="MOB|"..e['.name']end
end)for o,e in pairs(f.getActiveDevices())do
n[#n+1]="ACTIVE|"..e
end
return n
end
return l