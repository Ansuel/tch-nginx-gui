local e=require
local t={}local l=e'transformer.mapper.nwcommon'local n=e'transformer.mapper.ucihelper'local d=e'transformer.shared.models.igd.activedevice'local f=e'transformer.shared.models.igd.xtmconnection'local r=l.split_key
local l=n.foreach_on_uci
local u={config="xdsl",sectionname="xdsl"}local e={config="xtm"}local a
local function c(e,l,n)if a[1]==l then
e[#e+1]=n
else
e[#e+1]=n.."|"..l
end
end
local function m(n,a,t)local o={}e.sectionname="atmdevice"l(e,function(l)local e=l._key
if e then
e=t.."|"..e
n[#n+1]=e
o[e]=l[".name"]else
local e="ATM|"..l[".name"]c(n,a,e)end
end)return o
end
local function s(a,t)local o={}local n
e.sectionname="ptmdevice"l(e,function(e)local e=e['.name']n="ETH|"..e
c(a,t,n)o[e]=true
end)e.sectionname="ptmdevice_placeholder"l(e,function(e)local l=e['.name']local e=e.uciname or l:match("^(.*)_placeholder$")if e and not o[e]then
n="ETH|"..e
c(a,t,n)o[e]=true
end
end)end
local function i()local e={}l(u,function(n)e[#e+1]=n['.name']end)return e
end
function t.entries(o)local e={}local n,l=r(o)local c
if not a then
a=i()end
if n=="ETH"or n=="MOB"then
e[#e+1]=o
elseif n=="DSL"then
c=m(e,l,o)s(e,l)e=f.loadStatic_keys(e)elseif n=="ACTIVE"then
local n=d.getActiveInterfaces(l)for l,n in ipairs(n)do
e[#e+1]="ACTIVE|"..n
end
end
return e,c
end
return t