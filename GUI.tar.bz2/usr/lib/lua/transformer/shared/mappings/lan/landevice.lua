local e=require
local r={}local o=e'transformer.mapper.ucihelper'local n=e'transformer.mapper.nwcommon'local l=n.is_alias
local a=e'transformer.shared.common.network'function r.entries()local n={}local e={config="network",sectionname="interface"}local r=a.getWanInterfaces()o.foreach_on_uci(e,function(e)if e['.name']=='loopback'or l(e['.name'])then
return
end
if r[e['.name']]then
return
end
if e['proto']then
n[#n+1]=e['.name']end
end)return n
end
return r