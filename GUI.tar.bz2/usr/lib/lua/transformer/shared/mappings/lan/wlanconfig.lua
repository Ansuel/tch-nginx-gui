local e=require
local n=pairs
local l={}local i=e'transformer.mapper.ucihelper'local a=e'transformer.mapper.nwcommon'local t=e('transformer.mapper.ubus').connect()local c=e'transformer.shared.common.network'local function d(e)local o={}local r={}if e then
o[e]=true
local e=a.get_lower_layers(e)for o,e in n(e or{})do
r[e]=true
end
else
local e=c.getLanInterfaces()for e in n(e or{})do
o[e]=true
local e=a.get_lower_layers(e)for o,e in n(e or{})do
r[e]=true
end
end
end
return o,r
end
local function a(e)local e=e or{}if not e.ssid then
e.ssid=t:call("wireless.ssid","get",{})or{}end
if not e.radio then
e.radio=t:call("wireless.radio","get",{})or{}end
return e
end
function l.entries(l,e)local r={}local o={}local c,t=d(l)local a=a(e)for e,n in n(a.ssid or{})do
local n=a.radio[n.radio]local n=n and n.remotely_managed==1
if n then
local n=i.get_from_uci({config="wireless",sectionname=e,option="network",extended=true})if l==n then
r[#r+1]=e.."_remote"else
if not c[n]then
o[#o+1]=e.."_remote"end
end
else
if t[e]then
r[#r+1]=e
else
o[#o+1]=e
end
end
end
return r,o
end
function l.ssidName(e)return e:match("^(.+)_remote$")or e
end
return l