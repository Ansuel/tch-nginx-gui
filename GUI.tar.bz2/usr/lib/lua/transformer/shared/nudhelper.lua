local e={}local n,r=io.open,os.remove
local o=require("transformer.mapper.ucihelper")local n={config="nud",sectionname="diag"}local i={config="network"}local a=o.set_on_uci
local c=o.get_from_uci
local d=require("transformer.mapper.ubus").connect()local t
function e.clear_ping_results()r("/tmp/nud")r("/tmp/nud_ping")end
local r={enable="0",result="fail",rtt="0",payload="0",}function setDefault()a(n,"nud")for n,e in pairs(r)do
setOnUci(n,e,commitapply)end
end
function e.startup()local e=require("uci").cursor()e:ensure_config_file("nud")e:close()n.option=nil
local e=c(n)if e==''then
setDefault()o.commit(n)end
end
local function l()local e={}i.sectionname="interface"o.foreach_on_uci(i,function(n)if n.proto and n.proto=="6rd"then
e[#e+1]=n[".name"]end
end)return e
end
local function u(n)return d:call("network.interface."..n,"status",{})end
function e.uci_nud_get(e)n.option=e
return c(n)end
function setOnUci(i,e,o)n.option=i
a(n,e,o)t=true
end
function e.uci_nud_set(o,t,r)if o=="enable"then
e.clear_ping_results()if t=="1"then
local e
local o=l()for n,o in ipairs(o)do
local n=u(o)if n and not n.dynamic then
i.sectionname=o
i.option="peeraddr"e=c(i)elseif n and n["ipv6-address"]and n["ipv6-address"][1]then
e=n["ipv6-address"][1]["address"]or""end
end
if e then
n.option="host"setOnUci("host",e,r)end
end
end
setOnUci(o,t,r)end
function e.uci_nud_commit()if t then
o.commit(n)t=false
end
end
function e.uci_nud_revert()if t then
o.revert(n)t=false
end
end
return e