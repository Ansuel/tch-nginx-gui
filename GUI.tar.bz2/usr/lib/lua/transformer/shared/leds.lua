local o,e=io.open,string
local g=e.match
local f=require("lfs")local e=require("transformer.mapper.ucihelper")local t={}local h="/sys/class/leds/"local function c(e)local e=f.attributes(e,"mode")if e and e=="directory"then
return true
end
return false
end
local function u(a,r,d)local e=""local l,n,i
if a then
l=t.getLedStatus(a.trigger,a.brightness)end
if r then
n=t.getLedStatus(r.trigger,r.brightness)end
if d then
i=t.getLedStatus(d.trigger,d.brightness)end
if l=="Blinking"or n=="Blinking"or i=="Blinking"then
e="Blinking"elseif l=="Netdev"or n=="Netdev"or i=="Netdev"then
e="Netdev"elseif l=="On"or n=="On"or i=="On"then
e="On"else
e="Off"end
return e
end
function t.getLedStatus(n,t)local e=""if n=="none"then
if t==0 then
e="Off"else
e="On"end
elseif n=="default-on"then
e="On"elseif n=="pattern"or n=="timer"then
e="Blinking"elseif n=="netdev"then
e="Netdev"end
return e
end
local function m(n,e,t)local r,d,l
if n~=nil then
r=n.brightness
end
if e~=nil then
d=e.brightness
end
if t~=nil then
l=t.brightness
end
local e="None"local t,n,i=false,false,false
if r~=nil and r>0 then
t=true
end
if d~=nil and d>0 then
n=true
end
if l~=nil and l>0 then
i=true
end
if t and n and i then
e="White"elseif t and n then
e="Orange"elseif t and i then
e="Magenta"elseif t then
e="Red"elseif n and i then
e="Cyan"elseif n then
e="Green"elseif i then
e="Blue"end
return e
end
function t.getLedLevel(n,e)if n==nil or type(n)~="number"then
return 100
end
if e==nil or type(e)~="number"then
return 100
end
return(n/e)*100
end
local function b(i,r,e)local a,s,d
local l=0
local n=0
if i then
a=t.getLedLevel(i.brightness,i.max_brightness)l=l+1
n=n+a
if((r==nil or r.brightness==0)and(e==nil or e.brightness==0))then
return a.."%"end
end
if r then
s=t.getLedLevel(r.brightness,r.max_brightness)l=l+1
n=n+s
if((i==nil or i.brightness==0)and(e==nil or e.brightness==0))then
return s.."%"end
end
if e then
d=t.getLedLevel(e.brightness,e.max_brightness)l=l+1
n=n+d
if((r==nil or r.brightness==0)and(i==nil or i.brightness==0))then
return d.."%"end
end
local e=n/l
return e.."%"end
function t.getLedsInfo()local e={}if not c(h)then
return e
end
for n in f.dir(h)do
local i=g(n,"(.+):")local l=g(n,":(.+)")if i and l then
if e[i]==nil then
e[i]={}end
e[i][l]={}local r=h..n
if f.attributes(r,"mode")=="directory"then
local n=o(r.."/trigger","r")if not n then
break
end
local t=n:read("*all")if t then
local n=g(t,"%[(.+)%]")if n then
e[i][l].trigger=n
end
end
n:close()n=o(r.."/brightness","r")if not n then
break
end
t=n:read("*all")if t then
local n=tonumber(t)if n then
e[i][l].brightness=n
end
end
n:close()n=o(r.."/max_brightness","r")if not n then
break
end
t=n:read("*all")if t then
local n=tonumber(t)if n then
e[i][l].max_brightness=n
end
end
n:close()end
end
end
for d,l in pairs(e)do
local i,n,t
for r,e in pairs(l)do
if r=="red"then
i=e
elseif r=="green"then
n=e
elseif r=="blue"then
t=e
elseif r=="white"and l["red"]==nil and l["green"]==nil and l["blue"]==nil then
i=e
n=e
t=e
end
end
local l=m(i,n,t)local r=u(i,n,t)local n=b(i,n,t)e[d].mixColor=l
e[d].mixStatus=r
e[d].mixBrightness=n
end
return e
end
return t