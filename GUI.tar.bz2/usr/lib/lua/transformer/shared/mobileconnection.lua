local a=ipairs
local o=require("transformer.mapper.ubus").connect()local t={}local function r(t)local n={}local e=o:call("mobiled","status",{})if type(e)=="table"then
local e=tonumber(e.devices)if e and e>=1 then
for e=1,e do
local e=o:call("mobiled.network","sessions",{dev_idx=e})if e and e.sessions then
for o,e in a(e.sessions)do
if e.interface==t and e.session_state=="connected"then
n.proto=e.proto
if e.proto and type(e[e.proto])=="table"then
n.ipv4_addr=e[e.proto].ipv4_addr
n.ipv6_addr=e[e.proto].ipv6_addr
end
return n
end
end
end
end
end
end
return n
end
function t.get_network_interface(n)local e=r(n)if e.proto=="dhcp"then
e.interface=n.."_4"e.interface6=n.."_6"elseif e.proto=="ppp"then
e.interface=n.."_ppp"end
return e
end
return t