local a,t=io.popen,string
local n,e,i,e,e,e=t.match,t.find,math.floor,t.len,t.sub,t.format
local r=require("transformer.mapper.ubus").connect()local e=t.upper
local d=require("lfs")local f=io.open
local e=require("transformer.mapper.ucihelper")local s=e.get_from_uci
local c=e.foreach_on_uci
local e=require("modgui")local o=e.getRightLoggerModule()local e={}local l
function e.getBoardtype()if l then
return l
end
local n
local e=s({config="env",sectionname="rip",option="sfp"})if e=='1'then
e=true
else
e=false
end
local t=true
local r=io.open("/bin/pspctl","r")if not r then
t=false
else
r:close()end
if t and e then
n="gpon_sfp"elseif t and not e then
n="gpon"elseif not t and e then
n="sfp"else
n="none"end
l=n
return n
end
local s={TransmitOpticalLevel="US_TX_Power",OpticalSignalLevel="DS_Rx_RSSI"}local l={gpon={LowerOpticalThreshold="-29000",UpperOpticalThreshold="-7000",LowerTransmitPowerThreshold="-500",UpperTransmitPowerThreshold="6000",},p2p={LowerOpticalThreshold="-33000",UpperOpticalThreshold="0",LowerTransmitPowerThreshold="-10000",UpperTransmitPowerThreshold="-2700",},none={LowerOpticalThreshold="-127500",UpperOpticalThreshold="-127500",LowerTransmitPowerThreshold="-63500",UpperTransmitPowerThreshold="-63500",},}function e.getUbusObject()local e=e.getBoardtype()local n
if e=="sfp"then
n="optical"elseif e=="gpon"or e=="gpon_sfp"then
n="gpon"end
return n
end
function e.getTrsvInfo(n,l)local e=e.getUbusObject()if e then
e=t.format("%s.trsv",e)else
o:error("No ubus call for trsv is provided\n")return nil
end
local e=r:call(e,"get_info",{info=n})if e==nil then
o:error(t.format("Cannot retrieve trsv info %s\n",n))return nil
end
local e=e[n]local n,n="",""for e,n in pairs(e)do
e=e:match("[%S]+")if(e==l)then
return n
end
end
end
function e.getWanconf(n)local e=e.getUbusObject()if e then
e=t.format("%s.wanconf",e)else
o:error("No ubus call for wanconf is provided\n")return nil
end
local e=r:call(e,"get",{})if e==nil then
o:error("Cannot retrieve wanconf info\n")return nil
end
local e=e["WanConf"]local t,t="",""for t,e in pairs(e)do
if(t==n)then
return e
end
end
end
function e.getVendorName()local e=e.getTrsvInfo("vendor","Name")return e or""end
function e.getLevel(n)local t=s[n]if t then
local e=e.getTrsvInfo("status",t)if e and e~=""then
e=tonumber(e)e=e and i(e*1000)or 0
else
return"0"end
if n=="OpticalSignalLevel"then
return e<=-65536 and"-65536"or e>=65534 and"65534"or tostring(e)elseif n=="TransmitOpticalLevel"then
return e<=-127500 and"-127500"or e>=0 and"0"or tostring(e)end
end
return"0"end
function e.getLinkStatus()local e=e.getTrsvInfo("status","DS_Rx_RSSI")local n="unknown"e=tonumber(e)if e then
if e==-255. then
n="unplug"elseif e>=-99. and e<=-35. then
n="plugin"elseif e>-35. then
n="linkup"end
end
return n
end
function e.getThresholdValues(n)local e=e.getWantype()if e=="xepon_ae_p2p"then
return l["p2p"][n]elseif e=="gpon"or e=="xepon_ae"then
return l["gpon"][n]else
return l["none"][n]end
end
function e.getEnable()local e=e.getTrsvInfo("control","US_TX_Control")if e=="Disabled"then
e="0"elseif e=="Enabled"then
e="1"end
return e or""end
function e.setEnable(a)local l=e.getUbusObject()if l then
l=t.format("%s.trsv",l)else
o:error("No ubus call for trsv is provided\n")return""end
local n=e.getEnable()if n~=a then
if a=="1"then
n=true
elseif a=="0"then
n=false
end
r:call(l,"set_ustx",{enable=n})local e=e.getBoardtype()if e=="sfp"then
if not n then
r:send("sfp",{status="tx_disable"})else
r:send("sfp",{status="tx_enable"})end
end
end
end
function e.getGponstate()local t=a("gponctl getstate")local e=t:read("*a")t:close()local t="LowerLayerDown"if e and e~=""then
if n(e,"%(O5%)")then
t="Up"elseif n(e,"%(O1%)")then
t="Dormant"end
end
return t
end
function e.getWantype()local t="unknown"local n=e.getWanconf("WAN Type")if n then
if n=="GBE"then
local e=e.getWanconf("WAN EMAC")if e then
if e=="EPONMAC"then
t="xepon_ae"else
t="gbe"end
end
elseif n=="AE"or n=="ETH_WAN"then
t="gbe"elseif n=="XGS"or n=="XGPON1"or n=="GPON"then
t="gpon"elseif n=="SFP_GPON"then
t="xepon_ae"elseif n=="SFP_P2P"then
t="xepon_ae_p2p"end
end
return t
end
local o={config="ethernet",sectionname="port"}function e.getWanInterface()local e
c(o,function(n)if n.wan=="1"then
e=n[".name"]return false
end
end)return e
end
function e.getP2pState()local e=r:call("network.interface.wan","status",{})or{}local e=e["up"]if e==true then
return"up"end
return"LowerLayerDown"end
function e.getSfpState()local t="LowerLayerDown"local e=e.getSFPInfo("state")if e~=""then
if n(e,"%(O5%)")then
t="Up"elseif n(e,"%(O1%)")then
t="Dormant"end
end
return t
end
function e.getStatus()local r="Unknown"local t=e.getLinkStatus()if n(t,"unplug")then
return"NotPresent"elseif n(t,"plugin")then
local e=e.getEnable()if e=="0"then
return"Down"end
return"Dormant"elseif n(t,"linkup")then
local n=e.getEnable()if n=="0"then
return"Down"end
local n=e.getWantype()if n=="xepon_ae"then
return e.getSfpState()elseif n=="xepon_ae_p2p"then
return e.getP2pState()elseif n~="unknown"then
return e.getGponstate()end
end
return r
end
function e.getSFPInfo(n)local e=e.getLinkStatus()if e=="linkup"then
local e=a("sfp_get.sh --"..n)local n=e:read("*a")e:close()return n or""else
return""end
end
local o={BytesSent="bytes_sent",BytesReceived="bytes_rec",PacketsSent="packets_sent",PacketsReceived="packets_rec",ErrorsSent="errors_sent",ErrorsReceived="errors_rec",DiscardPacketsSent="discardpackets_sent",DiscardPacketsReceived="discardpackets_rec",}local function l(t,e)local e=n(t,e..":%s+(.-)%c")return e or"0"end
function e.getPonAeStats(n)local e=e.getSFPInfo(o[n])if e==""then
return"0"end
return l(e,n)end
local r={BytesSent="tx_bytes",BytesReceived="rx_bytes",PacketsSent="tx_packets",PacketsReceived="rx_packets",ErrorsSent="tx_errors",ErrorsReceived="rx_errors",DiscardPacketsSent="tx_dropped",DiscardPacketsReceived="rx_dropped",}function e.getIntfstats(e,n)local t=t.format("/sys/class/net/%s/statistics/",e)n=r[n]local e
if d.attributes(t,"mode")=="directory"then
local n=t..n
local n=f(n,"r")if n then
e=n:read("*all")if e then
e=e:match("(.-)%c")end
n:close()end
end
return e or"0"end
function e.getGponstats(n)return e.getIntfstats("gpondef",n)end
function e.getP2pStats(t)local n=e.getWanInterface()return e.getIntfstats(n,t)end
function e.getPonAeAllStats()local n={}local t=e.getSFPInfo("allstats")for e in pairs(o)do
if t==""then
n[e]="0"else
n[e]=l(t,e)end
end
return n
end
function e.getGponAllStats()local n={}for t in pairs(r)do
n[t]=e.getIntfstats("gpondef",t)end
return n
end
function e.getP2pAllStats()local o=e.getWanInterface()local n={}for t in pairs(r)do
n[t]=e.getIntfstats(o,t)end
return n
end
function e.getStats(n)local t=e.getWantype()if t=="xepon_ae"then
return e.getPonAeStats(n)elseif t=="xepon_ae_p2p"then
return e.getP2pStats(n)elseif t=="gpon"then
return e.getGponstats(n)end
return"0"end
function e.getAllStats()local n=e.getWantype()if n=="xepon_ae"then
return e.getPonAeAllStats()elseif n=="xepon_ae_p2p"then
return getP2pAllStats()elseif n=="gpon"then
return e.getGponAllStats()end
return"0"end
function e.getCrossbarStatus()local e=a("cat /proc/ethernet/crossbar_status")local n=e:read("*a")e:close()return n
end
function e.getPortStatus(t)local e=""local r=a("ethctl eth4 media-type port "..t.." 2>&1")local t=r:read("*a")r:close()if t then
if n(t,"Link is up")then
e="Up"else
e="Down"end
end
return e
end
function e.getGPHY4LinkStatus()return e.getPortStatus(10)end
function e.getSfpLinkStatus()return e.getPortStatus(9)end
function e.getWanType()local e=e.getCrossbarStatus()local t=""if e then
if n(e,"WAN Port is connected to: AE")then
t="SFP"elseif n(e,"WAN Port is connected to: GPHY4")then
t="GPHY4"end
end
return t
end
function e.getGPHY4Mode()local t=e.getCrossbarStatus()local e=""if t then
if n(t,"Switch Port %d is connected to: GPHY4")then
e="Lan"else
e="Wan"end
end
return e
end
function e.resetStatsGponSFP()os.execute("sfp_get.sh --counter_reset")end
return e