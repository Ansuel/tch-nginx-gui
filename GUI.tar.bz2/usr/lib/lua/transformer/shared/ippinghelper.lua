local o={}local t=io.open
local e=require("modgui")local a=e.getRightLoggerModule()local n=require("transformer.mapper.ucihelper")local s=string.match
local u,d=pairs,os.remove
local e=require("transformer.mapper.nwcommon")local f={SuccessCount=1,FailureCount=2,MinimumResponseTime=3,AverageResponseTime=4,MaximumResponseTime=5,IPAddressUsed=6,}local i={}local c={}local r={}local p=0
local e={}local function l(e,o,i)n.set_on_uci(e,o,i)c[e.config]=true
end
function o.clear_ping_results(e)d("/tmp/ipping_"..e)d("/tmp/ping_"..e)i[e]={}end
function o.read_ping_results(e,n)if(n~=nil)then
local c=f[n]if i[e]then
if i[e][c]then
return i[e][c]end
end
local n={}if p~=0 then return"0"end
local o,t=t("/tmp/ipping_"..e)if not o then
a:debug("ping results not found: "..t)return"0"end
for e in o:lines()do
n[#n+1]=e
end
o:close()i[e]=n
return n[c]else
return nil
end
end
function o.read_ping_trace_results(e)if e~="diagping"and e~="webui"then
return nil,"Ping traces valid only for Diagping or Webui"end
local n,e=t("/tmp/ping_"..e)if not n then
a:debug("ping results not found: "..e)return nil,e
end
local i={}for r in n:lines()do
local e,c,t,o,n=s(r,"(%d+) bytes from (%S+)%: seq=(%d+) ttl=(%d+) time=(%d*.%d*) ms")if e==nil then
e,c,t,o=s(r,"(%d+) bytes from (%S+)%: seq=(%d+) ttl=(%d+)")n="0"end
if e then
i[#i+1]={Bytes=e,IP=c,Seq=t,TTL=o,Time=n}end
end
n:close()return i
end
function o.startup(i,o)e[i]=o
local o=t("/etc/config/ipping")if not o then
o=t("/etc/config/ipping","w")if not o then
error("could not create /etc/config/ipping")end
o:write("config user '"..i.."'\n")o:close()n.set_on_uci(e[i]["Timeout"],10000)n.set_on_uci(e[i]["DataBlockSize"],56)n.set_on_uci(e[i]["DSCP"],0)n.set_on_uci(e[i]["ProtocolVersion"],"IPv4")if i=="webui"then
n.set_on_uci(e[i]["NumberOfRepetitions"],4)else
n.set_on_uci(e[i]["NumberOfRepetitions"],3)end
else
local o=n.get_from_uci({config="ipping",sectionname=i})if o==''then
n.set_on_uci({config="ipping",sectionname=i},"user")n.set_on_uci(e[i]["Timeout"],10000)n.set_on_uci(e[i]["DataBlockSize"],56)n.set_on_uci(e[i]["DSCP"],0)n.set_on_uci(e[i]["ProtocolVersion"],"IPv4")if i=="webui"then
n.set_on_uci(e[i]["NumberOfRepetitions"],4)else
n.set_on_uci(e[i]["NumberOfRepetitions"],3)end
end
end
n.set_on_uci(e[i]["DiagnosticsState"],"None")n.commit({config="ipping"})return i
end
function o.uci_ipping_get(i,s)local c
local t="ipping"if not e[i]then
e[i]={DiagnosticsState={config=t,sectionname=i,option="state"},Interface={config=t,sectionname=i,option="interface"},Host={config=t,sectionname=i,option="host"},NumberOfRepetitions={config=t,sectionname=i,option="count"},Timeout={config=t,sectionname=i,option="timeout"},DataBlockSize={config=t,sectionname=i,option="size"},DSCP={config=t,sectionname=i,option="dscp"},ProtocolVersion={config=t,sectionname=i,option="iptype"},}end
if e[i][s]then
c=n.get_from_uci(e[i][s])if s=="DiagnosticsState"and c=="InProgress"then
c="Requested"end
else
c=o.read_ping_results(i,s)end
return c
end
function o.uci_ipping_set(i,c,o,t)if c=="DiagnosticsState"then
if o~="Requested"and o~="None"then
return nil,"invalid value"end
r[i]=true
l(e[i]["DiagnosticsState"],o,t)l(e[i][c],o,t)else
local n=n.get_from_uci(e[i]["DiagnosticsState"])if(n~="Requested"and n~="None")then
l(e[i]["DiagnosticsState"],"None",t)end
l(e[i][c],o,t)end
end
function o.uci_ipping_commit()for e in u(r)do
o.clear_ping_results(e)end
r={}for e in u(c)do
local e={config=e}n.commit(e)end
c={}end
function o.uci_ipping_revert()r={}for e in u(c)do
local e={config=e}n.revert(e)end
c={}end
return o