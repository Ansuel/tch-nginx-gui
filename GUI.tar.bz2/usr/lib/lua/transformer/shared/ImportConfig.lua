local n=require("transformer.shared.ConfigCommon")local e=string.format
local r,i=io.open,io.stderr
local l=os.execute
local function o(t,...)local e=e(t,...)i:write('*error: ',e,'\n')return{e}end
local function i(l,t)local e
if t and(t~='-')then
local n
e,n=r(t,'w')if not e then
o("failed to open statefile %s: %s",t,n or'???')e=io.stdout
end
else
e=io.stdout
end
for o,t in pairs(l)do
e:write(o,"=",t,"\n")end
e:close()end
local function r(t,r)local e=n.export_init("")e.filename=t
e.state="Requested"n.import_start(e)local n=1
local a=5
local t=0
repeat
l("sleep "..n)t=t+n
if e.state~="Requested"then
break
end
until(t>=a)if e.state~="Complete"then
if e.state=="Requested"then
o("Timeout when import the config file")return 1
else
o('Import config error (state="%s", info="%s")',e.state,e.info or"")return 1
end
end
i({REBOOT="1"},r)return 0
end
os.exit(r(...)or 0)