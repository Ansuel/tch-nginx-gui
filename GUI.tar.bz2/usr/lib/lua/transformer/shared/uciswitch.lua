local n=require
local s=setmetatable
local i=loadstring
local c=pairs
local o=ipairs
local l=type
local u=pcall
local r=table.remove
local d=table.concat
local a=n'io'local e=n'transformer.mapper.ucihelper'local n=n("modgui")local h=n.getRightLoggerModule()local f={}local function t(e)local l
local n,e=a.open(e,"r")if n then
l=n:read("*a")n:close()else
e="open failed: "..e
end
return l,e
end
local function a(n)local o,e=t(n)if o then
local n,o=i(o,n)if n then
local o,n=u(n)if o then
if l(n)=='table'then
return n
else
e="config map must be a table"end
else
e="load failure: "..n
end
else
e="syntax error: "..o
end
end
return nil,e
end
local n={}n.__index=n
local function t(n,e)h:error("[%s] %s",n._configname,e)end
local function i(e,n)local n,a=a(n)if a then
t(e,a)end
n=n or{}local a={}for o,n in o(n)do
if l(n)~='table'then
t(e,"all entries in the config map must be tables")break
end
n.switcher=e
if n.execute~=false then
a[#a+1]=n
end
end
e._action_map=a
end
local function a(l,e)local e={_commitapply=e,_configname=l}s(e,n)i(e,l)return e
end
function f.switcher(e,n)if e then
return a(e,n)end
end
local function s(l)local n
local o={state=false,config=l.config,}if l.section then
o.sectionname=l.section
n=e.getall_from_uci(o)if not n['.name']then
n=nil
end
elseif l.section_where then
local l=l.section_where
o.sectionname=l['.type']e.foreach_on_uci(o,function(e)for l,o in c(l)do
if e[l]~=o then
return
end
end
n=e
return false
end)end
return n
end
local function a(n,l,a)local o={config=n['.config'],sectionname=n['.name'],state=false,}for l,t in c(l)do
if not l:match("^%.")then
o.option=l
e.set_on_uci(o,t,a)n[l]=t
end
end
end
local function i(l,o)local t=l.config
local n=l.section_where['.type']if n then
local e=e.add_on_uci({config=t,sectionname=n},o)local e={['.config']=t,['.type']=n,['.name']=e,['.anonymous']=true}a(e,l.section_where,o)return e
end
end
local function u(n,t)local o=n.config
local l=n.section
local n=n.add['.type']if not n then
return
end
e.set_on_uci({config=o,sectionname=l,state=false},n,t)return{['.config']=o,['.type']=n,['.name']=l,}end
local function m(e,o)local t=e.add
if l(t)~='table'then
return nil,"add must be a table"end
local n
if e.section then
n=u(e,o)elseif e.section_where then
n=i(e,o)end
if n then
a(n,t,o)end
return n
end
local function i(n)local e=s(n)if e then
e['.config']=n.config
end
return e
end
local function a(n,l)for e=1,#n do
if n[e]==l then
return e
end
end
end
local function h(e,n)if not n then
return e
end
local n=a(e,n)if n then
r(e,n)end
return e
end
local function s(e,n)if not n then
return e
end
local l=a(e,n)if not l then
e[#e+1]=n
end
return e
end
local function r(n)local e
e={}if l(n)=='table'then
return n
end
for n in n:gmatch("%S+")do
e[#e+1]=n
end
return e
end
local function u(l,e,n)local e=l[e]or''local l=n.set
if l then
return l
else
e=r(e)e=h(e,n.del)e=s(e,n.add)return d(e," ")end
end
local function s(a,i,c,f)local r=false
for n,o in o(c)do
local n=o[1]local o=o[i]if not(o and n)then
return false
end
if l(o)~="table"then
t(c.switcher,i.." must be a table")return false
end
local l=u(a,n,o)local n={config=a['.config'],sectionname=a['.name'],option=n,state=false,}e.set_on_uci(n,l,f)r=true
end
return r
end
local function d(a,e,n)local o=false
local l=i(e)if not l then
if e.add then
if n then
local n
l,n=m(e,a._commitapply)if n then
t(a,n)end
else
o=true
end
end
end
return l,o
end
local function l(n)local e=n._configs_changed
if not e then
e={}n._configs_changed=e
end
return e
end
function n:enable(e)e=(e==nil)and true or e
local a=e and"enable"or"disable"local t=self._action_map
local c=l(self)local n=false
for o,l in o(t)do
local e,o=d(self,l,e)if e then
if s(e,a,l,self._commitapply)then
c[e['.config']]=true
n=true
end
elseif o then
n=true
else
return false
end
end
return n
end
local function t(e,t)local o={}local n=l(e)for e in c(n)do
o.config=e
t(o)n[e]=nil
end
end
function n:commit()t(self,e.commit)end
function n:revert()t(self,e.revert)end
local function l(e,n)local e=r(e)return a(e,n)~=nil
end
local function t(o,e)local n=e[1]local e=e.enable
if e then
local n=o[n]or""if e.set then
return n==e.set
elseif e.add then
return l(n,e.add)elseif e.del then
return not l(n,e.del)else
return false
end
end
return true
end
function n:isEnabled()local n=false
for e,l in o(self._action_map)do
local e=i(l)if not e then
return false
end
for o,l in o(l)do
if not t(e,l)then
return false
end
n=true
end
end
return n
end
return f