local e=require
local t=setmetatable
local r=pairs
local o=e"lfs"local l=e"transformer.mapper.ucihelper"local n={}n.__index=n
local function c(e)return o.attributes("/etc/config/"..e,"modification")end
function n:load(e)self._configs[e]=c(e)local o={_all={}}l.foreach_on_uci({config=e,state=false},function(e)local n=e['.type']local a=e['.name']local l=n:match("^([^_]+)_placeholder")if l then
n=l
e['.placeholder']=true
end
local l=o[n]if not l then
l={}o[n]=l
end
local n=o._all
l[#l+1]=e
l[a]=e
n[#n+1]=e
n[a]=e
end)return o
end
function n:config_changed()local e=false
for l,n in r(self._configs)do
if n<c(l)then
e=true
break
end
end
return e
end
local e={}function e.Loader()return t({_configs={}},n)end
return e