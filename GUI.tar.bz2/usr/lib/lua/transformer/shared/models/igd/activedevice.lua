local e=require
local a=type
local o=ipairs
local n={}local c=e"transformer.mapper.ucihelper"local r=e("transformer.mapper.ubus").connect()local l={config="wanconfig",sectionname="activedevice"}function n.getActiveDevices()local n={}c.foreach_on_uci(l,function(e)n[#n+1]=e['.name']end)return n
end
local function t(n)local e,n=n:match("^([^:]+):?(.*)$")return{ifname=e,config=n~=""and n or"ip,ppp"}end
local function i(e)local n={}if a(e)=="table"then
for c,e in o(e)do
n[#n+1]=t(e)end
elseif e and e~=""then
n[#n+1]=t(e)end
return n
end
local t={config="wanconfig"}local function a(a)local e={}t.sectionname=a
t.option="interface"local c=c.get_from_uci(t)for c,n in o(i(c))do
e[#e+1]=n.ifname
end
return e
end
n.getActiveInterfaces=a
function n.getDevtypeAndName(n)local n=a(n)local n=n[1]if n then
local n=r:call("network.interface."..n,"status",{})local n=n and n.device
if n then
local e=c.get_from_uci{config="xtm",sectionname=n}if e~=""then
return"DSL","dsl0"end
return"ETH",n
end
end
end
local function t(t)local n
c.foreach_on_uci(l,function(e)local e=i(e.interface)for c,e in o(e)do
if e.ifname==t then
n=e.config
end
end
if n then return false end
end)return n or""end
function n.isActiveInterface(n)return t(n)~=""end
local function c(e,n)for e in e:gmatch("([^,]+)")do
if e==n then
return true
end
end
return false
end
local function e(e,n)local e=t(e)return c(e,n)end
function n.interfaceHasPPP(n)return e(n,"ppp")end
function n.interfaceHasIP(n)return e(n,"ip")end
return n