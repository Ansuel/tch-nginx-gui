local e=require
local a={}local n=e'transformer.shared.models.igd.activedevice'function a.getDevtypeAndName(e)local t,e=e:match("^([^|]*)|(.*)$")e=e:match("^([^|]+)")if t=="ACTIVE"then
t,e=n.getDevtypeAndName(e)end
return t,e
end
return a