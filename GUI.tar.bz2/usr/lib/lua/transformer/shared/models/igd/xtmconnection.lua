local e=require
local u,v=string.match,string.lower
local a={}local f=e("transformer.shared.models.xdsl")local m=e("transformer.shared.models.dmordering")local n=e("transformer.mapper.nwcommon")local c=e("transformer.shared.models.uciconfig").Loader()local s=n.split_key
local r={}local i={}local o="NONE"local t={}local d
local n={["ATM"]=true,["PTM"]=true,["NONE"]=true}local function l()return#t~=0
end
local function h()if not l()then
return false
end
local e=f.mode()if e~=o then
if n[e]and e~="NONE"then
o=e
return true
else
o="NONE"end
end
return false
end
local function N(a)local n={}local l=0
local e={active=1,inactive=2}for t,e in ipairs(a)do
n[#n+1]=e
end
l=#n
if l==0 then
return
end
if u(n[e.active],v(o))or o=="NONE"or l==1 then
i[t[e.active]]=n[e.active]i[t[e.inactive]]=n[e.inactive]else
i[t[e.active]]=n[e.inactive]i[t[e.inactive]]=n[e.active]end
n[e.active]=t[e.active]n[e.inactive]=n[e.inactive]and t[e.inactive]r=n
return r
end
local function v(r,t)if not t then
return r
end
local e={}local n={}for t,n in ipairs(r)do
local r,t=s(n)e[t]=n
end
for r,t in ipairs(t)do
if e[t]then
n[#n+1]=e[t]e[t]=nil
end
end
for r,t in ipairs(r)do
local r,t=s(t)if e[t]then
n[#n+1]=e[t]end
end
return n
end
local e=false
local function s()if not e then
c:load("xtm")local e=c:load("dmordering")d=m.getOrder("xtmdevice")if e.fixedkey then
t=e.fixedkey.xtmdevicekeys.devicekey
end
if l()then
o=f.mode()end
end
return true
end
local function t()local n=false
if c:config_changed()then
e=false
n=s()end
if h()then
return true
end
return n
end
function a.loadStatic_keys(n)s()if not d then
e=true
return n
end
if e and not t()then
return r
end
e=true
r=v(n,d)if not l()then
return r
end
return N(r)end
function a.resolve_key(e)return i[e]or e
end
function a.get_static_key(e)if not l()then
return e
end
for t,n in pairs(i)do
if u(n,e)then
return t
end
end
return e
end
return a