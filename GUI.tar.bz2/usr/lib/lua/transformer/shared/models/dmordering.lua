local n=require
local e=ipairs
local r=type
local t=n("transformer.shared.models.uciconfig").Loader()local l={}local o
local function a(n)local o={}for e,n in e(n.ordering or{})do
local e=n.name or n['.name']local n=n.order
if r(n)=='string'then
n={n}end
o[e]=n
end
return o
end
local function r(n)return n.type and n.name and n.linkto
end
local function i(n)local o={}for e,n in e(n.link or{})do
if r(n)then
local e=o[n.type]or{byname={},bytarget={}}e.byname[n.name]=n.linkto
local l=e.bytarget[n.linkto]or{}l[#l+1]=n.name
e.bytarget[n.linkto]=l
o[n.type]=e
end
end
return o
end
local function r()if not o or t:config_changed()then
local n=t:load("dmordering")o={orderings=a(n),links=i(n),}end
end
local function a(l,r)local n={}local o={}for e,n in e(l)do
o[n]=true
end
for l,e in e(r)do
if o[e]then
n[#n+1]=e
o[e]=false
end
end
for l,e in e(l)do
if o[e]then
n[#n+1]=e
end
end
return n
end
local function t(n)r()return o.orderings[n]end
l.getOrder=t
function l.sort(n,e)local e=t(e)if e then
n=a(n,e)end
return n
end
function l.linked(n,e)r()local n=o.links[n]if n then
return n.byname[e]end
end
function l.linksTo(l,n)r()local o=o.links[l]or{bytarget={}}local o=o.bytarget[n]or{}local n={n}if o then
for o,e in e(o)do
n[#n+1]=e
end
end
return n
end
return l