local e=require
local l=ipairs
local a=unpack
local t=setmetatable
local p=tostring
local f=e'os'local i={}local d=e'transformer.mapper.ucihelper'local o=e('transformer.mapper.ubus').connect()local e=e'transformer.mapper.nwcommon'local s=e.netmask2mask
local n={config="network",sectionname="interface"}local function u()local e={}d.foreach_on_uci(n,function(n)e[n['.name']]=n
end)return e
end
local n={}n.__index=n
local function c()return t({},n)end
i.UbusInterfaceData=c
local function t()local e=o:call("network.interface","dump",{})for o,n in l(e.interface)do
e[n.interface]=n
end
return e
end
function n:load()local e=self._ubus_data
if not e then
e=t()self._ubus_data=e
end
return e
end
local function t()local e=o:call("mobiled.network","sessions",{})if e then
e.interface={}e.sessions=e.sessions or{}for o,n in l(e.sessions)do
if n.session_state=='connected'and n.interface then
e.interface[n.interface]=n
end
end
else
e={sessions={},interface={}}end
return e
end
function n:load_mobile()local e=self._ubus_mobile_data
if not e then
e=t()self._ubus_mobile_data=e
end
return e
end
function n:get(e)local n=self:load()return n[e]end
local _={proto='static',ipaddr='0.0.0.0',}local n={static={'ipv4','static'},dhcp={'ipv4','dynamic'},pppoe={'ipv4','dynamic'},pppoa={'ipv4','dynamic'},dhcpv6={'ipv6','dynamic'},['6rd']={'ipv6','dynamic'},mobiled={'mobiled','dynamic'}}local e={"unknown","unknown"}local function r(o)return a(n[o]or e)end
local function t(n,e)local e=e:get(n)local e=e and e['ipv4-address']or{}local e=e[1]if e then
return e.address,s(e.mask)end
end
local function h(o,n,l,a)local e={ifname=o,proto=n.proto,disabled_info=n.disabled_info,}if l=="static"then
e.ipaddr=n.ipaddr or'0.0.0.0'e.netmask=n.netmask
elseif l=="dynamic"then
local o,n=t(o,a)e.ipaddr=o
e.netmask=n
end
return e
end
local function s(o,l)local n=l:load_mobile()local e={ifname=o,mobile=true,ipaddr="",netmask="",proto="",}local n=n.interface[o]if n then
if n.proto=="static"then
e.ipaddr=n.static.ipv4_addr
e.netmask=n.static.ipv4_subnet
e.proto="static"elseif n.proto=="dhcp"then
e.proto="dhcp"e.ipaddr,e.netmask=t(o.."_4",l)elseif n.proto:match("^ppp")then
e.proto=n.proto
e.ipaddr,e.netmask=t(o.."_ppp",l)elseif n.proto=="router"then
e.proto="static"if type(n.router)=="table"then
e.ipaddr=n.router.ipv4_addr
end
end
end
return e
end
local function m(t,o,l,a)local e
local n,i=r(o.proto)if n=='ipv4'then
e=h(t,o,i,a)elseif n=='mobiled'then
e=s(t,a)end
l[#l+1]=e
end
local function t(e)local e=e and e['ipv4-address']e=e and e[1]return e and e.address=='127.0.0.1'end
local function s(e,l,o,n)local n=n:get(e)local e={ifname=e,}if t(n)then
e.ipaddr="::1"e.proto="wellknown"else
e.proto="local"e.ipaddr=""e.l3_device=n and n.l3_device
end
if l.proto=='mobiled'then
e.mobile=true
end
o[#o+1]=e
end
local o={"ipv6-address","ipv6-prefix-assignment"}local function a(n,e)local e=n:get(e)if e then
for o,n in l(o)do
local n=e[n]if n then
local n=n[1]if n then
return n,e.l3_device
end
end
end
end
end
local function t(n,l,t)local e,o
e,o=a(t,l)local l=e~=nil
if e then
local o=f.time()n.ipaddr=e.address
if e.preferred then
n.preferred=o+e.preferred
end
if e.valid then
n.valid=o+e.valid
end
end
n.l3_device=o
return l
end
local function v(e,n,o)local n={ifname=e,disabled_info=n.disabled_info,proto=n.proto,}t(n,e,o)return n
end
local function h(o,l)local n=l:load_mobile()local e={ifname=o,mobile=true,ipaddr="",}local n=n.interface[o]local a=true
if n then
if n.proto=="static"then
e.proto="static"a=t(e,o,l)elseif n.proto=="dhcp"then
e.proto="dhcp"a=t(e,o.."_6",l)elseif n.proto=="router"then
e.proto="static"if type(n.router)=="table"and n.router.ipv6_addr then
e=n.router.ipv6_addr
end
elseif n.proto:match("^ppp")then
e.proto=n.proto
a=t(e,o.."_ppp",l)end
end
if a then
return e
end
end
local function f(a,o,n,l)local t=r(o.proto)local e
if t=="ipv6"then
e=v(a,o,l)elseif t=="mobiled"then
e=h(a,l)end
n[#n+1]=e
end
local function a(n,e)local e=e:load_mobile()for o,e in l(e.sessions)do
if e.interface==n then
return p(e.profile)end
end
end
local function r(o)local n
d.foreach_on_uci({config='mobiled',sectionname='profile'},function(e)if e.id==o then
n=e
return false
end
end)return n
end
local function t(e,n)local e=a(e,n)local e=r(e)if e then
return e.pdptype or'ipv4v6'end
return'ipv4v6'end
local function p(e,l,a)local o
local n
if l.proto=='mobiled'then
local e=t(e,a)o=(e=='ipv4')or(e=='ipv4v6')n=(e=='ipv6')or(e=='ipv4v6')else
o=true
n=l.ipv6~="0"end
return o,n
end
function i.getAddrList(d)local o={}local e={}local r=u()local n=c()local t=d[1]local a=r[t]if not a then
return o,e
end
local c,i=p(t,a,n)if i then
s(t,a,e,n)end
for t,l in l(d)do
local t=r[l]or _
if c then
m(l,t,o,n)end
if i then
f(l,t,e,n)end
end
return o,e
end
return i