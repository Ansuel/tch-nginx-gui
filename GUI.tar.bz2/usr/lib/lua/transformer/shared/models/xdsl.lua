local c=require
local u=tonumber
local n=io.popen
local t=pcall
local o
local e={}local n="NONE"local function r()local o,e=t(c,"transformer.shared.xdslctl")local n
if o then
n=e.infoValue('tpstc')end
if not n then
return"NONE"end
return n:match("%S+")or"NONE"end
local l
local function i(e)if e~=n then
n,e=e,n
if l then
t(l,n,e)end
end
end
local function a(n)if u(n.statuscode)~=5 then
i("NONE")else
i(r())end
end
local function t()if not o then
o=c("transformer.mapper.ubus").connect()o:listen({xdsl=a})n=r()end
end
function e.mode()t()return n
end
function e.isADSL()t()return n=='ATM'end
function e.isVDSL()t()return n=='PTM'end
function e.main()if not o then
local e=c'uloop'e.init()l=function(n,e)print("xdsl changed from "..e.." to "..n)end
t()print("current mode is "..n)e.run()end
end
return e