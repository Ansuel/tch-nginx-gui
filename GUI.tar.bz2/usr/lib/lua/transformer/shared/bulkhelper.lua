local e=require
local u=setmetatable
local s=ipairs
local h=tostring
local i=string.format
local l=string.match
local p=table.insert
local m=table.remove
local o=table.sort
local n=e('transformer.mapper.ucihelper')local _=e('transformer.mapper.multiroot').duplicate
local t={__index=function()return""end}local e={}e.entries={}local a={}a.__index=a
local r={config="bulkdata",sectionname="profile"}local function d(e)return n.foreach_on_uci(r,e)end
local t=u({['0']='false',['1']='true',['true']='1',['false']='0'},t)local function r(n)return t[n]end
e.convert_boolean=r
local function t(e,o)local n=tonumber(l(e,".*_(%d+)$"))local e=tonumber(l(o,".*_(%d+)$"))return n<e
end
function a:getProfileKeys(n)self.keys={}e.entries={}d(function(n)self.keys[#self.keys+1]=n['.name']e.entries[n['.name']]=n
end)o(self.keys,t)return self.keys
end
function a:getParamKeys(n,o)self.keys={}if type(e.entries[o][n])=="table"then
for e,e in s(e.entries[o][n])do
local e=i("%s|%s|%d",o,n,#self.keys+1)self.keys[#self.keys+1]=e
end
end
return self.keys
end
local function r(t)local o,n=t:match("(.*)|.*|(.*)")if o and n then
n=tonumber(n)else
o=t
end
return e.entries[o]or{},n
end
function e.getall(e,o)local n={}local t,r=r(o)local o=e._profile.map.get
local a=e.objectType.parameters
for e in pairs(a)do
if(o[e])then
if type(o[e])=="function"then
n[e]=o[e](t)elseif type(o[e])=="table"then
if not n.Name or not n.Reference then
local e,o=l((t[o[e][1]]and t[o[e][1]][r])or"","(.*)|(.*)")n.Name=o or""n.Reference=e or""end
else
n[e]=t[o[e]]end
end
n[e]=n[e]or a[e].default or""end
return n
end
function e.get(t,e,n)local o,a=r(n)local n=t._profile.map.get
local t=t.objectType.parameters
if(n[e])then
if type(n[e])=="function"then
return n[e](o)elseif type(n[e])=="table"then
local n,o=l((o[n[e][1]]and o[n[e][1]][a])or"","(.*)|(.*)")if e=="Name"then
return o
else
return n
end
else
return o[n[e]]or t[e].default or""end
end
end
function e.set(e,o,a,t)local r,f=r(t)local t=e._profile.map.set
local c=e._profile.commitapply
local u=e._profile.transactions
local e={config="bulkdata"}e.sectionname=r['.name']if t[o]then
if type(t[o])=="function"then
local e,n=t[o](e,a)if not e then
return nil,n
end
elseif type(t[o])=="string"then
e.option=t[o]n.set_on_uci(e,a,c)elseif type(t[o])=="table"then
e.option=t[o][1]n.delete_on_uci(e,c)local t,l=l(r[e.option][f]or"","(.*)|(.*)")if o=="Name"then
l=a
else
t=a
end
r[e.option][f]=i("%s|%s",t or"",l or"")n.set_on_uci(e,r[e.option],c)end
u[e.config]=true
return true
else
return nil,"Invalid or not supported parameter"end
end
local function t(o)local n={}local e
d(function(o)e=tonumber(o['.name']:match("(%d+)$"))n[e]=e
end)return#n<o and i("profile_%d",#n+1)or nil
end
function e.add_profile(o,e)local e={config="bulkdata"}local l=o._profile.commitapply
local a=o._profile.transactions
e.sectionname="global"e.option="max_num_profiles"local o=n.get_from_uci(e)local o=t(tonumber(o))if o==nil then
return nil,"The profile's instance number has reached the maximize and can't add any new!"end
e.sectionname=o
e.option=nil
n.set_on_uci(e,"profile",l)a[e.config]=true
return e.sectionname
end
function e.delete_profile(o,l,e)local e={config="bulkdata"}local t=o._profile.commitapply
local o=o._profile.transactions
e.sectionname=l
e.option=nil
n.delete_on_uci(e,t)o[e.config]=true
return true
end
local function f(e,a,o)local t=e._profile.commitapply
local l=e._profile.transactions
local e={config="bulkdata"}e.sectionname=a
e.option=o
local o=n.get_from_uci(e)if type(o)~="table"then
o={"|"}else
p(o,"|")n.delete_on_uci(e,t)end
n.set_on_uci(e,o,t)l[e.config]=true
return h(#o)end
local function c(e,a,o,l)local t=e._profile.commitapply
local r=e._profile.transactions
local e={config="bulkdata"}e.sectionname=o
e.option=l
local o=n.get_from_uci(e)if type(o)~="table"then
return nil,"No elements!"end
local l=a:match(".*|.*|(.*)")m(o,tonumber(l))n.delete_on_uci(e,t)if#o>0 then
n.set_on_uci(e,o,t)end
r[e.config]=true
return true
end
function e.add_parameter(t)return function(l,o)if reference=="parameters"then
local e={config="bulkdata"}e.sectionname="global"e.option="max_num_parameters"local t=n.get_from_uci(e)e.sectionname=o
e.option=reference
local e=n.get_from_uci(e)if#e>=tonumber(t)then
return nil,"The parameter's instance number has reached the maximize and can't add any new!"end
end
local e=f(l,o,t)return i("%s|%s|%d",o,t,e)end
end
function e.delete_parameter(n)return function(e,o,t)return c(e,o,t,n)end
end
local function o(n,t)local e={}for o in pairs(n.transactions)do
e.config=o
t(e)end
n.transactions={}end
function e.commit(e)o(e._profile,n.commit)end
function e.revert(e)o(e._profile,n.revert)end
function e.register(e,n)local e=_(e,"#ROOT",{"InternetGatewayDevice","Device"})for o,e in s(e)do
n(e)end
end
function e.SetProfileMap(n,e,o)local e={map=e,commitapply=o,transactions={}}n._profile=u(e,a)return e
end
return e