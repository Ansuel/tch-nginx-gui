local e={time_entries={last_five_minutes={period_seconds=300},last_twenty_minutes={period_seconds=1200},last_hour={period_seconds=3600},last_twentyfour_hours={period_seconds=86400},last_week={period_seconds=604800},last_month={period_seconds=2678400},diff={},all={}}}local n=1
local i="/tmp/"local t,o
function e.getUptime(e)local e=e:call("system","info",{})if e then
return tonumber(e.uptime)end
end
function e.setSignalQualityDiffSinceUptime(e)t=e
end
function e.getSignalQualityDiffSinceUptime()return t
end
function e.setAlarmsDiffSinceUptime(e)o=e
end
function e.getAlarmsDiffSinceUptime()return o
end
function e.setDeviceIndex(e)n=tonumber(e)or 1
end
function e.getDeviceIndex()return n
end
local function r(e)if type(e)=='string'then return e end
if type(e)~='table'or type(e.info)~='table'then return nil end
return string.format("line=%d, name=%s",e.info.currentline,e.info.name or"?")end
local function o(e,n)e.state="Error"e.info=n or""end
function e.export_reset(e)e.state="None"e.info=""end
function e.export_init(t)local n={}e.export_reset(n)if t then
n.location=t
else
n.location=i
end
return n
end
local function i(e)local n
local t=require("ubus").connect()if not t then
return
end
e.info="writing export data"n=t:call("ltedoctor","export",{path=e.location..e.filename})if n and n.error then
o(e,string.format("write export data failed (%s)",r(n.error)or"?"))return
end
e.state="Complete"e.info="export succesfully completed"end
function e.export_start(e)if not e.filename or e.filename==""then
o(e,"invalid filename")return
end
i(e)end
return e