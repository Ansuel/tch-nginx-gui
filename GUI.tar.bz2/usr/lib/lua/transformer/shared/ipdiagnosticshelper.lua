local d={}local r=require'transformer.mapper.nwcommon'local n,l=string.match,string.format
local function s(e)if not n(e,"(%d+%.%d+%.%d+%.%d+)")then
local d=e and l("dnsget %s 2>&1",e)local l=assert(io.popen(d))local a
for d in l:lines()do
a=n(d,"([^%s]+)%.%s")if a then
e=n(d,"%s+(%d+%.%d+%.%d+%.%d+)")if e then
break
end
end
end
l:close()end
if e then
local e=l("ip route get %s 2>&1",e)local e=assert(io.popen(e))local d=e:read("*a")e:close()return n(d,"src%s+(%d+%.%d+%.%d+%.%d+)")end
end
function d.get_physical_interface(e,d)if e and e:len()~=0 then
local e=r.get_ubus_interface_status(e)local n=e and e["l3_device"]if not n then
return
end
local e=e['ipv4-address']and e['ipv4-address'][1]and e['ipv4-address'][1]['address']return n,e
else
return"",s(d)end
end
return d