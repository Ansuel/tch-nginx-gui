local c,t=string,pairs
local i={config="gre_hotspotd"}local n={config="wireless"}local r=require("transformer.mapper.ucihelper")local a=r.foreach_on_uci
local e={}function e.getAp(i)local t
n.sectionname="wifi-ap"a(n,function(e)n.sectionname=e['.name']if e.iface and i and c.match(e.iface,i)then
t=e['.name']return false
end
end)return t
end
local function o()local n={}i.sectionname="hotspot"a(i,function(e)i.sectionname=e['.name']if type(e.wifi_iface)=="string"then
n[#n+1]=e.wifi_iface
else
for a,e in t(e.wifi_iface)do
n[#n+1]=e
end
end
end)return n
end
local function l(l,i)local t
local o
local l=e.getAp(l)n.sectionname="wifi-radius-server"a(n,function(e)n.sectionname=e['.name']if c.match(e['.name'],l)then
o=true
if i=="2G"then
t="EAPSSID"return false
else
t="EAPSSID5"return false
end
end
end)if not o then
return i=="2G"and"SSID"or"SSID5"end
return t
end
function e.getIfnames()local i={}local a
local e=o()for t,e in t(e)do
n.sectionname=e
n.option="device"local n=r.get_from_uci(n)if n=="radio_2G"then
a=l(e,"2G")i[a]=e
elseif n=="radio_5G"then
a=l(e,"5G")i[a]=e
end
end
return i
end
function e.getAllAp()local i={}local o=o()n.sectionname="wifi-ap"a(n,function(e)n.sectionname=e['.name']for a,n in t(o)do
if e.iface and c.match(e.iface,n)then
i[#i+1]=e['.name']end
end
end)return i
end
function e.getPrivateAp()local i,e,c={},{},{}for a,e in t(o())do
c[e]=true
end
n.sectionname="wifi-ap"a(n,function(n)if not c[n.iface]then
i[#i+1]=n['.name']e[#e+1]=n.iface
end
end)return i,e
end
function e.validateStringIsDomainName(e)if#e==0 or#e>255 then
return nil,"Domain name cannot be empty and it cannot be too long."end
local a=1
repeat
local n=e:find("%.",a)local e=e:sub(a,n and n-1)if#e==0 or#e>63 then
return nil,"Domain name cannot be empty and not longer than 63 characters."end
local e=e:match("^%w[%w%-]*%w$")or e:match("^%w$")if not e then
return nil,"Label within domain name has invalid syntax"end
a=n and n+1
until not n
return true
end
return e