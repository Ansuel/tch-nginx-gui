local r,e=io.popen,string
local t,l,h,o,f,n=e.match,e.find,math.floor,e.len,e.sub,e.format
local d=commitapply
local n=require("transformer.mapper.ucihelper")local a=n.get_from_uci
local S=n.set_on_uci
local s=n.foreach_on_uci
local g=n.commit
local n={config="env",sectionname="rip"}local i={config="ethernet",sectionname="port"}local c
local u=require("transformer.mapper.ubus").connect()local p=e.upper
local e={}function e.readSFPFlag()local e=a({config="env",sectionname="rip",option="sfp"})if e=='1'then
return 1
end
return 0
end
function e.setUciParam(t,e)n.option=t
S(n,e,d)c=true
end
function e.getSfpctlFormat(e)local e=r("sfpi2cctl -get -format "..e)local t=e:read("*a")e:close()return t
end
function e.getSfpStatus()local e=r("cat /proc/sfp_status")local t=e:read("*a")e:close()return t
end
function e.getTxDis()local e=e.getSfpctlFormat("tx_dis")if e and t(e,"Tx_Diable on")then
return"on"end
return"off"end
function e.getCrossbarStatus()local e=r("cat /proc/crossbar_status")local t=e:read("*a")e:close()return t
end
function e.getLinkStatus(n)local e=""local r=r("ethctl eth4 media-type port "..n.." 2>&1")local n=r:read("*a")r:close()if n then
if t(n,"Link is up")then
e="Up"else
e="Down"end
end
return e
end
function e.getGPHY4LinkStatus()return e.getLinkStatus(10)end
function e.getSfpLinkStatus()return e.getLinkStatus(9)end
function e.getWanType()local e=e.getCrossbarStatus()local n=""if e then
if t(e,"WAN Port is connected to: AE")then
n="SFP"elseif t(e,"WAN Port is connected to: GPHY4")then
n="GPHY4"end
end
return n
end
function e.getGPHY4Mode()local n=e.getCrossbarStatus()local e=""if n then
if t(n,"Switch Port %d is connected to: GPHY4")then
e="Lan"else
e="Wan"end
end
return e
end
function e.getSfpPhyState()local n="disconnect"local e=e.getSfpStatus()if e and t(e,"link up")then
n="connect"end
return n
end
function e.getSFPType()local n="none"local e=e.getSfpctlFormat("vendpn")local e=t(e,"%[(.+)%]")if e and e~=""then
if l(e,"LTE3415")or l(e,"FDA2000")or l(e,"AFM0002")then
n="gpon"elseif l(e,"SFP%-GE%-SX%-FW")then
n="p2p"end
end
return n
end
function e.resetStatsGponSFP()os.execute("sfp_get.sh --counter_reset")end
function e.getSFPVendorName()local e=e.getSfpctlFormat("vendname")if e then
return e:match("%[(.+)%]")or""end
return""end
function e.getSFPFlap()n.option="sfp_flap"n.default="0"return a(n)end
function e.getWanInterface()local e
s(i,function(t)if t.wan=="1"then
e=t[".name"]return false
end
end)return e
end
function e.getGponSFP(t)local e=e.getSfpPhyState()if e=="connect"then
local e=r("sfp_get.sh --"..t)local t=e:read("*a")e:close()return t or""else
return""end
end
local d={BytesSent="bytes_sent",BytesReceived="bytes_rec",PacketsSent="packets_sent",PacketsReceived="packets_rec",ErrorsSent="errors_sent",ErrorsReceived="errors_rec",DiscardPacketsSent="discardpackets_sent",DiscardPacketsReceived="discardpackets_rec",}local function i(e,n)local e=t(e,n..":%s+(.-)%c")return e or"0"end
function e.getGponStats(t)local e=e.getGponSFP(d[t])return i(e,t)end
local s={BytesSent="tx_bytes",BytesReceived="rx_bytes",PacketsSent="tx_packets",PacketsReceived="rx_packets",ErrorsSent="tx_errors",ErrorsReceived="rx_errors",DiscardPacketsSent="tx_dropped",DiscardPacketsReceived="rx_dropped",}local function l(e,n)if e then
for t,e in pairs(e)do
if t==s[n]then
return e and tostring(e)end
end
end
return"0"end
function e.getP2PStats(t)local e=e.getWanInterface()local e=u:call("network.device","status",{name=e})or{}return l(e['statistics'],t)end
function e.getGponAllStats()local t={}local n=e.getGponSFP("allstats")for e in pairs(d)do
t[e]=i(n,e)end
return t
end
function e.getP2PAllStats()local t={}local e=e.getWanInterface()local n=u:call("network.device","status",{name=e})or{}for e in pairs(s)do
t[e]=l(n['statistics'],e)end
return t
end
local s={TransmitOpticalLevel={option="txpwr",match="Txpwr",},OpticalSignalLevel={option="rssi",match="Rssi"},}local l={gpon={LowerOpticalThreshold="-29000",UpperOpticalThreshold="-7000",LowerTransmitPowerThreshold="-500",UpperTransmitPowerThreshold="6000",},p2p={LowerOpticalThreshold="-33000",UpperOpticalThreshold="0",LowerTransmitPowerThreshold="-10000",UpperTransmitPowerThreshold="-2700",},none={LowerOpticalThreshold="-127500",UpperOpticalThreshold="-127500",LowerTransmitPowerThreshold="-63500",UpperTransmitPowerThreshold="-63500",},}function e.getLevel(r)local n=s[r]if n then
local e=e.getSfpctlFormat(n["option"])local e=t(e,n["match"]..":(.-)%sdBm")e=e and h(e*1000)or 0
if r=="OpticalSignalLevel"then
return e<=-65536 and"-65536"or e>=65534 and"65534"or tostring(e)elseif r=="TransmitOpticalLevel"then
return e<=-127500 and"-127500"or e>=0 and"0"or tostring(e)end
end
return"0"end
function e.getThresholdValues(t)local e=e.getSFPType()return l[e][t]end
function e.getEnable()local e=a({config="optical",sectionname="optical",option="enable"})if e==""then
e="1"end
return e
end
function e.getOpticals()return{Enable=e.getEnable(),Status=e.getStatus(),OpticalSignalLevel=e.getLevel("OpticalSignalLevel"),TransmitOpticalLevel=e.getLevel("TransmitOpticalLevel"),X_FASTWEB_Flap=e.getSFPFlap(),X_FASTWEB_VendorName=e.getSFPVendorName(),X_FASTWEB_SFPType=p(e.getSFPType()),Name=p(e.getSFPType()),LowerLayers="",Upstream="1",LowerOpticalThreshold=e.getThresholdValues("LowerOpticalThreshold"),UpperOpticalThreshold=e.getThresholdValues("UpperOpticalThreshold"),LowerTransmitPowerThreshold=e.getThresholdValues("LowerTransmitPowerThreshold"),UpperTransmitPowerThreshold=e.getThresholdValues("UpperTransmitPowerThreshold"),}end
local a={[0]="0",[1]="1",[2]="2",[3]="3",[4]="4",[5]="5",[6]="6",[7]="7",[8]="8",[9]="9",[10]="A",[11]="B",[12]="C",[13]="D",[14]="E",[15]="F",[16]="G",}local function s(o,e)local function r(t,n)if(t<e)then
table.insert(n,t)else
r(math.floor(t/e),n)table.insert(n,t%e)end
end
local t={}r(o,t,e)return t
end
local function l(e,t)local t=s(e,t)local e=""for n,t in ipairs(t)do
e=e..a[t]end
return e
end
function e.checkErrStatus()local n=r("sfpi2cctl -get -raw 1 110 1")local e=n:read("*a")n:close()if t(e,"read raw data failed")then
return-1
end
local e=f(e,o(e)-3,o(e)-2)if e then
local e=tonumber(e,16)if e then
local e=l(e,2)if e and o(e)>2 then
if f(e,o(e)-2,o(e)-2)=='1'then
return 1
end
end
end
end
return 0
end
function e.getGponLinkStatus()local n="Unknown"local e=e.getGponSFP("state")if e~=""then
if t(e,"%(O5%)")then
n="Up"elseif t(e,"%(O1%)")then
n="Dormant"else
n="LowerLayerDown"end
end
return n
end
function e.getStatus()local n=e.getSfpStatus()local r="Unknown"if t(n,"unplug")then
return"NotPresent"elseif t(n,"plug in")then
local t=e.checkErrStatus()if t==1 then
return"Error"elseif t==-1 then
return"NotPresent"end
local e=e.getTxDis()if e=="on"then
return"Down"end
return"Dormant"elseif t(n,"link up")then
local t=e.getTxDis()if t=="on"then
return"Down"end
local t=e.getSFPType()if t=="gpon"then
return e.getGponLinkStatus()elseif t=="p2p"then
return""end
end
return r
end
function e.getStats(n)local t=e.getSFPType()if t=="gpon"then
return e.getGponStats(n)elseif t=="p2p"then
return e.getP2PStats(n)else
return"0"end
end
function e.getAllStats()local t=e.getSFPType()if t=="gpon"then
return e.getGponAllStats()elseif t=="p2p"then
return e.getP2PAllStats()else
return""end
end
function e.commit()if c==true then
g(n)end
c=false
end
return e