local o={}local c=commitapply
local n=require("transformer.mapper.ucihelper")local r=n.get_from_uci
local i=n.getall_from_uci
local l=n.set_on_uci
local e={config="system",sectionname="scheduledreboot"}local t
local function d(n,o)e.option=n
e.default=o
return r(e)end
local function a(n,o)e.option=n
l(e,o,c)t=true
end
local function r()e.option=nil
local e=i(e)return next(e)end
local function c()e.option=nil
l(e,"scheduledreboot")n.commit(e)end
local function l(n)local e={}e.year,e.month,e.day,e.hour,e.min,e.sec=n:match("(%d%d%d%d)%-(%d%d)%-(%d%d)T(%d%d):(%d%d):(%d%d)")if not e.year then
return
end
local e=os.time(e)local n=os.time()local e=e-n
if e>0 then
return true
end
end
function o.getRebootOptions(e,n)return d(e,n)end
function o.setRebootOptions(e,n)if not r()then
c()end
if e=="time"and not l(n)then
return nil,"Invalid value or format"end
a(e,n)return true
end
function o.uci_system_commit()if t then
n.commit(e)t=false
end
end
function o.uci_system_revert()if t then
n.revert(e)t=false
end
end
return o