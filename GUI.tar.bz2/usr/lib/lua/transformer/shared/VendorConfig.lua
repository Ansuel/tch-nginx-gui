local o=require("transformer.shared.ConfigCommon")local e=require("transformer.shared.banktable")local t=require("datamodel")local c=require("lfs")local n,i=string.format,tonumber
local t,r=io.open,io.stderr
local m=os.execute
local a=e.getCurrentBank()local s=e.getOtherBank()local function t(e,...)local e=n(e,...)r:write('*error: ',e,'\n')return{e}end
local function h(...)local e={...}if#e<3 then
t("Please enter the appropriate parameters!")return 1
end
local f="/overlay/%s/etc/config"local l,u,d=unpack(e)local r
if i(l)<1 then
r=a
else
local e
if l=="1"then
e=a
elseif l=="2"then
e=s
else
t("Inavid index number!")end
local t=c.attributes("/overlay/"..e,"mode")if t=="directory"then
r=e
end
end
if not r then
t("Invalid index number!")return 1
end
local r=n(f,r)local e=o.export_init(u)e.filename=d
e.state="Requested"o.export_start(e,r)local l=1
local a=5
local r=0
repeat
m("sleep "..l)r=r+l
if e.state~="Requested"then
break
end
until(r>=a)if e.state~="Complete"then
if e.state=="Requested"then
t("Timeout when generating the config file")return 1
else
t(n('Generate error (state="%s", info="%s")',e.state,e.info or""))return 1
end
end
return 0
end
os.exit(h(...)or 0)