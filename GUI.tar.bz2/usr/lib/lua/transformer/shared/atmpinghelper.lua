local n={}local a=io.open
local i=require("transformer.mapper.ucihelper")local l=i.get_from_uci
local o=i.set_on_uci
local e={config="wanatmf5loopback"}local r={DiagnosticsState="state",NumberOfRepetitions="count",Timeout="timeout"}local s={SuccessCount=1,FailureCount=2,MinimumResponseTime=3,MaximumResponseTime=4,AverageResponseTime=5}local t={}local function f(e)os.remove("/tmp/atmping_"..e)t[e]={}end
local function c(i,e)local o=s[e]if not o then
return"0"end
local e=t[i]local n
if e then
n=e[o]else
e={}t[i]=e
end
if not n then
local t=a("/tmp/atmping_"..i)if t then
for n in t:lines()do
e[#e+1]=n
end
t:close()n=e[o]end
end
return n or"0"end
function n.startup()local t=a("/etc/config/wanatmf5loopback")if not t then
t=a("/etc/config/wanatmf5loopback","w")if not t then
error("could not create /etc/config/wanatmf5loopback")end
end
t:close()local t=false
local n=n.entries()for n,i in pairs(n)do
e.sectionname=i
e.option="state"local n=l(e)if n==""then
e.option=nil
o(e,"wanatmf5loopback")e.option="count"o(e,"1")e.option="timeout"o(e,"5000")t=true
end
if n~="None"then
e.option="state"o(e,"None")t=true
end
os.remove("/tmp/atmping_"..i)end
if t then
i.commit(e)end
end
local t={config="xtm",sectionname="atmdevice"}function n.entries()local e={}i.foreach_on_uci(t,function(n)e[#e+1]=n[".name"]end)return e
end
local a={Interface="",DiagnosticsState="None",NumberOfRepetitions="1",Timeout="1",SuccessCount="0",FailureCount="0",AverageResponseTime="0",MinimumResponseTime="0",MaximumResponseTime="0",}function n.get(t,o)if not t then
return""end
local n=""local i=r[o]if i then
e.sectionname=t
e.option=i
n=l(e)if o=="DiagnosticsState"and n=="InProgress"then
n="Requested"end
else
n=c(t,o)end
if n~=""then
return n
else
return a[o]end
end
local t={}local a=false
function n.set(i,u,c,n,s)if not i then
return""end
e.sectionname=i
local r=r[u]e.option=r
if r=="state"then
if c~="Requested"then
return nil,"invalid value"end
t[#t+1]=i
o(e,c,n)e.option="user"o(e,s or"",n)a=true
else
o(e,c,n)e.option="state"local t=l(e)if t~="Requested"and t~="None"then
o(e,"None",n)end
a=true
end
end
function n.commit()if#t>0 then
for n,e in pairs(t)do
f(e)end
t={}end
if a then
i.commit(e)a=false
end
end
function n.revert()if#t>0 then
t={}end
if a then
i.revert(e)a=false
end
end
return n