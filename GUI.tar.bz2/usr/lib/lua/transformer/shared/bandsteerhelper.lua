local e={}local o=require("transformer.mapper.ucihelper")local t=require("ubus")local n={config="wireless"}local d=t.connect()local a,c=string.match,string.format
local s=require("transformer.shared.common.network")local l={config="env",sectionname="var"}local i
function e.isBaseIface(e)return"0"==a(e,"%d+")end
function e.getBsAp(t)local e=d:call("wireless.accesspoint","get",{})for n,e in pairs(e)do
if e.ssid==t then
return n,e
end
end
return nil
end
local function f()local n=d:call("wireless.ssid","get",{})if n==nil then
return{}end
local e={}for n in pairs(n)do
e[#e+1]=n
end
return e
end
local function r(t,e)n.sectionname=t
n.option=e
return o.get_from_uci(n)end
local function t(t,r,e,a)n.sectionname=r
n.option=e
o.set_on_uci(n,t,a)i=true
end
function e.getBandSteerPeerIface(n)local e=f()if e and next(e)then
local t=a(n,".*_(%d+)")for r,e in pairs(e)do
if e~=n then
if not t then
if not a(e,".*_(%d+)")then
return e
end
else
if t==a(e,".*_(%d+)")then
return e
end
end
end
end
end
return nil,"To get band steer switching SSID failed."end
function e.isBandSteerSectionConfigured(e)local n=d:call("wireless.bandsteer","get",{})if not n then
return false,"Please configure band steer section "..e
end
for n in pairs(n)do
if n==e then
return true
end
end
return false,"Please configure band steer section "..e
end
function e.getBandSteerId(n)local t=a(n,".*_(%d+)")local n
if not t then
n=c("%s","bs0")else
n=c("%s","bs"..t)end
local t,e=e.isBandSteerSectionConfigured(n)if not t then
return nil,e
end
return n
end
function e.getApBandSteerId(e)return r(e,"bandsteer_id")end
function e.isBandSteerEnabledByAp(n)local e=e.getApBandSteerId(n)if e and""~=e and"off"~=e then
return true
end
return false
end
function e.isBandSteerEnabledByIface(n)local n=e.getBsAp(n)if type(n)=='string'then
return e.isBandSteerEnabledByAp(n)end
return false
end
function e.canEnableBandSteer(t,n,i)if type(t)~='string'or type(i)~='string'then
return false,"Ap or Iface is invalid."end
if not n or not next(n)or"1"~=tostring(n.admin_state)then
return false,"Please enable network firstly."end
local n=e.getApBandSteerId(t)if n and""~=n and"off"~=n then
return false,"Band steering has already been enabled."end
if r(t,"security_mode")=="wep"then
return false,"Band steering cannot be supported in wep mode."end
local n,t=e.getBandSteerPeerIface(i)if not n then
return false,t
end
local e,n=e.getBsAp(n)if not e then
return false,"Band steering switching node does not exist."end
if tostring(n.admin_state)~="1"then
return false,"Please enable network for band steering switching node firstly."end
if r(e,"security_mode")=="wep"then
return false,"Band steering cannot be supported in wep mode."end
return true
end
function e.canDisableBandSteer(n,t)if type(n)~='string'then
return false,"Ap is invalid."end
local n=e.getApBandSteerId(n)if not n or""==n or"off"==n then
return false,"Band steering has already been disabled."end
local n=e.getBandSteerPeerIface(t)if not n then
return false,"Band steering switching node does not exist."end
local e=e.getBsAp(n)if not e then
return false,"Band steering switching node does not exist."end
return true
end
function e.setBandSteerPeerIfaceSSIDByLocalIface(n,e,a,i)if"1"==a then
local n=r(n,"ssid")if""~=n then
t(n,e,"ssid",i)end
else
l.option="commonssid_suffix"local n=o.get_from_uci(l)t(r(e,"ssid")..n,e,"ssid",i)end
end
function e.setBandSteerPeerIfaceSSIDValue(n,e)t(e,n,"ssid")end
local function a(i,t)local n,r=e.getBandSteerPeerIface(t.ssid)if not n then
return nil,r
end
local r=e.getBsAp(n)if not r then
return nil,"Band steering switching node does not exist"end
if e.isBaseIface(t.ssid)then
return i,r,t.ssid,n
else
return r,i,n,t.ssid
end
end
local function f(n,i)local e=r(n,"security_mode")t(e,i,"security_mode")e=r(n,"wpa_psk_key")t(e,i,"wpa_psk_key")end
local function r(r,i,e,n)t(e,r,"bandsteer_id",n)t(e,i,"bandsteer_id",n)end
local function c(t,i)local n=s.getAccessPointInfo(t)if not n or not next(n)then
return nil,"The related AP node cannot be found."end
local d,o=e.canDisableBandSteer(t,n.ssid)if not d then
return nil,o
end
local o,a,n,t=a(t,n)r(o,a,"off",i)e.setBandSteerPeerIfaceSSIDByLocalIface(n,t,"0",i)end
local function d(t,o)local n=s.getAccessPointInfo(t)if not n then
return nil,"AP node is invalid."end
local d,i=e.canEnableBandSteer(t,n,n.ssid)if not d then
return nil,i
end
local i,t,d,l=a(t,n)local n,a=e.getBandSteerId(n.ssid)if not n then
return nil,a
end
r(i,t,n)e.setBandSteerPeerIfaceSSIDByLocalIface(d,l,"1",o)f(i,t)end
function e.setBandSteerValue(i,t,r)local e,n
if i=="1"then
e,n=d(t,r)else
e,n=c(t,r)end
if not e then
return nil,n
end
return e
end
function e.uci_commit()if i then
o.commit(n)i=false
end
end
function e.uci_revert()if i then
o.revert(n)i=false
end
end
return e