local n={}local t=type
local function r(l)local e={}for l,n in pairs(l)do
if t(n)=="table"then
e[l]=r(n)else
e[l]=n
end
end
return e
end
n.copyTable=r
function n.csvSplit(e)local n={}for e in e:gmatch("([^,]*),?")do
n[#n+1]=e
end
if not e:match(",$")then
n[#n]=nil
end
return n
end
function n.ensureList(e)if not e then
return{""}end
if t(e)~="table"then
return n.csvSplit(e)end
return e
end
return n