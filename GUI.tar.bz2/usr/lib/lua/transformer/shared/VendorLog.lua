local e=require("transformer.shared.ConfigCommon")local f=require("datamodel")local r=require("transformer.mapper.ucihelper")local a,u=string.format,tonumber
local g,n=io.open,io.stderr
local s=os.execute
local function d(e,...)local e=a(e,...)n:write('*error: ',e,'\n')return{e}end
local function m(...)local e={...}if#e<3 then
d("Please enter the appropriate parameters!")return 1
end
local t,i,c=unpack(e)local e
local l
if u(t)<1 then
e="logread"else
local n=f.get("uci.cwmpd.cwmpd_config.datamodel")local o=n and n[1].value
if o~="Device"then
o="InternetGatewayDevice"end
local i=false
local d={config="system",sectionname="log"}r.foreach_on_uci(d,function(e)if e.path and e.size and e.rotate then
i=true
return
end
end)if i then
n=f.get(a("%s.DeviceInfo.VendorLogFile.%s.Name",o,t),a("%s.DeviceInfo.VendorLogFile.%s.X_000E50_Rotate",o,t))e=n and n[1].value
l=n and n[2].value
l=l and u(l)else
n=f.get(a("%s.DeviceInfo.VendorLogFile.%s.Name",o,t))e=n and n[1].value
end
end
if not e then
d("Invalid index number!")return 1
end
if e=="filter_file"then
e=r.get_from_uci({config="system",sectionname="@system[0]",option="log_filter_file",default="/var/log/filt_msg",extended=true})elseif e=="logread"then
e=r.get_from_uci({config="system",sectionname="@system[0]",option="log_file",default="logread",extended=true})end
if e=="logread"then
s("logread > "..i..c)else
local n=g(e,"r")if not n then
d("Invalid log file name!")return 1
end
n:close()if persistenlog_enabled and l>=1 then
s("cat `ls -r "..e.."*` > "..i..c)else
s("ln -fs "..e.." "..i..c)end
end
return 0
end
os.exit(m(...)or 0)