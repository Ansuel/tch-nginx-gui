local e={}local n=require'io'local t=n.open
local function o(e)return"/proc/banktable/"..e
end
local function n(e)local e=t(o(e),"r")if e then
local n=e:read("*l")e:close()return n
end
end
local function c(e,n)local e=t(o(e),"w")if e then
e:write(n)e:close()return true
end
end
function e.isDualBank()return n("active")and true or false
end
function e.getCurrentBank()return n("booted")or"bank_1"end
function e.getOtherBank()return n("notbooted")end
local l=e.getOtherBank
local function o(e)local t=n("active")local o=n("booted")if t~=o then
e=not e
end
return n(e and"activeversion"or"passiveversion")end
function e.getCurrentVersion()return o(true)end
function e.getOtherVersion()return o(false)end
function e.getCurrentOID()return n("bootedoid")end
function e.getOtherOID()return n("notbootedoid")end
local function a(o)local n
local e=t("/proc/mtd","r")if e then
for t in e:lines()do
local t,e=t:match('^([^:]+):.*"([^"]+)"')if e==o then
n="/dev/"..t
break
end
end
e:close()end
return n
end
function e.isOtherBankValid()local r=false
local o=a(l())if o then
local e=t(o,"rb")if e then
local n=e:read(32)e:close()if(n:sub(0,4)=="UBI#")then
local a=4096
local l="VERSTART"local n=#l
local e=t(o,"rb")local o=e:seek('end')e:seek('set',0)local t=e:read(a+n)while t do
if t:find(l)then
r=true
break
end
if e:seek('cur')==o then
break
end
e:seek('cur',-n)t=e:read(a+n)end
e:close()else
local e=0
for t=1,4 do
e=e*256+n:byte(t)end
r=(e==0)and(n:sub(18,21)=="LINU")end
end
end
return r
end
function e.prepareSwitchOver()local e=n("notbooted")if e then
return c("active",e)end
end
function e.getNextBootBank()return n("active")end
return e