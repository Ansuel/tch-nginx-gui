local e={}local function t(r)local n={}local e
for r in string.gmatch(r,'([^"%s"]+)')do
if not e then
e=r
else
n[#n+1]=r
end
end
return e,n
end
function e.isEncrypted(e)return e and#e>=72 and e:match("^$%d%d$%d%d%$")or nil
end
function e.isModuleAvailable(e)if package.loaded[e]then
return true
else
for r,n in ipairs(package.searchers or package.loaders)do
local n=n(e)if type(n)=='function'then
package.preload[e]=n
return true
end
end
return false
end
end
local n=e.isModuleAvailable
function e.getRightLoggerModule()if n("tch.logger")then
return require("tch.logger")elseif n("transformer.logger")then
return require("transformer.logger")end
return nil
end
function e.execute(e)if n("tch.process")then
return require("tch.process").execute(t(e))end
return os.execute(e)end
function e.popen(e)if n("tch.process")then
return require("tch.process").popen(t(e))end
return io.popen(e)end
function e.decryptPassword(r)if n("tch.simplecrypto")then
if e.isEncrypted(r)then
local e,n=require("tch.simplecrypto").decrypt(r)if not e then
return nil,n
end
return e
end
end
return nil,"Can't decrypt"end
return e