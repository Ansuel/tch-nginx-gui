local e,n=ngx,require
local t,d=string.match,next
local i=n("web.content_helper")local c=n("dkjson")local r,o=ipairs,type
local a={}function a.handleAjaxQuery(a,l)if e.var.request_method=="POST"and e.var.content_type and t(e.var.content_type,"application/x%-www%-form%-urlencoded")then
local n=e.req.get_post_args()if n["action"]=="AJAX-GET"then
local t=n["requested_params"]if o(t)~="table"then
t={t}end
local n={}for t,e in r(t)do
local e=e:untaint()if a[e]then
n[e]=a[e]end
end
if d(n)~=nil then
local t,a=i.getExactContent(n)if o(l)=="function"then
l(n)end
if t then
local l={}t=c.encode(n,{indent=false,buffer=l})if t then
e.header.content_type="application/json"e.print(l)e.exit(e.HTTP_OK)else
e.exit(e.HTTP_INTERNAL_SERVER_ERROR)end
else
e.exit(e.HTTP_INTERNAL_SERVER_ERROR)end
else
e.exit(e.HTTP_BAD_REQUEST)end
end
end
end
return a