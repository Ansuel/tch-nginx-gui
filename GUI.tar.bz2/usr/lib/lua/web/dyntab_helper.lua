local u,e=ngx,require
local o,l=ipairs,type
local a=string
local i=e("datamodel")local e=e("web.post_helper")local h=e.getValidateInEnumSelect
local function s(e)if l(e)=="table"then
local l,n
local n=true
for t,e in o(e)do
local t=e[1]local e=e[2]l=i.set(t,e)n=n and l
end
return n
elseif l(e)=="function"then
return e()end
end
local function p(e)local t={}for n,e in o(e)do
if l(e.check)=="function"then
if e.check()then
return e.name
end
elseif l(e.check)=="table"then
local n=true
for l,e in o(e.check)do
if#e~=2 then
n=false
else
if not t[e[1]]then
local l=i.get(e[1])if not l then
n=false
else
local n=l[1].value
t[e[1]]=n
end
end
n=n and a.find(t[e[1]],e[2])end
end
if n then
return e.name
end
end
end
return""end
local r={}r.process=function(f)local a={}local c={}local r=""local n=""local t=""local d=false
for n,e in o(f)do
a[#a+1]={e.name,e.description}c[e.name]=e
if e.default==true then
r=e.name
end
end
local e
if u.var.request_method=="POST"then
e=u.req.get_post_args()local n=e["action"]local e=e["newmode"]if n=="SWITCH_MODE"then
if h(a)(e)then
t=e:untaint()s(c[t].operations)i.apply()end
elseif n=="AJAX-GET"then
d=true
end
end
n=p(f)if n==""then
n=r
end
if t==""then
t=n
end
local n={}local e=c[t]if e then
n={name=e.name,description=e.description,ajax=d}if l(e.view)=="function"then
n.view=e.view()else
n.view=e.view
end
if l(e.card)=="function"then
n.card=e.card()else
n.card=e.card
end
end
return{current=n,options=a}end
return r