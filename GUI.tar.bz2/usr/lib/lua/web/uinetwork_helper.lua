local t={}local o,e,d=type,require,ipairs
local l=string.format
local n=e("web.content_helper")local c=e("datamodel")local l=e("web.web")local i=e("bit")function t.getHostsList()local e="rpc.hosts.host."local t=c.get(e)local l={}if o(t)=="table"then
l=n.convertResultToObject(e,t)end
return l
end
local r="%x*:%x*:%x*:%x*:%x*:%x*:%x*:%x*"local a="%d+%.%d+%.%d+%.%d+"local n="%x*:%x*:%x*:%x*:%x*:%x*"function t.getAutocompleteHostsList(h)local e=t.getHostsList()local s={}local c={}for t,e in d(e)do
local o=l.html_escape(e.FriendlyName)local d=l.html_escape(e.IPAddress)local l=l.html_escape(e.MACAddress)local e
for t in d:gmatch(a)do
if o:match(n)then
e=t
else
e=o.." ("..t..")"end
e=e.." ["..l.."]"s[e]=t
end
for t in d:gmatch(r)do
if t then
if o:match(n)then
e=t
else
e=o.."("..t..")"end
e=e.." ["..l.."]"if h then
if i.band(t:byte(1),224)==32 then
c[e]=t
end
else
c[e]=t
end
end
end
end
return s,c
end
function t.getAutocompleteHostsListMac()local e=t.getHostsList()local s={}local c={}for t,e in d(e)do
local o=l.html_escape(e.FriendlyName)local d=l.html_escape(e.IPAddress)local t=l.html_escape(e.MACAddress)local e
for l in d:gmatch(a)do
if o:match(n)then
e=l
else
e=o
end
e=e.." ["..t.."]"s[e]=t
end
for l in d:gmatch(r)do
if l then
if o:match(n)then
e=l
else
e=o
end
e=e.." ["..t.."]"if skipIPv6LinkLocal then
if i.band(l:byte(1),224)==32 then
c[e]=t
end
else
c[e]=t
end
end
end
end
return s,c
end
function t.getAutocompleteHostsListIPv4()return(t.getAutocompleteHostsList())end
return t