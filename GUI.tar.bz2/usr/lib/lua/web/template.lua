local i,e,l,r=string.find,string.format,string.gsub,string.sub
local d,t=table.concat,table.insert
local o="ngx.print"local u="ngx.print"local function a(n,t,a)n=r(n,t,a or-1)if n==""then return n end
n=l(n,"([\\\n'])","\\%1")n=l(n,"\r","\\r")return e(" %s('%s'); ",o,n)end
local function g(r)local n={}local l=1
while true do
local o,c,s,i=i(r,"<%%[ \t]*(=?)(.-)%%>",l)if not o then
break
end
t(n,a(r,l,o-1))if s=="="then
t(n,e(" %s(%s);",u,i))else
t(n,e(" %s ",i))end
l=c+1
end
t(n,a(r,l))return d(n)end
return{translate=g}