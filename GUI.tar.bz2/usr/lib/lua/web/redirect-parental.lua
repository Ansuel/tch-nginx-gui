local n=require("datamodel")local a={}function a.process()local a=n.get("uci.dhcp.dnsmasq.@dnsmasq.hostname.@1.value")[1].value
local n=n.get("uci.dhcp.dnsmasq.@dnsmasq.domain")[1].value
ngx.redirect("http://"..string.untaint(a).."."..string.untaint(n).."/parental-block.lp",ngx.HTTP_MOVED_TEMPORARILY)end
return a