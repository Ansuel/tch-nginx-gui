local l=require("web.intl")local function t(e)ngx.log(ngx.NOTICE,e)end
local e=l.load_gettext(t)local l=e.gettext
e.textdomain('webui-mobiled')local t={}function t.get_params()e.language(ngx.header['Content-Language'])return{card_title=l"Mobile",modal_title=l"Mobile",}end
return t