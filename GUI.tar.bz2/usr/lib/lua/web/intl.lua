local u=string.format
local n=error
local h=table.sort
local g=ipairs
local r=require'lfs'local i=require'web.trfile'local m=require'web.plural'local t={}local l='/www/lang'function t.setLangPath(n)if n then
l=n:gsub('/$','')end
return l
end
local o=setmetatable({},{__mode='v'})local function d(n,e)return u('%s/%s/%s.po',l,e,n)end
local function s(n,e)if e and(n.dom~=e)then
n.dom=e
n.tr=nil
end
return n.dom
end
local function c(n,e)if e and(n.lang~=e)then
n.lang=e
n.tr=nil
end
return n.lang
end
local function a(n)if n.tr then
return n.tr
end
local l=d(n.dom,n.lang)local e=o[l]if not e then
local t
e,t=i.load(l)if not e then
if t and(n.dom~='<notset>')and(n.lang~='<notset>')then
n.log_error(t)end
e={}end
o[l]=e
end
n.tr=e
n.meta=e['']e['']=nil
n.plural=nil
return e
end
local function o(n)return(n==1)and 0 or 1
end
local function f(e)local n
local l=a(e)n=e.plural
if not n then
local t=e.meta
local t=t and t:match('\n%s*Plural%-Forms:(.*)\n')if t then
n=m.compile(t)end
if not n then
n=o
end
e.plural=n
end
return l,n
end
local function o(e,n)local e=a(e)return e[n:untaint()]or n
end
local function a(t,n,o,e)local l,t=f(t)local e=t(e)+1
local n=l[n:untaint()]or{n,o}return n[e]or n[#n]end
local function n()end
function t.load_gettext(e)local n={log_error=e or n,dom='<notset>',lang='<notset>',}local n={textdomain=function(e)return s(n,e)end;language=function(e)return c(n,e)end;gettext=function(e)return o(n,e)end;ngettext=function(l,e,t)return a(n,l,e,t)end;}return n
end
local function a(n,e)local n=d(n,e)return r.attributes(n,'mode')=='file',n
end
local function d(e,n)if n=="en-us"then
return true
else
return a(e,n)end
end
function t.findLanguage(r,e,n)if e then
if d(r,e)then
return e
end
end
n=n or''local t={}for e in n:gmatch('([^,]+),?')do
local n,o
local l=e:find(';')if l then
n=e:sub(1,l-1)o=tonumber(e:sub(l+1):match('q=(0%.%d*)')or'0')else
n=e
o=1
end
local e
n,e=n:match('^%s*([%a]*)[-_]?([%w@]*)%s*$')if n then
if e~=''then
n=u("%s-%s",n,e)end
n=n:lower()t[#t+1]={n,o}end
end
h(t,function(n,e)return n[2]>e[2]end)for e,n in g(t)do
if d(r,n[1])then
return n[1]end
end
return'en-us'end
function t.listLanguages(o)local n={}local t=false
if r.attributes(l,'mode')=='directory'then
for e in r.dir(l)do
if not e:find('^%.')then
local l,o=a(o,e)if l then
local l=i.getLanguage(o)or e
n[#n+1]={e,l}if e=='en-us'then
t=true
end
end
end
end
end
if not t then
n[#n+1]={'en-us','English (US)'}end
return n
end
return t