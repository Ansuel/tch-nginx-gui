local t,i,u=error,loadstring,ipairs
local c,a=table.insert,table.remove
local f=io.open
local r=require("web.template").translate
local o
local function d(n)o=n
end
local n={}local l=20
local function s(e)if e<0 then
t("cache size must be >= 0",2)end
if e<l and#n>e then
for e=e+1,#n do
n[e]=nil
end
end
l=e
end
local function h()n={}end
local function t(n)local l=n:match("^--pretranslated")local e
if l then
e=n
else
e=r(n)end
return e
end
local function R(e,n)local e=t(e)local e,n=i(e,n)if not e then
ngx.log(ngx.CRIT,n)if not ngx.status then
return ngx.exit(ngx.HTTP_INTERNAL_SERVER_ERROR,n)else
ngx.ctx.session:store("lasterr",n)return ngx.exit(ngx.HTTP_INTERNAL_SERVER_ERROR,n)end
end
return e
end
local function i(t)for l,e in u(n)do
if e.filename==t then
if l~=1 then
e=a(n,l)c(n,1,e)end
return e
end
end
end
local function r(e)if l>0 then
if#n>=l then
a(n)end
c(n,1,e)end
end
local function a(n)local n,e=f(n,"r")if not n then
return nil,e
end
local e=n:read("*a")n:close()return e
end
local function l(n,t)local e=i(n)if not e then
local l=a(n)e={filename=n,content=l and R(l,t or n)}r(e)end
return e.content
end
local function e(n)local n=l(o..n,n)setfenv(n,getfenv(2))n()end
local n={setpath=d,setcachesize=s,flush=h,load=l,include=e,translate=t,}return n