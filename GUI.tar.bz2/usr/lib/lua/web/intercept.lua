local n=require("datamodel")local t={}local function e()return n.get("uci.network.interface.@lan.ipaddr")[1].value
end
function t.process()local t=e()local e=ngx.var.http_host..ngx.unescape_uri(ngx.var.request_uri)ngx.log(ngx.NOTICE,"Intercept: uri="..string.untaint(e))ngx.header.content_type="text/html"ngx.say([[<html><head></head>
  <body><center>
  <p><b>INTERCEPT TEST</b></p>
  You have been intercepted for the following destination :<br/>
  <i>]],e,[[</i>
  <div>
  <p><b>WAN connection is unavailable.</b><br/>
  Please check internet access settings, close your browser and try again.</p>
  <div>
  <p><a href="http://]],t,[[">Click here to access NG-gateway webinterface</a></p>
  </center></body>
  </html>]])ngx.exit(ngx.HTTP_OK)end
return t