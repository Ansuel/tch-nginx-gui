local r=io.open
local s=table.concat
local e=error
local e=pairs
local h={}function h.load(e)local u,e=r(e)if not u then
return nil,e
end
local e
local i=""local o={}local t,l,d,e={},{},{},{}local h=false
local a=0
local g=false
for n in u:lines()do
if n==""or n:match("^msg[A-Z]+%s")then
if t[1]then
a=a+1
end
if l[1]then
if not(s(l)=="")then
o[s(t)]=s(l)else
a=a-1
end
l={}t={}end
if d[1]then
if e[1]then
if not(s(e)=="")then
d[#d+1]=s(e)else
g=true
end
e={}end
if(g==false)then
o[s(t)]=d
else
a=a-1
end
t={}d={}end
h=false
i=""end
if(i=="msgid")and not(n:match('^msg.+%s"'))and not h then
t[#t+1]=n:gsub('"',"",1):sub(0,-2):gsub('\\"','"')end
if(i=="msgstr")and not(n:match("^msgid%s"))then
l[#l+1]=n:gsub('"',"",1):sub(0,-2):gsub('\\"','"')end
if(i=="msgstr_plural")and not(n:match("^msgstr%["))then
e[#e+1]=n:gsub('"',"",1):sub(0,-2):gsub('\\"','"')end
if n:match("^msgid%s")then
t={}t[#t+1]=n:gsub('msgid "',""):sub(0,-2):gsub('\\"','"')i="msgid"end
if n:match("^msgid_plural")then
h=true
end
if n:match("^msgstr%s")then
l={}l[#l+1]=n:gsub('msgstr "',""):sub(0,-2):gsub('\\"','"')i="msgstr"end
if n:match("^msgstr%[")then
if e[1]then
d[#d+1]=s(e)e={}end
e[#e+1]=n:gsub('msgstr%[.*%] "',""):sub(0,-2):gsub('\\"','"')i="msgstr_plural"end
end
u:close()if l[1]then
if not(s(l)=="")then
o[s(t)]=s(l)else
a=a-1
end
end
if d[1]then
if e[1]then
if not(s(e)=="")then
d[#d+1]=s(e)else
g=true
end
e={}end
if(g==false)then
o[s(t)]=d
else
a=a-1
end
end
return o,a
end
function h.getLanguage(e)local e,n=r(e)if not e then
return nil
end
local n,s
for s in e:lines()do
if s:match("Language%-Name:")then
n=s:gsub('"Language%-Name:%s',""):gsub('\\n"',"")break
end
end
e:close()return n or nil
end
return h