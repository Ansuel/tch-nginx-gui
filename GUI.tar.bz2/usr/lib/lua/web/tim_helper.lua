local e=require("web.intl")local function t(n)ngx.log(ngx.NOTICE,n)end
local n=e.load_gettext(t)local t=n.gettext
local e=n.ngettext
local function e()n.language(ngx.header['Content-Language'])end
n.textdomain('webui-tim')local n={}function n.ethtrans()e()return{eth_infinit=t"infinite"}end
return n