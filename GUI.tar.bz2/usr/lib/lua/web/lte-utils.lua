local o,r,c,a,t=string.format,setmetatable,ipairs,pairs,ngx
local i=require("web.intl")local function n(e)t.log(t.NOTICE,e)end
local n=i.load_gettext(n)local e=n.gettext
local function s()n.language(t.header['Content-Language'])end
n.textdomain('webui-mobiled')local l=require("web.lte-params")local i=require("datamodel")local n={}local d={__index=function()return""end}n.radio_interface_map={["no_service"]=e"No service",["cdma"]=e"CDMA",["umts"]=e"UMTS",["gsm"]=e"GSM",["lte"]=e"LTE"}n.radio_tech_map={["cdma"]=e"CDMA",["lte"]=e"LTE",["umts"]=e"UMTS",["gsm"]=e"GSM",["auto"]=e"Auto"}n.roaming_map={["none"]=e"None",["national"]=e"National",["international"]=e"International"}n.network_selection_map={["auto"]=e"Auto",["manual"]=e"Manual"}n.radio_preference_map={["auto"]=e"Auto",["lte_preferred"]=e"LTE Preferred",["lte_only"]=e"LTE Only",["lte"]=e"LTE",["umts_preferred"]=e"UMTS Preferred",["umts_only"]=e"UMTS Only",["umts"]=e"UMTS",["gsm_preferred"]=e"GSM Preferred",["gsm_only"]=e"GSM Only",["gsm"]=e"GSM"}n.antenna_map={["internal"]=e"Internal",["external"]=e"External",["auto"]=e"Auto"}n.rrc_state_map={["idle"]=e"Idle",["connected"]=e"Connected"}n.mobiled_state_map={["no_device"]=e"Unplugged",["configuring_device"]=e"Configuring device",["initializing_sim"]=e"SIM locked",["connecting"]=e"Connecting",["connected"]=e"Connected",["disconnected"]=e"Disconnected",["scanning_network"]=e"Scanning networks",["upgrading_firmware"]=e"Upgrading firmware",["disabled"]=e"Disabled",["error"]=e"Error"}n.sim_state_map={["error"]=e"SIM error",["ready"]=e"SIM ready",["not_present"]=e"SIM not present"}n.signal_quality_map={["1"]=e"Poor",["2"]=e"Weak",["3"]=e"Fair",["4"]=e"Good",["5"]=e"Superb"}n.nas_state_map={["not_registered"]=e"Not registered",["registered"]=e"Registered",["not_registered_searching"]=e"Searching for network",["registration_denied"]=e"Registration denied"}n.session_state_map={["disconnected"]=e"Disconnected",["disconnecting"]=e"Disconnecting",["connected"]=e"Connected",["connecting"]=e"Connecting",["suspended"]=e"Suspended",["authenticating"]=e"Authenticating"}n.pin_state_map={["not_initialized"]=e"Not initialized",["enabled_not_verified"]=e"Not verified",["enabled_verified"]=e"Verified",["disabled"]=e"Disabled",["blocked"]=e"Blocked",["permanently_blocked"]=e"Permanently blocked"}n.power_mode_map={["online"]=e"Online",["lowpower"]=e"Low-power mode",["airplane"]=e"Airplane mode"}n.string_map={["no_device"]=e"0 device connected",}n.service_state_map={["limited_regional_service"]=e"Limited regional service",["limited_service"]=e"Limited service",["normal_service"]=e"Normal service",["no_service"]=e"No service",["sleeping"]=e"Sleeping"}n.time_period_map={["last_five_minutes"]=e"Last Five Minutes",["last_twenty_minutes"]=e"Last Twenty Minutes",["last_hour"]=e"Last Hour",["last_twentyfour_hours"]=e"Last 24 Hours",["last_week"]=e"Last Week",["last_month"]=e"Last Month"}local e=r({},{__index=function(t,i)s()local t={}if n[i]then
for i,n in a(n[i])do t[i]=e(n)end
end
r(t,d)return t
end})function e.getContent(e)local n=i.get(e)local e={}r(e,{__index=function()return""end})for t,n in c(n or{})do
e[n.param]=o("%s",n.value)end
return e
end
function e.Len(n)local e=0
for n,n in a(n)do e=e+1 end
return e
end
function e.isTableValue(n,e)for t,n in a(n)do
if e==n then
return true
end
end
return false
end
function e.sendResponse(e)t.say(e)t.exit(t.HTTP_OK)end
function e.get_params()return l.get_params()end
function e.get_uci_device_path()local e=i.get("rpc.mobiled.device.@1.info.device_config_parameter")local n=""if type(e)=="table"then n=e[1].value end
if n~=""then
e=i.get("rpc.mobiled.device.@1.info."..n)local t
if type(e)=="table"then t=e[1].value end
if t then
local e=i.get("uci.mobiled.device.")for i,e in a(e)do
if e.param==n and e.value==t then
return e.path
end
end
end
end
return"uci.mobiled.device_defaults."end
return e