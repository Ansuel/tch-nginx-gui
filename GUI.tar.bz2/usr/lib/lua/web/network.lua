local n=require
local l=ipairs
local t=unpack
local r=string.untaint
local o=n"datamodel"local e={}local function c(e)local n={}for e,l in l(e)do
n[#n+1]="rpc.network.interface.@"..l..".ipaddr"end
return n
end
local function a(n)local e={}for l,n in l(n)do
if n.param=="ipaddr"then
local l=n.path:match("^rpc%.network%.interface%.@([^.]+)")e[l]=r(n.value)end
end
return e
end
local function r(n)if#n>0 then
return o.get(t(n))end
return{}end
local function o(r,e)local n={}for e,l in l(e)do
n[#n+1]=r[l]or""end
return n
end
function e.interfacesToIP(n)local l=c(n)local l=r(l)if l then
local l=a(l)return o(l,n)end
return{}end
return e