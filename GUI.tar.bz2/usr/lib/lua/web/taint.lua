local o,c,d,s,l,a,f,_=newproxy,tostring,ipairs,type,unpack,rawequal,rawget,error
local n={}local i={}setmetatable(n,{__mode="k"})setmetatable(i,{__mode="v"})local u=o(true)local t=getmetatable(u)local e=string
local function r(r)local e=i[r]if not e then
e=o(u)n[e]=r
i[r]=e
end
return e
end
t.__index=e
t.__tostring=function(n)return"tainted string"end
t.__tonumberstr=function(e)return n[e]end
t.__len=function(e)return#n[e]end
t.__eq=function(e,r)return(n[e]or e)==(n[r]or r)end
t.__lt=function(e,r)return(n[e]or e)<(n[r]or r)end
t.__le=function(r,e)return(n[r]or r)<=(n[e]or e)end
t.__concat=function(e,o)e=n[e]or e
o=n[o]or o
return r(e..o)end
t.__add=function(r,e)r=n[r]or r
e=n[e]or e
return r+e
end
t.__sub=function(r,e)r=n[r]or r
e=n[e]or e
return r-e
end
t.__mul=function(r,e)r=n[r]or r
e=n[e]or e
return r*e
end
t.__div=function(r,e)r=n[r]or r
e=n[e]or e
return r/e
end
t.__mod=function(e,r)e=n[e]or e
r=n[r]or r
return e%r
end
t.__pow=function(r,e)r=n[r]or r
e=n[e]or e
return r^e
end
t.__unm=function(e)e=n[e]or e
return-e
end
function e.taint(e)if n[e]then
return e
end
e=c(e)return r(e)end
function e.untaint(e)return n[e]or e
end
function e.istainted(e)return(n[e]~=nil)end
local t={}for n,e in pairs(e)do
t[n]=e
end
getmetatable("").__index=t
local function u(t)return function(e,...)local n=n[e]if n then
local n=t(n,...)return r(n)end
return t(e,...)end
end
local o=e.byte
e.byte=function(e,r,t)e=n[e]or e
return o(e,r,t)end
local t=e.dump
e.dump=function(n)return r(t(n))end
local c=e.find
function e.find(t,e,u,o)e=n[e]or e
local n=n[t]if n then
local n={c(n,e,u,o)}if#n==0 then
return nil
end
if#n>2 then
for e=3,#n do
local t=r(n[e])n[e]=t
end
end
return l(n)end
return c(t,e,u,o)end
local t
local function h(n)t=n
end
local c=e.format
function e.format(r,...)if n[r]then
_("string.format() called with tainted format string",2)end
local e={...}for r,o in d(e)do
local n=n[o]if n then
e[r]=t(n)end
end
return c(r,l(e))end
local t=e.gmatch
function e.gmatch(o,e)e=n[e]or e
local n=n[o]if n then
local n=t(n,e)return function()local n={n()}for t,e in d(n)do
local e=r(e)n[t]=e
end
return l(n)end
end
return t(o,e)end
local _=e.gsub
function e.gsub(t,c,e,f)c=n[c]or c
local i=n[t]or t
local o=not a(i,t)local t
local u=s(e)if u=="string"then
t=e
elseif u=="userdata"then
t=n[e]or e
o=o or(not a(t,e))elseif u=="table"then
t=function(t)local e=e[t]local n=n[e]or e
if not a(n,e)then
o=true
end
return n
end
elseif u=="function"then
t=function(...)local t
if o then
local n={...}for e,r in d(n)do
n[e]=r:taint()end
t=e(l(n))else
t=e(...)end
local n=n[t]or t
if not a(n,t)then
o=true
end
return n
end
end
local n,e=_(i,c,t,f)if o then
local n=r(n)return n,e
end
return n,e
end
local o=e.len
e.len=function(t)t=n[t]or t
return o(t)end
e.lower=u(e.lower)local c=e.match
function e.match(u,t,o)t=n[t]or t
local n=n[u]if n then
local n={c(n,t,o)}if#n==0 then
return nil
end
for e=1,#n do
local t=r(n[e])n[e]=t
end
return l(n)end
return c(u,t,o)end
e.rep=u(e.rep)e.reverse=u(e.reverse)e.sub=u(e.sub)e.upper=u(e.upper)return{set_escape_function=h,untaint_mt={__index=function(e,t)return f(e,n[t])end},taint_mt={__index=function(n,e)return f(n,i[e])end}}