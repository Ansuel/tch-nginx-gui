local e=require
local t=pairs
local o=ipairs
local r=string.untaint
local a=e'web.assistance'local n=e'datamodel'local c={}local function i(n)local e={}for t,n in t(n)do
local o,n,a,l=n:match("(.*)_(.*)_(.*)_(.*)")e[#e+1]={assistant=t:untaint(),enable=o,mode=n,pwdcfg=a,pwd=l}end
return e
end
local function d()local l={}local e=n.get("uci.web.user.")or{}for e,n in o(e)do
local a=n.path:match("^uci.web.user.@([^.]+)%.")local e=l[a]if not e then
e={}l[a]=e
end
e[n.param]=n.value
end
return l
end
local function l(n,e)for l,e in t(e)do
if e.name==n then
return e
end
end
end
local function f(e)return l(e:username(),d())end
local e={}e.__index=e
local function n(l,n)return setmetatable({trueValue=l,falseValue=n},e)end
function e:__call(e,n)if e==self.trueValue then
return true
elseif e==self.falseValue then
return false
else
return n
end
end
local d=n("on","off")local s=n("permanent","temporary")local function t(n)local l=a.getAssistant(n.assistant)if not l then
return
end
local e=n.pwd
local a=n.pwdcfg or"keep"if a=="random"then
e=nil
elseif a=="keep"then
e=false
elseif a=="srpuci"then
local n=f(l)e={salt=r(n.srp_salt),verifier=r(n.srp_verifier),}if not(e.salt and e.verifier)then
e=nil
end
end
local a=d(n.enable,l:enabled())local n=s(n.mode,l:isPermanentMode())l:enable_with_reload(a,n,e)end
local function n(e)for n,e in o(e)do
t(e)end
end
local function l(e)local e=a.getAssistant(e)if e then
local a=e:enabled()local n=e:isPermanentMode()local l=false
e:enable_with_reload(a,n,l)end
end
local function t()local e=a.assistantNames()for n,e in o(e)do
l(e)end
end
function c.reload(e)local e=i(e)if#e>0 then
n(e)else
t()end
end
return c