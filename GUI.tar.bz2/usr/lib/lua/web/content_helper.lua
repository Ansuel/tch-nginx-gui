local a=require("datamodel")local p=io.open
local t,c,i,l,e=pairs,ipairs,unpack,type,tonumber
local h,b=table.concat,table.sort
local f=string
local u=f.untaint
local n={}local function s(n)local e={}if n then
for t,n in t(n)do
e[#e+1]=n
end
end
return e
end
function n.getPaths(e)local a,t,l,n
if e:find("%.@%.$")then
t=e:sub(1,-3)l=e:sub(1,-2)n="@"else
t=e
l=e
n=""end
return t,l,n
end
function n.getExactContent(n)local l=s(n)local o=a.get(i(l))local function r()local l={}for n,e in c(o or{})do
l[e.path..e.param]=e.value
end
for t,e in t(n)do
n[t]=l[e]or""end
end
if o then
r()return true
else
local e={}local d={}e[#e+1]="Exact data not found in this paths: "e[#e+1]="<br/>"for t,o in t(n)do
if not(a.get(o))then
e[#e+1]="Key <strong>"..u(t).."</strong>".." : "..u(o).."<br/>"d[#d+1]=t
n[t]=nil
end
end
l=s(n)o=a.get(i(l))r()for t,e in t(d)do
n[e]="Exact path not found!"end
return nil,table.concat(e)end
end
function n.getMatchedContent(u,i,s)if(u==nil)then
return{}end
local e,c={},{}local d,o="",""local f,r=0,0
if(l(i)=="table")then
for e,e in t(i)do
f=f+1
end
end
local u=n.getPaths(u)local n=a.get(u)if(l(n)=="table")then
local a={}for t,n in t(n)do
local t=n.path:match("^("..u.."[^%.]+)").."."if(d==""or t~=d)then
if(r~=f)then
e[#e]=nil
end
if(#e==s)then
return e
end
d=t
e[#e+1]={path=d,__path=d}r=0
end
o=n.path:match(".(%w+).@[%w+].$")if(n.path:match(d)and n.path~=d and o)then
e[#e][o]=e[#e][o]or{}local e=e[#e][o]e[#e+1]={value=n.value,path=n.path}c[#c+1]=n.value
if(l(i)=="table")then
if(l(i[o])=="table")then
b(c)b(i[o])local e=h(c,"")local n=h(i[o],"")if(e==n)then
r=r+1
end
end
end
elseif(n.path==d)then
e[#e][n.param]=n.value
c={}if(l(i)=="table")then
if(n["value"]==i[n["param"]])then
r=r+1
end
end
end
end
end
if(r~=f)then
e[#e]=nil
end
return e
end
function n.addListContent(l,e)for t,e in t(e)do
local n=a.get(e)if(n)then
local e={}for t,n in c(n)do
e[#e+1]=n.value
end
l[t]=e
end
end
end
local o={number="*n",line="*l",file="*a"}function n.readfile(e,n,t)local e=p(e)if not e then
return""end
local n=o[n]or o["line"]local n=e:read(n)e:close()if l(t)=="function"then
return t(n)end
return n
end
local function s(e,u,o)local i,t,h
local d={}local a={}local s,r=f.find,f.gsub
i=#e
if not e:find("%.@%.$")then
i=i+1
end
e=r(e,"-","%%-")e=r(e,"%[","%%[")e=r(e,"%]","%%]")if u then
for l,n in c(u)do
t,h=n.path:match("^([^%.]+)%.(.*)$",i)if t and s(n.path,e)==1 then
if d[t]==nil then
d[t]={}d[t]["paramindex"]=t
a[#a+1]=d[t]end
d[t][h..n.param]=n.value
end
end
end
if o and#a>1 then
if l(o)=="function"then
table.sort(a,o)elseif l(o)=="string"then
local l=false
local e=f.match(o,"^-(.*)")if e then
l=true
else
e=o
end
if a[1][e]then
table.sort(a,function(t,n)if t[e]and n[e]then
if l then
return t[e]>n[e]else
return t[e]<n[e]end
else
return true
end
end)end
end
end
return a
end
n.convertResultToObject=s
local function o(t,l)local e={}if t.param~=nil then
local n=0
while true do
n=n+1
local n=l[t.param..".@"..n..".value"]if not n then
break
end
e[#e+1]=u(n)end
end
return e
end
local function i(n,t)local e={}for l,n in c(n)do
if n.type=="checkboxgroup"then
e[#e+1]=o(n,t)elseif n.type=="aggregate"then
e[#e+1]=i(n.subcolumns,t)else
if t[n.param]~=nil then
e[#e+1]=t[n.param]else
e[#e+1]=""end
end
end
return e
end
function n.loadTableData(e,r,t,o)local n,d=n.getPaths(e)local n=a.get(n)local e=s(e,n,o)local o={}local d={}for e,a in c(e)do
local e
if l(t)=="function"then
e=t(a)elseif t==nil then
e=true
end
if e then
local n
if l(e)=="table"then
n=e
else
n={canEdit=true,canDelete=true,}end
n.paramindex=a.paramindex
d[#d+1]=n
o[#o+1]=i(r,a)end
end
return o,d
end
function n.setObject(u,o,e,n)local r,i=true,{}local d={}local f=false
e=e or""if l(n)=="table"then
for t,n in t(n)do
d[e..t]=n
end
end
for n,t in t(u)do
if o[n]~=nil then
f=true
if l(t)=="table"then
a.del(e..o[n]..".")for t,l in c(t)do
a.add(e..o[n]..".")d[e..o[n]..".@"..t..".value"]=l
end
else
d[e..o[n]]=t
end
end
end
if f==true then
r,i=a.set(d)end
return r,i
end
local function d(t,n)local a="%.@[^%.]+%."local e,l
local a,o=t:find(a)if a then
e=t:sub(1,a)l=t:sub(a+2,o-1)if not n[e]then
n[e]={}end
if not n[e][l]then
n[e][l]={}end
d(t:sub(o+1),n[e][l])end
end
local function o(e,n)local d="^%d+$"local l
for l,n in t(n)do
for n,t in t(n)do
if n:match(d)then
a.add(e..l)else
a.add(e..l,n)end
o(e..l.."@"..n..".",t)end
end
end
local function i(n,l)local e={}for t,n in t(l)do
d(n,e)end
o(n,e)end
function n.addNewObject(f,r,o,c,d)local t,e,l,u
e,t,l=n.getPaths(f)local e,l=a.add(e,d)if e~=nil then
i(t..e..".",o)_,l=n.setObject(r,o,t..e..".",c)end
return e,l
end
function n.validateObject(n,l)if n==nil then
return true
end
local a=true
local o={}if l then
for e,t in t(n)do
if l[e]then
local n,t=l[e](t,n,e)a=a and n~=nil
if n==nil then
o[e]=t
end
end
end
end
return a,o
end
local function o(a,e)if(l(a)~="table"or l(e)~="table")then
return false
end
for t,n in t(a)do
if n~=e[t]and not o(n,e[t])then
return false
end
end
for e in t(e)do
if not a[e]then
return false
end
end
return true
end
n.tableEquals=o
function n.getMergedList(n,e)local l=require("web.web").html_escape
local t=""n=l(n)e=l(e)if n==""and e~=""then
t=e
elseif n~=""and e==""then
t=n
elseif n~=""and e~=""then
t=n..","..e
end
local e={}local l={}for n in t:gmatch("[^,]+")do
if not l[n]then
e[#e+1]=n
l[n]=true
end
end
t=table.concat(e,",")return t
end
return n