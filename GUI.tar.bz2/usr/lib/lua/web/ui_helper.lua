local e,i,c,s,b,l=require,pairs,ipairs,type,tonumber,getfenv
local a,n,d,w=string.format,string.find,string.gsub,string.gmatch
local S=math.huge
local r,l,p=table.concat,table.sort,tostring
local v=string.istainted
local u=ngx
local l=e("web.taint").untaint_mt
local m=e("web.web").html_escape
local h={["1"]=" green",["2"]=" orange",["3"]=" yellow",["4"]=" red",["true"]=" green",}setmetatable(h,l)local g=e("web.intl")local function l(e)u.log(u.NOTICE,e)end
local e=g.load_gettext(l)local o=e.gettext
local l=e.ngettext
local function f()e.language(u.header['Content-Language'])end
e.textdomain('web-framework-tch')local e={}local function t(a,e)if a==nil then
a={}end
if e==nil then
return a
end
for l,e in i(e)do
if a[l]==nil then
a[l]={}end
local t=a[l]if s(e)=="table"then
if(e.readonly or e.disabled)and not e.no_warnlog then
u.log(u.WARN,"'readonly' or 'disabled' attributes can be easily removed client side, making fields editable. ","Use labels or make sure your code does not process POST data containing rogue values for such fields! ","E.g. for handleTableQuery() use the 'readonly' property on your columns or use a validation function.")end
e.no_warnlog=nil
for a,l in i(e)do
if nil==t[a]then
t[a]=l
else
if a=="class"then
local e=t[a]if n(l,"span")~=nil then
e=d(e,"span%d+","")end
if n(l,"table-")~=nil then
e=d(e,"table%-%a+","")end
if n(l,"help-block")~=nil then
e=d(e,"help-inline","")end
if n(l,"alert-")~=nil then
e=d(e,"alert%-%a+","")end
if n(l,"icon-")~=nil then
e=d(e,"icon%-%a+","")end
t[a]=e.." "..l
else
t[a]=l
end
end
end
end
end
return a
end
local function l(l)local e={}for t,l in i(l)do
e[#e+1]=a('%s="%s"',t,m(l))end
return r(e," ")end
function e.createAlertBlock(o,n)local e={alert={class="alert alert-error"},}t(e,n)local t=l(e["alert"])local l={}local e=o
if e~=nil then
if s(e)~="table"then
e={e}end
for n,e in c(e)do
l[#l+1]=a('<div %s>%s</div>',t,e)end
end
return l
end
function e.createHelpText(o,n)local e={help={class="help-inline"},}t(e,n)local t=l(e["help"])local l={}local e=o
if e~=nil then
if s(e)~="table"then
e={e}end
for n,e in c(e)do
l[#l+1]=a("<span %s>%s</span>",t,e)end
end
return l
end
local function m(l)local e={}for l,a in i(l)do
e[#e+1]='"'..l:gsub('"','"')..'": "'..a:gsub('"','"')..'"'end
return'{'..r(e,',')..'}'end
function e.createSimpleInputHidden(c,o,n,s)local o={input={class="",type="hidden",name=c,value=o,},}t(o,n)local l=l(o["input"])local e={a("<input %s>",l),e.createHelpText(s,n)}return e
end
function e.createSimpleInputText(n,i,o,c)local n={input={class="edit-input span3",type="text",name=n,value=i,id=n,},help={class="help-inline"},}t(n,o)if s(o)=="table"and s(o["autocomplete"])=="table"then
n.input["data-values"]=m(o["autocomplete"])n.input["autocomplete"]="off"n.input["class"]=n.input["class"].." typeahead"end
local t=l(n["input"])local l=l(n["help"])local e={a("<input %s>",t),e.createHelpText(c,o)}return e
end
function e.createInputText(r,i,s,o,c)local n={group={class="control-group"},label={class="control-label"},controls={class="controls"},}if c~=nil then
n.group.class=n.group.class.." error"end
t(n,o)local t=l(n["group"])local d=l(n["label"])local l=l(n["controls"])local e={a("<div %s><label %s>%s</label><div %s>",t,d,r,l),e.createSimpleInputText(i,s,o,c),"</div></div>"}return e
end
function e.createSimpleInputPassword(n,o,c,i)local n={input={class="edit-input span3",type="password",autocomplete="new-password",name=n,value="",id=n,},help={class="help-inline"},}if(s(o)=="string"or v(o))and#o>0 then
n.input.value="********"end
t(n,c)local t=l(n["input"])local l=l(n["help"])local e={a("<input %s>",t),e.createHelpText(i,c)}return e
end
function e.createInputPassword(d,r,i,o,c)local n={group={class="control-group"},label={class="control-label"},controls={class="controls"},}if c~=nil then
n.group.class=n.group.class.." error"end
t(n,o)local s=l(n["group"])local t=l(n["label"])local l=l(n["controls"])local e={a("<div %s><label %s>%s</label><div %s>",s,t,d,l),e.createSimpleInputPassword(r,i,o,c),"</div></div>"}return e
end
function e.createSimpleInputCheckbox(o,e,c,s)local n={input={class="",type="checkbox",name=o,value=p(e),},}t(n,c)local l=l(n["input"])local e=(e=="1"or e==true)and" checked"or""if s then
return a("<input %s%s>  %s</input><br> ",l,e,o)end
return a("<input %s%s>",l,e)end
function e.createInputCheckbox(i,r,s,o)local n={group={class="control-group"},label={class="control-label"},controls={class="controls"},}t(n,o)local c=l(n["group"])local t=l(n["label"])local l=l(n["controls"])local e={a("<div %s><label %s>%s</label><div %s>",c,t,i,l),e.createSimpleInputCheckbox(r,s,o),"</div></div>"}return e
end
function e.createSimpleCheckboxSwitch(o,c,s)local e={}local n={checkbox={class="checkbox"},input={type="checkbox",name=o,id=o}}t(n,s)local t=l(n["checkbox"])local l=l(n["input"])local n=(c=="1"or c==true)and" checked"or""e[#e+1]=a('<label class="hide checkbox"><input type="checkbox" name="%s" value="_DUMMY_" checked></label>',o)e[#e+1]=a('<label %s>',t)e[#e+1]=a('<input %s value="%s" %s> %s</label>',l,"_TRUE_",n,"")return e
end
function e.createCheckboxSwitch(c,s,i,o)local n={group={class="control-group"},label={class="control-label"},controls={class="controls"},}t(n,o)local t=l(n["group"])local r=l(n["label"])local l=l(n["controls"])local e={a("<div %s><label %s>%s</label><div %s>",t,r,c,l),e.createSimpleCheckboxSwitch(s,a("%s",i),o),"</div></div>"}return e
end
function e.createSimpleCheckboxGroup(i,r,o,d)local e={}local n={checkbox={class="checkbox"},input={type="checkbox",name=i}}t(n,d)local d=l(n["checkbox"])local u=l(n["input"])local t={}if s(o)=="table"then
for l,e in c(o)do
t[e]=true
end
end
e[#e+1]=a('<label class="hide checkbox"><input type="checkbox" name="%s" value="" checked></label>',i)for n,l in c(r)do
local n=""e[#e+1]=a('<label %s>',d)if t[l[1]]then
n="checked"end
e[#e+1]=a('<input %s value="%s" %s> %s</label>',u,l[1],n,l[2])end
return e
end
function e.createCheckboxGroup(d,r,s,c,o,u)local n={group={class="control-group"},label={class="control-label"},controls={class="controls"},}t(n,o)local t=l(n["group"])local i=l(n["label"])local n=l(n["controls"])local l={a("<div %s>",t)}l[#l+1]=a("<label %s>%s</label><div %s>",i,d,n)l[#l+1]=e.createSimpleCheckboxGroup(r,s,c,o)l[#l+1]=e.createAlertBlock(u,o)l[#l+1]="</div></div>"return l
end
function e.createLabel(s,i,o,c)local n={group={class="control-group"},label={class="control-label"},controls={class="controls"},span={class="span2 simple-desc",id=s},help={class="help-inline"}}if c~=nil then
n.group.class=n.group.class.." error"end
t(n,o)local t=l(n["group"])local r=l(n["label"])local d=l(n["controls"])local u=l(n["span"])local l=l(n["help"])local e={a("<div %s><label %s>%s</label><div %s><span %s>%s</span>",t,r,s,d,u,i),e.createHelpText(c,o),"</div></div>"}return e
end
function e.createSimpleSwitch(n,c,i,r)f()local n={switch={class="switch"},switcher={class="switcher"},input={type="hidden",name=n,value=c,id=n},help={class="help-inline",},values={on="1",off="0"}}t(n,i)local t=n["values"]["on"]local s=n["values"]["off"]if c==t then
n["switch"]["class"]=n["switch"]["class"].." switchOn"n["switcher"]["class"]=n["switcher"]["class"].." switcherOn"else
n["input"]["value"]=s
end
local c=l(n["switch"])local u=l(n["switcher"])local d=l(n["input"])local l=l(n["help"])local e={a('<div %s><div %s textON="%s" textOFF="%s" valOn="%s" valOff="%s"></div><input %s></div>',c,u,o"ON",o"OFF",t,s,d),e.createHelpText(r,i)}return e
end
function e.createSwitch(d,i,s,c,o)local n={group={class="control-group"},label={class="control-label"},controls={class="controls"},}if o~=nil then
n.group.class=n.group.class.." error"end
t(n,c)local t=l(n["group"])local r=l(n["label"])local l=l(n["controls"])local e={a("<div %s><label %s>%s</label><div %s>",t,r,d,l),e.createSimpleSwitch(i,s,c,o),"</div></div>"}return e
end
function e.createSimpleInputSelect(n,s,r,o,i)local n={select={class="span3",name=n,id=n},help={class="help-inline",},}t(n,o)local t=l(n["select"])local l=l(n["help"])local l={a("<select %s>",t)}for t,e in c(s)do
local t=""if r==e[1]then
t='selected="selected"'end
l[#l+1]=a("<option value=%q %s>%s</option>",e[1],t,e[2])end
l[#l+1]="</select>"l[#l+1]=e.createHelpText(i,o)return l
end
function e.createInputSelect(d,u,i,r,c,o)local n={group={class="control-group"},label={class="control-label"},controls={class="controls"},}if o~=nil then
n.group.class=n.group.class.." error"end
t(n,c)local s=l(n["group"])local t=l(n["label"])local l=l(n["controls"])local e={a("<div %s><label %s>%s</label><div %s>",s,t,d,l),e.createSimpleInputSelect(u,i,r,c,o),"</div></div>"}return e
end
function e.createSimpleInputRadio(e,n,c,o)local e={radio={class="radio",},input={name=e,value=n[1]},}if c==n[1]then
e.input["checked"]="checked"end
t(e,o)local t=l(e["input"])local e=l(e["radio"])local e={a("<label %s>",e),a("<input type='radio' %s />%s",t,n[2]),"</label>",}return e
end
function e.createInputRadio(r,i,d,u,o,s)local n={group={class="control-group"},label={class="control-label"},controls={class="controls"},}if s~=nil then
n.group.class=n.group.class.." error"end
t(n,o)local t=l(n["group"])local p=l(n["label"])local l=l(n["controls"])local l={a("<div %s><label %s>%s</label><div %s>",t,p,r,l),}for t,a in c(d)do
l[#l+1]=e.createSimpleInputRadio(i,a,u,o)end
l[#l+1]=e.createHelpText(s,o)l[#l+1]="</div></div>"return l
end
function e.createSimpleButton(n,e,o)local e={button={class="btn",id=n,},icon={class=e}}t(e,o)local t=l(e["button"])local e=l(e["icon"])return a("<div %s><i %s></i>  %s</div>",t,e,n)end
function e.createButton(c,i,s,o)local n={group={class="control-group"},label={class="control-label"},controls={class="controls"},}t(n,o)local t=l(n["group"])local r=l(n["controls"])local l=l(n["label"])local e={a("<div %s><label %s>%s</label><div %s>",t,l,c,r),e.createSimpleButton(i,s,o),"</div></div>"}return e
end
function e.createInputTextWithButton(i,d,p,u,s,o,c)local n={group={class="control-group"},label={class="control-label"},controls={class="controls"},help={class="help-inline"},}if c~=nil then
n.group.class=n.group.class.." error"end
t(n,o)local t=l(n["group"])local r=l(n["label"])local l=l(n["controls"])local e={a("<div %s><label %s>%s</label><div %s>",t,r,i,l),e.createSimpleInputText(d,p,o),e.createSimpleButton(u,s,o),e.createHelpText(c,o),"</div></div>"}return e
end
local function y(l,t)local e={"<thead><tr>"}for t,l in c(l)do
e[#e+1]=a("<th>%s</th>",l.header)end
if t==true then
e[#e+1]="<th></th>"end
e[#e+1]="</tr></thead>"return e
end
local function m(a,t)local l={}local n={switch={class="switch disabled"},}if a.type=="select"then
local e=false
for n,a in c(a.values)do
if a[1]==t then
e=true
l[#l+1]=a[2]end
end
if e==false then
l[#l+1]=t
end
elseif a.type=="switch"then
l[#l+1]=e.createSimpleSwitch(a.name,t,n)elseif a.type=="checkboxswitch"then
l[#l+1]=e.createSimpleCheckboxSwitch(a.name,t,n)elseif a.type=="light"then
l[#l+1]=e.createSimpleLight(t,"",{})elseif a.type=="checkboxgroup"then
l[#l+1]=e.createSimpleCheckboxGroup(a.name,a.values,t,{input={disabled="disabled",no_warnlog=true}})elseif a.type=="aggregate"then
if s(a.synthesis)=="function"then
l[#l+1]=a.synthesis(t)end
elseif a.type=="password"then
l[#l+1]="********"elseif a.type~="hidden"then
l[#l+1]=t
end
return l
end
local function k(l,n,c)local a={}local o={}if c then
local e={class="tooltip-on error",["data-placement"]="top",["data-original-title"]=c,}o={switch=e,input=e,select=e,}a[#a+1]=[[<div class="control-group error">]]else
a[#a+1]=[[<div class="control-group">]]end
t(o,l.attr)if l.type=="text"then
a[#a+1]=e.createSimpleInputText(l.name,n or l.default or"",o)elseif l.type=="password"then
a[#a+1]=e.createSimpleInputPassword(l.name,n or l.default or"",o)elseif l.type=="select"then
a[#a+1]=e.createSimpleInputSelect(l.name,l.values,n or l.default or"",o)elseif l.type=="switch"then
a[#a+1]=e.createSimpleSwitch(l.name,n or l.default or true,o)elseif l.type=="checkboxswitch"then
a[#a+1]=e.createSimpleCheckboxSwitch(l.name,n or l.default or true,o)elseif l.type=="checkboxgroup"then
if n==nil then
n={}end
a[#a+1]=e.createSimpleCheckboxGroup(l.name,l.values,n,o)elseif l.type=="hidden"then
a[#a+1]=e.createSimpleInputHidden(l.name,n or l.default or"",o)elseif l.type=="label"then
a[#a+1]=n
end
a[#a+1]="</div>"return a
end
local function x(l,n,c)local a={}local o={}t(o,l.attr)if l.type=="text"then
a[#a+1]=e.createInputText(l.header,l.name,n or l.default or"",o,c)elseif l.type=="password"then
a[#a+1]=e.createInputPassword(l.header,l.name,n or l.default or"",o,c)elseif l.type=="select"then
a[#a+1]=e.createInputSelect(l.header,l.name,l.values,n or l.default or"",o,c)elseif l.type=="switch"then
a[#a+1]=e.createSwitch(l.header,l.name,n or l.default or true,o,c)elseif l.type=="checkboxswitch"then
a[#a+1]=e.createCheckboxSwitch(l.header,l.name,n or l.default or true,o,c)elseif l.type=="checkboxgroup"then
if n==nil then
n=l.default or{}end
a[#a+1]=e.createCheckboxGroup(l.header,l.name,l.values,n,o,c)elseif l.type=="hidden"then
a[#a+1]=e.createSimpleInputHidden(l.name,n or l.default or"",o)end
return a
end
local function n(l)local e={}for a,l in i(l)do
e[a]=l
end
return e
end
local function p(e)local e=n(e.button)e["data-original-title"]=nil
e["class"]=d(e["class"],"%s*tooltip%-on","")e["class"]=d(e["class"],"btn%-mini","btn-small")return{button=e}end
local function v(b,t,h,s)local f={button={class="btn-mini btn-primary btn-table-add tooltip-on",["data-placement"]="top",["id"]="btn-table-add",["data-original-title"]=o"Add",}}local u={button={class="btn-mini btn-primary btn-table-modify tooltip-on",["data-placement"]="top",["id"]="btn-table-modify",["data-original-title"]=o"Apply",}}local r={button={class="btn-mini btn-danger btn-table-cancel tooltip-on",["data-placement"]="top",["id"]="btn-table-cancel",["data-original-title"]=o"Cancel",}}if t==nil then
t={}end
local d=#b
local l={'<tr class="line-edit">'}local n={}s=s or{}for a,e in i(b)do
l[#l+1]="<td>"if e.type=="aggregate"then
n[#n+1]={legend=e.legend,columns=e.subcolumns,data=t[a]or e.default or{}}else
if e.readonly then
l[#l+1]=m(e,t[a])else
l[#l+1]=k(e,t[a],s[e.name])end
end
l[#l+1]="</td>"end
l[#l+1]="<td>"if#n<1 then
if h==true then
l[#l+1]=e.createSimpleButton("","icon-plus-sign",f)else
l[#l+1]=e.createSimpleButton("","icon-ok",u)end
l[#l+1]=" "l[#l+1]=e.createSimpleButton("","icon-remove",r)end
l[#l+1]="</td></tr>"for t,e in c(n)do
l[#l+1]="<tr class='additional-edit'>"l[#l+1]=a('<td colspan="%d">',d)l[#l+1]=a("<fieldset><legend>%s</legend>",e.legend)for t,a in i(e.columns)do
l[#l+1]=x(a,e.data[t],s[a.name])end
l[#l+1]="</fieldset>"l[#l+1]="</td><td></td>"l[#l+1]="</tr>"end
if#n>0 then
l[#l+1]=a('<tr> <td class="btn-col-OK" colspan="%d">',d)if not h then
l[#l+1]=e.createSimpleButton(o"Apply","",p(u))else
l[#l+1]=e.createSimpleButton(o"Save","",p(f))end
l[#l+1]=" "l[#l+1]=e.createSimpleButton(o"Cancel","",p(r))l[#l+1]="</td></tr>"end
return l
end
local function x(t,d,h,u,n,p,r)local l={}local s={button={class="btn-mini btn-table-edit tooltip-on",["data-placement"]="top",["data-original-title"]=o"Edit",}}local i={button={class="btn-mini btn-danger btn-table-delete tooltip-on",["data-placement"]="top",["data-original-title"]=o"Delete",}}for o,d in c(d)do
if n==o then
l[#l+1]=v(t,d,false,p)else
l[#l+1]="<tr>"for e,n in c(d)do
l[#l+1]=a('<td %s %s>',n~=""and(' data-title="'..t[e]["header"]..'"')or"",t[e]["additional_class"]or"")l[#l+1]=m(t[e],n)l[#l+1]="</td>"end
local t=""if h==true and r[o].canEdit then
if n~=0 then
s.button.class=s.button.class.." disabled"end
t=e.createSimpleButton("","icon-edit",s)end
l[#l+1]=" "if u==true and r[o].canDelete then
if n~=0 then
i.button.class=i.button.class.." disabled"end
t=t..e.createSimpleButton("","icon-remove-sign icon-large",i)end
if t~=""then
l[#l+1]=a("<td>%s</td>",t)end
l[#l+1]="</tr>"end
end
return l
end
local function m(s,r,i,o)local l={}local t={button={class="btn-table-new"}}local n="btn dropdown-toggle"if(s==true)then
if r~=0 then
t.button.class=t.button.class.." disabled"n=n.." disabled"end
l[#l+1]='<center><div class="btn-group">'l[#l+1]=e.createSimpleButton(i,"icon-plus-sign",t)if o~=nil then
l[#l+1]=a('<div class="%s" data-toggle="dropdown" tabindex="-1" ><span class="caret"></span></div>',n)l[#l+1]='<ul class="dropdown-menu">'for t,e in c(o)do
l[#l+1]=a('<li><a href="#" class="btn-table-new-list" data-listid="%d" >%s</a></li>',t,e.text)end
l[#l+1]='</ul>'end
l[#l+1]="</div></center>"end
return l
end
function e.createTable(s,g,n,h,p)f()local c={group={class="control-group"},table={class="table table-striped",id=n and n.tableid or"youforgottheid",["data-stateid"]=n and n.stateid,},}local r=n and not(n.canEdit==false)local i=n and b(n.editing)or 0
local f=n and b(n.minEntries)or 0
local d=(n and n.maxEntries)or S
local S=(n and n.createMsg)or o"Create new"local o=#g
local d=n and not(n.canAdd==false)and(o<d)local o=n and not(n.canDelete==false)and(o>f)local f=n and n.newList
local u=u.ctx.session
local b=n.tableid..".allowedindexes"t(c,h)local t=l(c["group"])local c=l(c["table"])local l=u:retrieve(b)or{}local e={e.createAlertBlock(n.errmsg,h),a("<div %s><table %s>",t,c),y(s,r or o),"<tbody>",x(s,g,r,o,i,p,l)}if(d==true)and(i==-1)then
e[#e+1]=v(s,{},true,p)end
e[#e+1]="</tbody></table>"e[#e+1]=m(d,i,S,f)e[#e+1]="</div>"return e
end
function e.createSimpleLight(o,c,s,n)local e={span={class="simple-desc",},light={class="light",},icon={class=n and a("light_icon fa %s",n)or"light_icon off",}}if o~=nil then
if n then
e.icon.class=e.icon.class..(h[o]or" off")else
e.light.class=e.light.class..(h[o]or" off")end
end
t(e,s)local t=l(e["span"])local o=l(e["light"])local e=l(e["icon"])if n then
return a("<span %s><div %s></div>%s</span>",t,e,c)else
return a("<span %s><div %s></div>%s</span>",t,o,c)end
end
function e.createLight(r,i,c,o)local n={group={class="control-group"},label={class="control-label"},controls={class="controls"},}t(n,o)local s=l(n["group"])local t=l(n["label"])local l=l(n["controls"])local e={a("<div %s><label %s>%s</label><div %s>",s,t,r,l),e.createSimpleLight(i,c,o),"</div></div>"}return e
end
function e.createSimpleSliderSelect(c,s,i,o,r)local n={slider={class="noUiSlider slider-select span2 no-margin horizontal",},slidertext={class="noUiSlider-text simple-desc",id="Slider_ID"},help={class="help-inline",},select={class="hide",},}t(n,o)local t=l(n["slider"])local d=l(n["slidertext"])local l=l(n["help"])local e={a("<div %s>",t),e.createSimpleInputSelect(c,s,i,n),a("</div><div %s></div>",d),e.createHelpText(r,o)}return e
end
function e.createSliderSelect(d,r,s,i,o,c)local n={group={class="control-group"},label={class="control-label"},controls={class="controls"},}if c~=nil then
n.group.class=n.group.class.." error"end
t(n,o)local u=l(n["group"])local t=l(n["label"])local l=l(n["controls"])local e={a("<div %s><label %s>%s</label><div %s>",u,t,d,l),e.createSimpleSliderSelect(r,s,i,o,c),"</div></div>"}return e
end
function e.createModalTabs(t)if(s(t)~="table")then
return nil
end
local e={ul={class="nav nav-tabs",}}local n={a("<ul %s>",l(e["ul"]))}for o,t in c(t)do
if t.active then
e["li"]={["class"]=t.active,}else
e["li"]={}end
e["a"]={["id"]=t.desc,["href"]="#",["data-remote"]=t.target,}local o=t.desc or""local t=l(e["li"])local e=l(e["a"])n[#n+1]=a("<li %s><a %s>%s</a></li>",t,e,o)end
n[#n+1]=[[</ul>]]return n
end
function e.createHeader(n,u,c,e,t,d)f()local l=""if s(e)=="number"then
l=" data-autorefresh='"..e.."'"end
local e={[[
 <div class="modal-header" ]]..l..[[>
    <div class="modal-header-title">
		<h2> ]]..n..[[</h2>
    </div>]]}e[#e+1]=[[<div class="modal-header-items">]]if s(t)=="table"then
local l={}for n,t in i(t)do
if s(t)=="string"then
l[#l+1]=a('%s="%s"',n,t)end
end
e[#e+1]=a('<span id="help" class="modal-action" %s><i class="icon-question-sign"></i> %s</span>',r(l," "),o"help")end
if c then
e[#e+1]=a('<span class="modal-action"><span class="modal-action-refresh" id="Refresh_id"><i class="icon-refresh"></i> %s</span></span>',o"refresh data")end
if d then
e[#e+1]=[[
        <span id = "btn-dhcp-reset" class = "modal-action">
          <img src = "../img/button-reload.png" alt = "Reload Icon" style = "width:25%"></img>
        </span>
      ]]end
if u then
e[#e+1]=a([[
        <span class="modal-action">
            <span class="modal-action-advanced hide" id="Hide_Advanced_id"><i class="icon-minus-sign"></i> %s</span>
            <span class="modal-action-advanced" id="Show_Advanced_id"><i class="icon-plus-sign"></i> %s</span>
        </span>
        ]],o"hide advanced",o"show advanced")end
e[#e+1]=[[
		</div>
		<div class="modal-action-close"><a href="#" class="button btn-primary btn-close" data-dismiss="modal"><i class="icon-remove"></i></a></div>
 </div>
    ]]return e
end
function e.createFooter()return a([[
     <div class="modal-footer">
      <div id="modal-no-change">
        <div id="close-config" class="btn btn-primary btn-large" data-dismiss="modal">%s</div>
      </div>
      <div id="modal-changes" class="hide">
        <div id="cancel-config" class="btn btn-large" data-dismiss="modal">%s</div>
        <div id="save-config" class="btn btn-primary btn-large">%s</div>
      </div>
    </div>
    ]],o"Close",o"Cancel",o"Save")end
function e.createCardHeader(s,n,c,r,i)local o
if n then
o=n:match("^.*/([^.]*).lp$")end
local o={header={class="header-title pull-left",["data-toggle"]="modal",["data-remote"]=n,["data-id"]=o,},div={class="settings",["data-toggle"]="modal",["data-remote"]=n,["data-id"]=o,id=s},icon={class="icon-cogs"}}if c and n then
o.header.class=o.header.class.." tooLongTitle"end
if not n or n==""then
o.header["data-toggle"]=nil
end
t(o,i)local d=l(o["header"])local t=l(o["div"])local o=l(o["icon"])local l={[[<div class="header">]],a("<div %s><p id=%s_tab>%s</p></div>",d,s,s)}l[#l+1]=[[<div class="header-items">]]if c and c~=""then
l[#l+1]=e.createSimpleSwitch(c,r,i)end
if n and n~=""then
l[#l+1]=a("<div %s><i %s ></i></div>",t,o)end
l[#l+1]=[[  </div>]]l[#l+1]=[[</div>]]return l
end
function e.createCardHeaderNoIcon(c,e,n,n,o)local n
if e then
n=e:match("^.*/([^.]*).lp$")end
local n={header={class="header-title pull-left",["data-toggle"]="modal",["data-remote"]=e,["data-id"]=n,style="white-space:nowrap;",},}if not e or e==""then
n.header["data-toggle"]=nil
end
t(n,o)local e=l(n["header"])local e={[[<div class="header">]],a("<div %s><p><u>%s</u></p></div>",e,c)}e[#e+1]=[[</div>]]return e
end
function e.createSwitchPort(o,c,s,i)local e={socket={class="socket",id=o},speed={class="socket-light align-left"},state={class="socket-light green align-right"}}local n=true
if s=="1000"then
e.speed.class=e.speed.class.." green"elseif s=="100"then
e.speed.class=e.speed.class.." orange"else
n=false
end
t(e,i)local t=l(e["socket"])local s=l(e["speed"])local l=l(e["state"])local e={a("<div %s><ul><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>",t),a("<p>%s</p>",o),[[<div class="socket-light off align-right" style="opacity:.5;"></div>]],[[<div class="socket-light off align-left" style="opacity:.5;"></div>]]}if c=="up"or c=="Up"then
e[#e+1]=a("<div %s></div>",l)end
if n then
e[#e+1]=a("<div %s></div>",s)end
e[#e+1]="</div>"return e
end
function e.createLanguageSelect(a,n,t)local l={}local a=g.listLanguages(a)if a and(#a>1)then
l[#l+1]=e.createSimpleInputSelect("webui_language",a,n,t)end
return l
end
function e.createBitLoadHistogram(n)local l={}local s=5
local c={}local e=1
local o=true
local t={}for e in w(n,"%d+")do
t[#t+1]=b(e)end
l[#l+1]='<pre style="letter-spacing:1px;color:gray;line-height:normal">'local n=#t
while o do
local l={}l[1+n+1]="\n"o=false
l[1]=a("%2d",e)for a=1,n do
if t[a]>=e then
o=true
l[a+1]="&#9608;"else
l[a+1]=" "end
end
if o then
c[e]=r(l,'')e=e+1
end
end
while e<=s do
c[e]={a("%2d\n",e)}e=e+1
end
for e=#c,1,-1 do
l[#l+1]=c[e]end
local e={"  "}e[1+n+1]="\n"for a=1,n do
if t[a]>9 then
e[a+1]="+"else
e[a+1]=t[a]end
end
l[#l+1]=r(e,'')e={"  "}local o="|               "local a=#t
while a>0 do
e[#e+1]=o
a=a-16
end
e[#e+1]="\n"l[#l+1]=r(e,'')e={"  "}local a=0
local t={[13]="   ",[14]="  ",[15]=" ",[16]=""}while a<n do
local l=a.."            "e[#e+1]=l..t[#l]a=a+16
end
e[#e+1]="\n"l[#l+1]=r(e,'')l[#l+1]="</pre>"return l
end
function e.createMessages(l)local e={}for l,t in c(l)do
local l=t.content
local t=t.level or"warning"if l then
e[#e+1]=a('<div class="alert alert-%s">',t)e[#e+1]=l
e[#e+1]="</div>"end
end
return e
end
function e.createInputSelectWithButton(p,h,u,r,d,s,o,c)local n={group={class="control-group"},label={class="control-label"},controls={class="controls"},}if c~=nil then
n.group.class=n.group.class.." error"end
t(n,o)local i=l(n["group"])local t=l(n["label"])local l=l(n["controls"])local e={a("<div %s><label %s>%s</label><div %s>",i,t,p,l),e.createSimpleInputSelect(h,u,r,o),e.createSimpleButton(d,s,o),e.createHelpText(c,o),"</div></div>"}return e
end
function e.createLabelWithButton(s,r,i,d,o,c)local n={group={class="control-group"},label={class="control-label"},controls={class="controls"},span={class="span2 simple-desc",},help={class="help-inline"}}if c~=nil then
n.group.class=n.group.class.." error"end
t(n,o)local t=l(n["group"])local u=l(n["label"])local h=l(n["controls"])local p=l(n["span"])local l=l(n["help"])local e={a("<div %s><label %s>%s</label><div %s><span %s>%s</span>",t,u,s,h,p,r),e.createSimpleButton(i,d,o),e.createHelpText(c,o),"</div></div>"}return e
end
function e.createTab(e,t)local l={}for a,e in c(e)do
local a=""if t==("/modals/"..e[1])then
a="active"end
l[#l+1]=string.format('<li class="%s"><a href="#" data-remote="/modals/%s">%s</a></li>',a,e[1],e[2])end
return l
end
function e.alertAttributes(a,l,t)local l={alert={class=l,id=t}}return e.createAlertBlock(a,l)end
return e