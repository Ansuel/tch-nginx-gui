local c=ngx
local l=type
local n={}local t="uimessages"local function o()local e=c.ctx.session
local e=e:retrieve(t)if l(e)~="table"then
e={}end
return e
end
local function l(n)local e=c.ctx.session
e:store(t,n)end
function n.pushMessage(t,n)local e=o()local o=true;for l,e in ipairs(e)do
if e.content==t and e.level==n then
o=false
break
end
end
if o then
e[#e+1]={content=t,level=n}l(e)end
end
function n.popMessage()local e=o()if#e==0 then
return nil
else
local n=e[#e]e[#e]=nil
l(e)return n.content,n.level
end
end
function n.popMessages()local e=o()l({})return e
end
return n