local e=require
local t=ipairs
local n=string.format
local r=e"datamodel"local c={ipaddr=true,ip6addr=true}local d={ipv6uniquelocaladdr=true,ipv6uniqueglobaladdr=true}local function l(e)local t=r.getPN("uci.network.interface.",true)local a
for r,t in pairs(t or{})do
a=t.path:match("@(%S+)%.")e[#e+1]=n('rpc.network.interface.@%s.ipaddr',a)e[#e+1]=n('rpc.network.interface.@%s.ip6addr',a)e[#e+1]=n('rpc.network.interface.@%s.ipv6uniquelocaladdr',a)e[#e+1]=n('rpc.network.interface.@%s.ipv6uniqueglobaladdr',a)e[#e+1]=n('rpc.network.interface.@%s.type',a)end
end
local function n(e)local a=r.getPN("uci.dhcp.dnsmasq.",true)for n,a in t(a or{})do
e[#e+1]=a.path.."hostname."e[#e+1]=a.path.."domain"end
end
local function o(a)local e=r.get({"rpc.ddns.ActiveServices"},false)local e=e and e[1]and e[1].value or""for e in e:gmatch("(%S+)")do
a[#a+1]=e..".domain"end
end
local function i()local e={"uci.system.system.@system[0].hostname"}n(e)l(e)o(e)return e
end
local function o(e)local a={}for n,e in t(e)do
if e.path:match("^rpc%.network%.interface%.")and e.param=="type"and e.value=="lan"then
a[e.path]=true
end
end
return a
end
local function n(e)return e and e:lower()end
local function l(a)a=n(a)local r=r.get(i(),false)or{}local l=o(r)for o,e in t(r)do
if e.path=="uci.system.system.@system[0]."then
if a==n(e.value)then
return true
end
elseif e.path:match("^uci%.dhcp%.dnsmasq%.@.*%.hostname%.")then
if e.param=="value"and a==n(e.value)then
return true
else
for r,t in t(r)do
if t.param=="domain"and t.path:match("^uci%.dhcp%.dnsmasq%.")then
if a==n(e.value.."."..t.value)then
return true
end
end
end
end
elseif e.path:match("^rpc%.network%.interface%.")then
if c[e.param]or(d[e.param]and l[e.path])then
if e.value~=""and a==n(e.value:match("^%S+"))then
return true
end
end
elseif e.path:match("^uci%.ddns%.service%.")then
if n(e.value)==a then
return true
end
end
end
return false
end
return{refersToUs=l,}