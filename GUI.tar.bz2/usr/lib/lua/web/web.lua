local a,t,l,s,h,n,c
local _,i,g,p,u,b,x=select,type,unpack,pairs,ipairs,getfenv,loadfile
local e={['<']="&lt;",['>']="&gt;",['&']="&amp;",['"']="&quot;",["'"]="&#39;",['/']="&#47;"}local function o(n)return l(n:gsub('[<>&"\'/]',e))end
local d=require("web.lp")local e=require("web.taint")e.set_escape_function(o)require("datamodel").enable_tainting()local f=require'web.intl'a,t,l,s,h,n,c=string.taint,string.istainted,string.untaint,string.match,string.format,string.byte,string.sub
local e=ngx
do
local function r(n)for l,e in u(n)do
if t(e)then
n[l]=o(e)elseif i(e)=="table"then
n[l]=r(e)end
end
return n
end
local function c(l,...)local a=_("#",...)if a==1 then
local e=...if t(e)then
return l(o(e))end
if i(e)=="table"then
return l(r(e))end
return l(e)elseif a==2 then
local n,e=...if t(n)then
n=o(n)elseif i(n)=="table"then
n=r(n)end
if t(e)then
e=o(e)elseif i(e)=="table"then
e=r(e)end
return l(n,e)else
local e={...}for l=1,a do
local n=e[l]if t(n)then
e[l]=o(n)elseif i(n)=="table"then
e[l]=r(n)end
end
return l(g(e))end
end
local n=e.print
local o=e.say
e.print=function(...)return c(n,...)end
e.say=function(...)return c(o,...)end
local function o(n)for l,e in p(n)do
local t=i(e)if t=="table"then
for t,n in u(e)do
e[t]=a(n)end
elseif t~="boolean"then
n[l]=a(e)end
end
return n
end
local n=e.req.get_uri_args
e.req.get_uri_args=function(...)return o(n(...))end
local n=e.req.get_post_args
e.req.get_post_args=function(...)e.req.read_body()local n,t=n(...)if n then
local e=e.ctx.session
if e then
e:checkCSRFtoken(n.CSRFtoken)end
n=o(n)end
return n,t
end
local n=getmetatable(e.var)local i=n.__index
local o=n.__newindex
n.__index=function(t,e)local e=i(t,e)if e then
return a(e)end
end
n.__newindex=function(t,e,n)return o(t,e,l(n))end
local o=e.escape_uri
e.escape_uri=function(e)local n=t(e)e=o(l(e))if n then
e=a(e)end
return e
end
local n=e.unescape_uri
e.unescape_uri=function(e)local t=t(e)e=n(l(e))if t then
e=a(e)end
return e
end
local t=e.exit
e.exit=function(n,l)if n>=400 then
e.status=n
e.header.content_type="text/html"e.header.error_msg=l
d.setpath("/www/docroot/")d.include("error.lp")return t(e.HTTP_OK)end
return t(n)end
end
local r={html_escape=o}function r.printf(...)e.print(h(...))end
local function u(n)e.log(e.NOTICE,n)end
local function h(o)local a=o:match("%.([^.]+)$")local n,t
local i="text/html"if a=="lp"then
n=d.load(o,l(e.var.uri))elseif a=="lua"then
i="text/plain"n,t=x(o)if not n then
e.log(e.CRIT,t)return e.exit(e.HTTP_INTERNAL_SERVER_ERROR,t)end
end
return n,i
end
local function o(o)local t=e.req.get_headers()local n=t['cookie']local l
if n then
l=s(n,'webui_language=([%a%-]+);?')end
local t=f.findLanguage('webui-core',l,t['accept-language'])e.header['Content-Language']=t
local n=b(o)local e=n.gettext or f.load_gettext(u)n.gettext=e
n.T=e.gettext
n.N=e.ngettext
e.language(t)end
function r.process(n)n=l(n or e.var.request_filename)e.header.cache_control="no-cache"local n,t=h(n)if not n then
e.exit(404)end
e.header.content_type=t
o(n)n()end
do
local b=n("=")local _=n(";")local s=n(" ")local g=n("\t")local function h(t,l,n)n=a(n)local e=t[l]if not e then
t[l]=n
else
if i(e)=="table"then
e[#e+1]=n
else
t[l]={e,n}end
end
end
function r.get_cookies()local u=1
local f=2
local d=3
local i={}local t=l(e.var.http_cookie)if not t then
return i
end
local p=#t
local o=d
local l=1
local e=1
local a,r
while e<=p do
if o==u then
if n(t,e)==b then
a=c(t,l,e-1)o=f
l=e+1
end
elseif o==f then
if n(t,e)==_ or
n(t,e)==s or
n(t,e)==g then
r=c(t,l,e-1)h(i,a,r)a,r=nil,nil
o=d
l=e+1
end
elseif o==d then
if n(t,e)~=s and
n(t,e)~=g then
o=u
l=e
e=e-1
end
end
e=e+1
end
if a~=nil and r==nil then
h(i,a,c(t,l))end
return i
end
end
local e
function r.isDemoBuild()if e==nil then
local n=require("datamodel").get("uci.version.version.@version[0].mask")if n then
local n=n[1].value
e=tonumber(n:sub(3,3))%2==1 or n:sub(4,4)=='9'else
e=true
end
end
return e
end
return r