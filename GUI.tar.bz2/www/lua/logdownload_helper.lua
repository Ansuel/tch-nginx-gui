local r={}gettext.textdomain('webui-core')local c=require("web.content_helper")local e,s=ngx,string.format
local a=require("datamodel")local function i(o,d,a)local r=o.."state"local n=.25
local i=5
local l=0
local t
repeat
e.sleep(n)l=l+n
t={state=r,}c.getExactContent(t)if t.state~="Requested"then
break
end
until(l>=i)if a then
os.remove(a)end
if t.state~="Complete"then
if t.state=="Requested"then
e.log(e.ERR,"Timeout on ",o)else
e.log(e.ERR,s('Error on %s (state="%s")',o,t.state))end
if d then
e.print('{ "error":"10" }')e.exit(e.OK)else
e.exit(e.HTTP_INTERNAL_SERVER_ERROR)end
end
end
function r.export_log(n)local t="rpc.system.log.download."local l=t.."way"local o=t.."state"local n=n or"logread"a.set(l,n)a.set(o,"Requested")i(t)e.header.content_disposition="attachment; filename=log.txt"e.header.content_type="application/octet-stream"e.header.set_cookie="fileDownload=true; Path=/"local t=("/tmp/log.msg")local t=io.open(t,"r")if t then
e.print(t:read("*all"))t:close()a.set(o,"None")end
e.exit(e.HTTP_OK)end
return r