local s,e=ipairs,string
local t=e.format
local l=require("datamodel")local a={}local o={}local function n(e)if a[e]then
return a[e]end
local t=t("rpc.wireless.radio.@%s.supported_frequency_bands",e)local l=l.get(t)[1].value
a[e]=l
return l
end
function o.getSSID()local r={}for a,e in s(l.getPN("rpc.wireless.ssid.",true))do
local e=e.path
local t=l.get(e.."radio",e.."ssid",e.."oper_state")if t then
local o=l.get(e.."ap_display_name")[1].value
local a
if o~=""then
a=o
elseif l.get(e.."stb")[1].value=="1"then
a="IPTV"else
a=t[2].value
end
r[#r+1]={radio=n(t[1].value),ssid=a,state=t[3].value,}end
end
return r
end
return o