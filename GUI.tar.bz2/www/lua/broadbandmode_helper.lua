gettext.textdomain('webui-core')local e=require("datamodel")local n=require("web.ui_helper")local n=require("web.content_helper")local n=require("web.uimessage_helper")local n=require("web.post_helper")format,match=string.format,string.match
local a=require("transformer.shared.sfp").readSFPFlag()local n=e.get("sys.eth.port.@eth4.status")if n and n[1].value then
n="eth4"else
n="eth3"end
local function i()if e.get("uci.wansensing.global.enable")then
return e.get("uci.wansensing.global.enable")[1].value
end
return""end
local function l(n)for t,e in ipairs(e.getPN("uci.network.device.",true))do
local e=match(e.path,"uci%.network%.device%.@.*"..n..".*%.")if e then
return(e:gsub("uci%.network%.device%.",""):gsub("%.",""))end
end
return nil
end
local function t()local e=require("ubus")local e=e.connect()if not e then
return"Failed to connect to ubusd"end
e:call("network","restart",{})e:close()end
local t={}t[#t+1]={name="adsl",default=false,description="ADSL2+",view="broadband-adsl-advanced.lp",card="002_broadband_xdsl.lp",check=function()if i()=="1"then
local e=e.get("uci.wansensing.global.l2type")[1].value
if e=="ADSL"then
return true
end
else
local e=e.get("uci.network.interface.@wan.ifname")[1].value
local e=match(e,"atm")if e then
return true
end
end
end,operations=function()local l=l("atm")or"@wanatmwan"local t=e.get("uci.network.device."..l..".ifname")if t then
local n=e.get("uci.network.device."..l..".name")[1].value
t=e.get("uci.network.device."..l..".ifname")[1].value
if t~=""and t~=nil then
e.set("uci.network.interface.@wan.ifname",n)else
e.set("uci.network.interface.@wan.ifname","atmwan")end
else
e.set("uci.network.interface.@wan.ifname","atmwan")end
if a==1 then
e.set("uci.ethernet.globals.eth4lanwanmode","1")end
if n=="eth3"then
local t=e.get("uci.network.interface.@lan.ifname")[1].value
e.set({["uci.network.interface.@lan.ifname"]=t..' '..n,["uci.ethernet.port.@eth3.wan"]="0"})end
e.set("uci.wansensing.global.l2type","ADSL")end,}t[#t+1]={name="vdsl",default=true,description="VDSL2",view="broadband-vdsl-advanced.lp",card="002_broadband_xdsl.lp",check=function()if i()=="1"then
local e=e.get("uci.wansensing.global.l2type")[1].value
if e=="VDSL"then
return true
end
else
local e=e.get("uci.network.interface.@wan.ifname")[1].value
local e=match(e,"ptm0")if e then
return true
end
end
end,operations=function()local l=l("ptm")or"@wanptm0"local t=e.get("uci.network.device."..l..".ifname")if t then
local n=e.get("uci.network.device."..l..".name")[1].value
t=e.get("uci.network.device."..l..".ifname")[1].value
if t~=""and t~=nil then
e.set("uci.network.interface.@wan.ifname",n)else
e.set("uci.network.interface.@wan.ifname","ptm0")end
else
e.set("uci.network.interface.@wan.ifname","ptm0")end
if a==1 then
e.set("uci.ethernet.globals.eth4lanwanmode","1")end
if n=="eth3"then
local t=e.get("uci.network.interface.@lan.ifname")[1].value
e.set({["uci.network.interface.@lan.ifname"]=t..' '..n,["uci.ethernet.port.@eth3.wan"]="0"})end
e.set("uci.wansensing.global.l2type","VDSL")end,}t[#t+1]={name="ethernet",default=false,description="Ethernet",view="broadband-ethernet-advanced.lp",card="002_broadband_ethernet.lp",check=function()if i()=="1"then
local e=e.get("uci.wansensing.global.l2type")[1].value
if e=="ETH"then
return true
end
else
local t=e.get("uci.network.interface.@wan.ifname")[1].value
local n=match(t,n)or match(t,"lan")if a==1 then
local e=e.get("uci.ethernet.globals.eth4lanwanmode")[1].value
if n and e=="0"then
return true
end
else
if n then
return true
end
end
end
end,operations=function()local l=l(n)or"@waneth4"local t=e.get("uci.network.device."..l..".ifname")if t then
local a=e.get("uci.network.device."..l..".name")[1].value
t=e.get("uci.network.device."..l..".ifname")[1].value
if t~=""and t~=nil then
e.set("uci.network.interface.@wan.ifname",a)else
e.set("uci.network.interface.@wan.ifname",n)end
else
e.set("uci.network.interface.@wan.ifname",n)end
if a==1 then
e.set("uci.ethernet.globals.eth4lanwanmode","0")end
if n=="eth3"then
local t=e.get("uci.network.interface.@lan.ifname")[1].value
e.set({["uci.network.interface.@lan.ifname"]=string.gsub(string.gsub(t,n,""),"%s$",""),["uci.ethernet.port.@eth3.wan"]="1"})end
e.set("uci.wansensing.global.l2type","ETH")end,}if a==1 then
t[#t+1]={name="gpon",default=false,description="GPON",view="broadband-gpon-advanced.lp",card="002_broadband_gpon.lp",check=function()if i()=="1"then
local n=e.get("uci.wansensing.global.l2type")[1].value
local e=e.get("rpc.optical.Interface.1.Status")local e=e and e[1].value or""if n=="SFP"or e=="Dormant"then
return true
end
else
local t=e.get("uci.network.interface.@wan.ifname")[1].value
local n=match(t,n)if a==1 then
local e=e.get("uci.ethernet.globals.eth4lanwanmode")[1].value
if n and e=="1"then
return true
end
else
if n then
return true
end
end
end
end,operations=function()local a=l(n)or"@waneth4"local t=e.get("uci.network.device."..a..".ifname")if t then
local l=e.get("uci.network.device."..a..".name")[1].value
t=e.get("uci.network.device."..a..".ifname")[1].value
if t~=""and t~=nil then
e.set("uci.network.interface.@wan.ifname",l)else
e.set("uci.network.interface.@wan.ifname",n)end
else
e.set("uci.network.interface.@wan.ifname",n)end
e.set("uci.ethernet.globals.eth4lanwanmode","1")e.set("uci.wansensing.global.l2type","SFP")end,}end
return t