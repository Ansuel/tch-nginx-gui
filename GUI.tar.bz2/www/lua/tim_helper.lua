local n=require("web.intl")local function e(n)ngx.log(ngx.NOTICE,n)end
local n=n.load_gettext(e)local e=n.gettext
local t=n.ngettext
local r,t=math.floor,string.match
local s=require("web.taint").untaint_mt
local t=require("web.post_helper")local i=require("bit")local o=require("datamodel")local function m()n.language(ngx.header['Content-Language'])end
n.textdomain('webui-core')local a={}local function l(t)if t then
local n=0
n=n+3*(r(t/10000000)%10)n=n+(r(t/1000000)%10)n=n+3*(r(t/100000)%10)n=n+(r(t/10000)%10)n=n+3*(r(t/1000)%10)n=n+(r(t/100)%10)n=n+3*(r(t/10)%10)n=n+(t%10)if 0==(n%10)then
return true
end
end
return nil,e"Invalid Pin."end
function a.validateWPSPIN(n)local t=e"PIN code must be composed of 4 or 8 digits with potentially a dash or space in the middle."if n==nil or#n==0 then
return true
end
local a=n:match("^(%d%d%d%d)$")local e,n=n:match("^(%d%d%d%d)[%-%s]?(%d%d%d%d)$")if a then
return true
end
if e and n then
local n=tonumber(e..n)return l(n)end
return nil,t
end
function a.validateWEP(n)if n==nil or(#n~=5 and#n~=10 and#n~=13 and#n~=26)then
return nil,e"Invalid length, a WEP key must be 5, 10, 13 or 26 characters long, length of 10 and 26 can only contain the letters A to F or digits"end
if(#n==10 or#n==26)and(not n:match("^[%x]+$"))then
return nil,e"A WEP key of length 10 or 26 can only contain the letters A to F or digits"end
return true
end
function a.isWWANIP(n)local e="wwan"if n and n:match("192.168.0.")then
return true,e
end
return false
end
function a.isIPinOtherRange(n,e,c,u)local r=t.validateStringIsIP(n)and t.ipv42num(n)local e=t.validateStringIsIP(e)and t.ipv42num(e)local d=t.ipv42num(n)local a,l
if r and e then
a=i.band(r,e)l=i.bor(a,i.bnot(e))end
for n,e in pairs(c)do
if e.paramindex~=u then
local n=o.get("uci.network.interface.@"..e.paramindex..".ipaddr")[1].value
local r=o.get("uci.network.interface.@"..e.paramindex..".netmask")[1].value
local o=t.validateStringIsIP(n)and t.ipv42num(n)local r=t.validateStringIsIP(r)and t.ipv42num(r)local n,t
if o and r then
n=i.band(o,r)t=i.bor(n,i.bnot(r))end
if n and t then
if d>=n and d<=t then
return true,e.paramindex
end
if a and l then
if a<=n and n<=l then
return true,e.paramindex
end
end
end
end
end
end
function a.ethtrans()m()return{eth_infinit=e"infinite"}end
local function r(n)local e=e"Input must be a whole number."if not(n and n:match("^%d+$"))then
return nil,e
end
return true
end
function a.validateStringIsLeaseTime(n)if not n then
return nil,e"Invalid value."end
local t="^(%d+)([wdhms])$"local a=setmetatable({s=2147483647,m=35791394,h=596523,d=24855,w=3551,},s)local n,t=n:match(t)n=n and tonumber(n)if not n or n<1 then
return nil,e"Invalid value; enter a number greater than 0, followed by 's' for seconds or 'm' for minutes or 'h' for hours or 'd' for days or 'w' for weeks. No spaces."end
if(((t=="s")and(n<120))or((t=="m")and(n<2)))then
return nil,e"The minimum leasetime must be 120 seconds or 2 minutes."elseif a[t]and n>a[t]then
return nil,e"The Maximum leasetime must be 3551 weeks or 24855 days or 596523 hours or 35791394 minutes or 2147483647 seconds."end
return true
end
function a.validateRegExpire(t)local n=tonumber(t)if n and n>=60 and n<=600000 and r(t)then
return true
end
return nil,e"Expire Time is invalid. It should be a whole number, between 60 and 600000."end
function a.getValidateNumberInRange(a,t)local n=e"Input must be a number"if a and t then
n=string.format(e"Input must be a number between %d and %d included",a,t)elseif not a and not t then
n=e"Input must be a number"elseif not a then
n=string.format(e"Input must be a number smaller than %d included",t)elseif not t then
n=string.format(e"Input must be a number greater than %d included",a)end
return function(r)local e=tonumber(r)local r=string.find(r,"[^%d]+")if r then
return nil,n
end
if not e then
return nil,n
end
if a and e<a then
return nil,n
end
if t and e>t then
return nil,n
end
return true
end
end
return a