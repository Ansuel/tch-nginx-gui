local e={}function e.get_usb_label(e)return e:match('.*%-(%d+)')end
return e