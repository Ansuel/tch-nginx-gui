local t=require("web.content_helper")local n={}local o={["broadband.lp"]=true,["internet.lp"]=true,}function n.get_limit_info()local n=false
local e={wan_proto="uci.network.interface.@wan.proto",wwan_proto="uci.network.interface.@wwan.proto",wan6_proto="uci.network.interface.@wan6.proto"}t.getExactContent(e)if e.wan_proto=='mobiled'and
e.wwan_proto=='mobiled'and
e.wan6_proto=='mobiled'then
n=true
end
return{isLTEBoard=n}end
function n.card_limited(e,n)if e.isLTEBoard then
return o[n]end
return false
end
return n