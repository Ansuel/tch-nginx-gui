local e=require("lfs")local r={}function r.isGPONBoard()local n=false
if e.attributes("/proc/rip/011b","mode")=="file"then
local e=io.popen("hexdump -n 1 /proc/rip/011b|awk '{print $2}'")if e then
for r in e:lines()do
local e=string.sub(r,1,2)if e=="01"or e=="02"then
n=true
end
end
e:close()end
end
return n
end
return r