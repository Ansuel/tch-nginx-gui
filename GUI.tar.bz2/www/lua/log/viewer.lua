local l=require
local i=table.sort
local e=l("datamodel")local function t(l)local o=1
local n=#l
while o<n do
l[o],l[n]=l[n],l[o]o=o+1
n=n-1
end
end
local function u()local l=e.get("sys.log.devicelog")l=l[1].value
return l
end
local function s(l,c,o)local n={}local r={}o=o or{}local e="([^%s]+%s+%d+ %d+:%d+:%d+) [^%s]+ ([^%s]+) ([^%s]+): ([^\n]+)"for t,d,e,a in l:gmatch(e)do
local l=string.gsub(e,"%[%d+%]$","")if l==""then
l="others"end
if not c or l==c then
n[#n+1]={t,d,e,a}end
if not r[l]then
o[#o+1]={l,l}r[l]=true
end
end
return n,o
end
local n=2^32
local function c(l,o)local e=l._order or n
local n=o._order or n
if e==n then
return l[1]<o[1]else
return e<n
end
end
local function n(o,...)local l={}for n,o in ipairs{o,...}do
o._order=n
l[#l+1]=o
end
return l
end
local function r(e,l,...)local o=n(l,...)local l=u()local l,o=s(l,e,o)t(l)i(o,c)return l,o
end
return{load=r}