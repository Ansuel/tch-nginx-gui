local n=require("web.ui_helper")local a={}function a.createModalTab(e)local c=ngx.var.uri
local a={}local l=ngx.ctx.session
for n,e in ipairs(e)do
if l:hasAccess("/modals/"..e[1])then
local l=nil
if c==("/modals/"..e[1])then
l="active"end
local e={desc=e[2],active=l,target="/modals/"..e[1]}table.insert(a,e)end
end
ngx.print(n.createModalTabs(a))end
return a