local t=ngx
local h,d=string.find,require
local f=table.sort
local r=d("lfs")local n=d("uci"):cursor()local o
local l={}local function a()local e={}n:foreach('web','rule',function(n)e[n['.name']]=n
end)n:unload('web')return e
end
local a=a()local function c()local e={}n:foreach('web','card',function(n)local l=a[n.modal]if l and not n['.anonymous']then
n.modal=l.target
n.hide=(n.hide~='0')n.card=n.card:gsub("^%d+_","")e[n.card]=n
end
end)n:unload('web')return e
end
local c=c()local function i(l,e,n)local n=e[n]if n then
local e
if n.modal then
e=l:hasAccess(n.modal)end
if not e and n.hide then
return false
end
end
return true
end
local e
do
local n
n,e=pcall(d,"cards_limiter")if not n then
e=nil
end
end
local function u()local n=e and e.get_limit_info
if n then
return n()end
end
local function d(a,o,l)local n=e and e.card_limited
if n then
return n(a,o,l)end
return false
end
function l.setpath(n)o=n
end
local e={}local function e(e,o)local e=nil
n:foreach('web','card',function(l)local n=a[l.modal]if n and not l['.anonymous']then
if val1==o then
e=n.target
end
end
end)n:unload('web')return e
end
function l.get_card_from_modal(o)local d=t.ctx.session
local e
n:foreach('web','card',function(n)local l=a[n.modal]if l and not n['.anonymous']then
if l.target==o then
e=n.card
end
end
end)n:unload('web')if e and i(d,c,(e:gsub("^%d+_","")))then
return e
end
return
end
function l.get_modal_from_card(o)local l
n:foreach('web','card',function(n)local e=a[n.modal]if e and not n['.anonymous']then
if n.card==o then
l=e.target
end
end
end)n:unload('web')return l
end
function l.cards()local a=t.ctx.session
local t=u()local n={}if o and r.attributes(o,'mode')=='directory'then
for e in r.dir(o)do
if h(e,"%.lp$")then
local l=e:gsub("^%d+_","")if i(a,c,l)and not d(t,l,o)then
n[#n+1]=e
end
end
end
end
f(n)return n
end
return l