local e,r=require,ipairs
local t=e("datamodel")local i=string.match
local n={}function n.getBandSteerPeerIface(s)local n=i(s,".*(_%d+)")local e=t.get("uci.wireless.wifi-iface.")local t="uci%.wireless%.wifi%-iface%.@([^%.]*)%."if e then
for r,e in r(e)do
if e.param=="ssid"then
local e=e.path:match(t)if e~=s then
if not n then
if not i(e,".*(_%d+)")then
return e
end
else
if n==i(e,".*(_%d+)")then
return e
end
end
end
end
end
end
return nil
end
function n.isBaseIface(e)if"0"==i(e,"%d+")then
return true
else
return false
end
end
function n.getBandSteerId(e)local e=i(e,".*_(%d+)")if not e then
return string.format("%s","bs0")else
return string.format("%s","bs"..e)end
end
function n.disableBandSteer(e)if""==e.bsid or"off"==e.bsid then
return true
else
e.bsid="off"e.bspeerid="off"local n=t.get("uci.env.var.commonssid_suffix")[1].value
if e.bspifacessid then
e.bspifacessid=e.ssid..n
else
e.ssid=e.ssid..n
end
end
return true
end
return n