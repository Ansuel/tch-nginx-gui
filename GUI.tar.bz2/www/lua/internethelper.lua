local r=require("datamodel")local i={}local function n(e)if r.get(e)[1].value~=""then
return true
end
return false
end
function i.getIpv6Content()local e={ip6addr="",ip6prefix="rpc.network.interface.@wan.ip6prefix",}for i,r in ipairs(r.getPN("rpc.network.interface.",true))do
local r=string.match(r.path,"rpc%.network%.interface%.@([^%.]+)%.")if r then
if r=="6rd"then
e.ip6addr="rpc.network.interface.@6rd.ip6addr"if n(e.ip6addr)then
e.ip6prefix="rpc.network.interface.@6rd.ip6prefix"e.dnsv6="rpc.network.interface.@6rd.dnsservers"break
end
elseif r=="wan_6"then
e.ip6addr="rpc.network.interface.@wan_6.ip6addr"if n(e.ip6addr)then
e.ip6prefix="rpc.network.interface.@wan_6.ip6prefix"e.dnsv6="rpc.network.interface.@wan_6.dnsservers"break
end
elseif r=="wan6"then
e.ip6addr="rpc.network.interface.@wan6.ip6addr"if n(e.ip6addr)then
e.ip6prefix="rpc.network.interface.@wan6.ip6prefix"e.dnsv6="rpc.network.interface.@wan6.dnsservers"break
end
elseif r=="wan"then
e.ip6addr="rpc.network.interface.@wan.ip6addr"if n(e.ip6addr)then
e.ip6prefix="rpc.network.interface.@wan.ip6prefix"break
end
end
end
end
return e
end
return i