local n=ngx
local a,e,e,e,e=pairs,ipairs,tonumber,type,setmetatable
local s,c,g,t,e=string.format,string.match,string.find,string.gsub,require
local d=table.sort
local r=e("web.content_helper")local o=e("web.uimessage_helper")local f=e("datamodel")local l=e("lfs")local i=e("web.intl")local function t(e)n.log(n.NOTICE,e)end
local e=i.load_gettext(t)local t=e.gettext
local i=e.ngettext
local function i()e.language(n.header['Content-Language'])end
e.textdomain('web-framework-tch')local e
module("wizard")function setpath(n)e=n
end
function cards()local n={}if e and l.attributes(e,'mode')=='directory'then
for e in l.dir(e)do
if g(e,"%.lp$")then
n[#n+1]=e
end
end
end
d(n)return n
end
function createFooter()return s([[
     <div class="modal-footer">
      <div id="modal-changes">
        <div id="wizard-previous" class="btn btn-primary btn-large">%s</div>
        <div id="wizard-next" class="btn btn-primary btn-large">%s</div>
        <div id="wizard-complete" class="btn btn-primary btn-large">%s</div>
        <div id="cancel-config" class="btn btn-primary btn-large" data-dismiss="modal">%s</div>
      </div>
    </div>
    ]],t"Back",t"Next",t"Finish",t"Exit")end
function handleQuery(l,g)i()local e={}local s={}for n,t in a(l)do
e[n]=t
end
local i,d=r.getExactContent(e)if not i then
o.pushMessage(d,"error")return e,s
end
if n.var.request_method=="POST"and n.var.content_type and c(n.var.content_type,"application/x%-www%-form%-urlencoded")then
local i=n.req.get_post_args()if(i["action"]=="SAVE"or i["action"]=="VALIDATE")then
local d={}for e,n in a(e)do
d[e]=n
end
for n,t in a(i)do
e[n]=t
end
local c
c,s=r.validateObject(e,g)if c then
if i["action"]=="SAVE"then
local s,i=r.setObject(e,l)if s then
s,i=f.apply()for n,t in a(l)do
if not e[n]then
e[n]=d[n]end
end
if not s then
n.log(n.ERR,"apply failed: "..i)o.pushMessage(t"Error while applying changes","error")else
o.pushMessage(t"Changes saved successfully","success")end
else
n.log(n.ERR,"setObject failed: "..i)o.pushMessage(t"Error while saving changes","error")for t,n in a(l)do
e[t]=n
end
r.getExactContent(e)end
elseif i["action"]=="VALIDATE"then
for n,t in a(l)do
if not e[n]then
e[n]=d[n]end
end
end
else
o.pushMessage(t"Some parameters failed validation","error")end
end
end
return e,s
end