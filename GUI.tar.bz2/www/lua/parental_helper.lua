local t={}gettext.textdomain('webui-core')local e=require("web.post_helper")local o=require("web.content_helper")local a=require("datamodel")local n="rpc.wifitod."local m="uci.tod.host."local p,l=string.format,string.match
local i,s=string.gsub,string.untaint
local d=require("web.uinetwork_helper")local n=string
local n=tonumber
local h
local r=ngx
local y=e.validateQTN
local w=e.getAndValidation
local function c()gettext.language(r.header['Content-Language'])end
local function r(e)if not e then return nil end
for t,a in pairs(e)do
local a=l(t,"%[%s*([%x:]+)%s*%]")if a then
e[t]=a
end
end
return e
end
local function f(t)local e={}if type(t)~="table"then return e end
for t,a in pairs(t)do
e[a]=t
end
return e
end
function t.get_hosts_ac()return r(d.getAutocompleteHostsListIPv4())end
local function r(t,e,r)local a="^(%d+):(%d+)$"local t={l(t,a)}if#t==2 then
if e["start_time"]==e["stop_time"]then
return nil,T"Start and Stop time cannot be the same"end
local a=n(t[1])local t=n(t[2])if a<0 or a>23 then
return nil,T"Invalid hour, must be between 0 and 23"end
if t<0 or t>59 then
return nil,T"Invalid minutes, must be between 0 and 59"end
if r=="stop_time"then
local t=i(s(e["start_time"]),":","")local e=i(s(e["stop_time"]),":","")if n(t)>n(e)then
return nil,T"The time range is incorrect"end
end
return true
else
return nil,T"Invalid time (must be hh:mm)"end
end
local _=e.getValidateInCheckboxgroup
local d=e.getValidateInEnumSelect
local g=e.validateStringIsMAC
local u=e.validateBoolean
local function n()return{{"Mon",T"Mon."},{"Tue",T"Tue."},{"Wed",T"Wed."},{"Thu",T"Thu."},{"Fri",T"Fri."},{"Sat",T"Sat."},{"Sun",T"Sun."},}end
local function i(a,t,e)local n=_(n())local a,n=n(a,t,e)if not a then
return a,n
end
for a=#t[e],1,-1 do
if t[e][a]==""then
table.remove(t[e],a)end
end
return true
end
local function k(e,t)return e["id"]<t["id"]end
function t.mac_to_hostname(t)local e=""if not t then return e end
local a=h[t]if a then
e=l(a,"(%S+)%s+%(")or"Unknown-"..t
else
e="Unknown-"..t
end
return e
end
local function _(e)if type(e)~="table"then
return
end
for a,e in ipairs(e)do
e[2]=t.mac_to_hostname(s(e[2]))end
end
function t.getTod()c()local e={{"allow",T"Allow"},{"block",T"Block"},}local a={{header=T"Status",name="enabled",param="enabled",type="light",readonly=true,attr={input={class="span1"}},},{header=T"Hostname",name="id",param="id",type="text",readonly=true,attr={input={class="span3"}},},{header=T"Start Time",name="start_time",param="start_time",type="text",readonly=true,attr={input={class="span2"}},},{header=T"Stop Time",name="stop_time",param="stop_time",type="text",readonly=true,attr={input={class="span2"}},},{header=T"Mode",name="mode",param="mode",type="text",readonly=true,attr={input={class="span2"}},},{header=T"Day of week",name="weekdays",param="weekdays",values=n(),type="checkboxgroup",readonly=true,attr={input={class="span1"}},},{header="",legend=T"Time of day access control",name="timeofday",type="aggregate",synthesis=nil,subcolumns={{header=T"Enabled",name="enabled",param="enabled",type="switch",default="1",attr={switch={class="inline"}},},{header=T"MAC address",name="id",param="id",type="text",attr={input={class="span2",maxlength="17"},autocomplete=t.get_hosts_ac()},},{header=T"Mode",name="mode",param="mode",type="select",values=e,default="allow",attr={select={class="span2"}},},{header=T"Start Time",name="start_time",param="start_time",type="text",default="00:00",attr={input={class="span2",id="starttime",style="cursor:pointer;"}},},{header=T"Stop Time",name="stop_time",param="stop_time",type="text",default="23:59",attr={input={class="span2",id="stoptime",style="cursor:pointer;"}},},{header=T"Day of week",name="weekdays",param="weekdays",type="checkboxgroup",values=n(),attr={checkbox={class="inline"}},},}},}local l={["mode"]=d(e),["start_time"]=r,["stop_time"]=r,["weekdays"]=i,["enabled"]=u,["id"]=w(g,y)}local n={["type"]="mac",}local e=t.get_hosts_ac()a[7].subcolumns[2].attr.autocomplete=e
h=f(e)return{columns=a,valid=l,default=n,sort_func=k,mac_to_hostname=_,}end
function t.getTodwifi()c()local function o()local n={}for t,e in ipairs(a.getPN("rpc.wireless.ap.",true))do
local r=l(e.path,"rpc%.wireless%.ap%.@([^%.]+)%.")local e=a.get("rpc.wireless.ap.@"..r..".ssid")e=e and e[1].value or nil
if e then
local t=a.get("rpc.wireless.ssid.@"..e..".radio")if t and t[1].value then
t=l(t[1].value,"radio_5G")and"5GHz"or"2.4GHz"end
local e=a.get("rpc.wireless.ssid.@"..e..".ssid")e=e and e[1].value
n[#n+1]={r,e.." ("..t..")"}end
end
return n
end
local e={{"on",T"On"},{"off",T"Off"},}local t={{header=T"Status",name="enabled",param="enabled",type="light",readonly=true,attr={input={class="span1"}},},{header=T"Access Point",name="ap",param="ap",type="text",readonly=true,attr={input={class="span3"}},},{header=T"Start Time",name="start_time",param="start_time",type="text",readonly=true,attr={input={class="span2"}},},{header=T"Stop Time",name="stop_time",param="stop_time",type="text",readonly=true,attr={input={class="span2"}},},{header=T"AP State",name="mode",param="mode",type="text",readonly=true,attr={input={class="span2"}},},{header=T"Day of week",name="weekdays",param="weekdays",values=n(),type="checkboxgroup",readonly=true,attr={input={class="span1"}},},{header="",legend=T"Time of day wireless control",name="timeofday",type="aggregate",synthesis=nil,subcolumns={{header=T"Enabled",name="enabled",param="enabled",type="switch",default="1",attr={switch={class="inline"}},},{header=T"Access Point",name="ap",param="ap",type="checkboxgroup",values=o(),attr={input={class="span2"}},},{header=T"AP State",name="mode",param="mode",type="select",values=e,default="on",attr={select={class="span2"}},},{header=T"Start Time",name="start_time",param="start_time",type="text",default="00:00",attr={input={class="span2",id="starttime",style="cursor:pointer;"}},},{header=T"Stop Time",name="stop_time",param="stop_time",type="text",default="23:59",attr={input={class="span2",id="stoptime",style="cursor:pointer;"}},},{header=T"Day of week",name="weekdays",param="weekdays",type="checkboxgroup",values=n(),attr={checkbox={class="inline"}},},}},}local e={["mode"]=d(e),["start_time"]=r,["stop_time"]=r,["weekdays"]=i,["enabled"]=u,}return{columns=t,valid=e,days=n(),}end
function t.compareTodRule(i,r)local n,e,o
local a,t,s
local l
for d,r in ipairs(r)do
n=r.start_time
e=r.stop_time
o=r.weekdays
for i,r in ipairs(i)do
a=r.start_time
t=r.stop_time
s=r.weekdays
local r=false
for t,e in ipairs(s)do
for a,t in ipairs(o)do
if e==t then
r=true
break
else
if(e=="All"and t=="All")or(e=="All"and#t>0)or(t=="All"and#e>0)then
r=true
break
end
end
end
end
if r==true then
if(n==a and e==t)then
return nil,T"Duplicate contents are not allowed"else
if(n>=a and e<=t)then
l=true
break
elseif(n<=a and e>=a and e<=t)then
l=true
break
elseif(n<=a and e>=t)then
l=true
break
elseif(n>=a and n<=t and e>=t)then
l=true
break
end
end
end
end
if l then
return nil,T"Overlap contents are not allowed"end
end
return true
end
function t.getWifiTodRuleLists()local e=a.get("rpc.wifitod.")local t=o.convertResultToObject("rpc.wifitod.",e)local e={}for n,t in pairs(t)do
e[#e+1]={}e[#e].rule_name=t.name
e[#e].start_time=t.start_time
e[#e].stop_time=t.stop_time
e[#e].enable=t.mode
e[#e].index=t.paramindex
e[#e].weekdays={}local n=p("rpc.wifitod.%s.weekdays.",t.paramindex)local t=a.get(n)t=o.convertResultToObject(n,t)for a,t in pairs(t)do
if t.value~=""then
e[#e].weekdays[#e[#e].weekdays+1]=t.value
end
end
if(#e[#e].weekdays==0)then
e[#e].weekdays[#e[#e].weekdays+1]="All"end
end
return e
end
function t.getAccessControlTodRuleLists(l,n)local t=o.convertResultToObject(m,a.get(m))local e={}for r,t in pairs(t)do
local n=n and"@"..n
if t["id"]==l and n~=t.paramindex then
e[#e+1]={}e[#e].rule_name=t.name
e[#e].start_time=t.start_time
e[#e].stop_time=t.stop_time
e[#e].enable=t.mode
e[#e].index=t.paramindex
e[#e].weekdays={}local t=p("uci.tod.host.%s.weekdays.",t.paramindex)local t=o.convertResultToObject(t,a.get(t))for a,t in pairs(t)do
if t.value~=""then
e[#e].weekdays[#e[#e].weekdays+1]=t.value
end
end
if(#e[#e].weekdays==0)then
e[#e].weekdays[#e[#e].weekdays+1]="All"end
end
end
return e
end
function t.validateTodRule(n,a,l,e)local n,r=i(n,a,l)if not n then
return n,r
end
local n
if e=="Wireless"then
n=t.getWifiTodRuleLists(a["id"])elseif e=="AccessControl"then
n=t.getAccessControlTodRuleLists(a["id"],a["index"])else
return nil,T"Function input param is missing"end
if#n==0 then
return true
end
local e={}e[#e+1]={}e[#e].rule_name=a["name"]e[#e].start_time=a["start_time"]e[#e].stop_time=a["stop_time"]e[#e].enable=a["mode"]e[#e].index=a["index"]e[#e].weekdays={}for a,t in pairs(a[l])do
if t~=""then
e[#e].weekdays[#e[#e].weekdays+1]=t
end
end
if(#e[#e].weekdays==0)then
e[#e].weekdays[#e[#e].weekdays+1]="All"end
return t.compareTodRule(n,e)end
function t.getCurrentDayAndTime()local e=os.date("%a %H:%M")return e:match("(%S+)%s(%S+)")end
return t