gettext.textdomain('webui-mobiled')local _=require("dkjson")local e=require("web.lte-utils")local c,n,r,d,o,s
local t=e.getContent("rpc.mobiled.DeviceNumberOfEntries")local i=tonumber(t.DeviceNumberOfEntries)if not i or i==0 then
r=e.string_map["no_device"]else
local i=1
local a=string.format("rpc.mobiled.device.@%d.",i)t=e.getContent(a.."display_status")if t then
if t.display_status~="disabled"then
n=e.mobiled_state_map[t.display_status]t=e.getContent(a.."radio.signal_quality.radio_interface")d=e.radio_interface_map[t.radio_interface]local l=e.getContent(a.."sim.sim_state").sim_state
local i=e.getContent(a.."sim.pin.pin_state").pin_state
if l=="ready"and(i=="enabled_verified"or i=="disabled")then
t=e.getContent(a.."leds.")o=t.bars
s=e.signal_quality_map[o]end
if l=="ready"or l=="locked"or l=="blocked"then
if i=="enabled_not_verified"or i=="blocked"then
c=true
if i=="enabled_not_verified"then
n=T"Please enter PIN"else
n=T"Please enter PUK"end
elseif i=="permanently_blocked"then
n=T"SIM permanently blocked"end
elseif l=="not_present"then
n=T"SIM not present"end
end
end
end
local n={status=n or"",no_device=r or"",radio_interface=d or"",signal_quality=s or"",bars=o or"",redirect_sim=c or"false"}local t={}if _.encode(n,{indent=false,buffer=t})then
e.sendResponse(t)end
e.sendResponse("{}")