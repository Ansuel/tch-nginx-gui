gettext.textdomain('webui-mobiled')local u=require("dkjson")local l=require("datamodel")local r=require("web.lte-utils")local e=ngx.req.get_post_args()local d=tonumber(e.dev_idx)or 1
local t=string.format("rpc.mobiled.device.@%d.sim.pin.",d)local function n(e)local t=T"The PIN code must be composed of 4 to 8 digits."local e=e:match("^(%d+)$")if e~=nil then
if string.len(e)>=4 and string.len(e)<=8 then
return true
end
end
return nil,t
end
local function c(e)local t=T"The PUK code must be composed of 8 to 16 digits."local e=e:match("^(%d+)$")if e~=nil then
if string.len(e)>=8 and string.len(e)<=16 then
return true
end
end
return nil,t
end
local function o(n)local t=r.getContent(t)local e=tonumber(t.unlock_retries_left)or 0
local r=tonumber(t.unblock_retries_left)or 0
local t
if n=="unlock"then
t=string.format(N("Failed to verify the PIN code. ( %d retry left ) Please make sure you entered the correct PIN.","Failed to verify the PIN code. ( %d retries left ) Please make sure you entered the correct PIN.",e),e)elseif n=="disable"then
t=string.format(N("Failed to disable the PIN code. ( %d retry left ) Please make sure you entered the correct PIN.","Failed to disable the PIN code. ( %d retries left ) Please make sure you entered the correct PIN.",e),e)elseif n=="enable"then
t=string.format(N("Failed to enable the PIN code. ( %d retry left ) Please make sure you entered the correct PIN.","Failed to enable the PIN code. ( %d retries left ) Please make sure you entered the correct PIN.",e),e)elseif n=="change"then
t=string.format(N("Failed to change the PIN code. ( %d retry left ) Please make sure you entered the correct PIN.","Failed to change the PIN code. ( %d retries left ) Please make sure you entered the correct PIN.",e),e)elseif n=="unblock"then
t=string.format(N("Failed to verify the PUK code. ( %d retry left ) Please make sure you entered the correct PUK.","Failed to verify the PUK code. ( %d retries left ) Please make sure you entered the correct PUK.",r),r)end
if t then
return false,t
end
return false,T"Unknown PIN action"end
local function s(e)local r=T"Please enter a valid PIN."if e["action"]=="default"then
return true
elseif e["action"]=="change"then
local i,a=n(e["old_pin"])if not i then
return false,r.." "..a
end
i,a=n(e["new_pin"])if i~=true then
return false,r.." "..a
end
i=l.set(t.."change",e["old_pin"]..','..e["new_pin"])if not i then
return o(e["action"])end
return true
elseif e["action"]=="disable"then
local n,i=n(e["pin"])if not n then
return false,r.." "..i
end
n=l.set(t.."disable",e["pin"])if not n then
return o(e["action"])end
return true
elseif e["action"]=="enable"then
local n,i=n(e["pin"])if not n then
return false,r.." "..i
end
n=l.set(t.."enable",e["pin"])if not n then
return o(e["action"])end
return true
elseif e["action"]=="unlock"then
local n,i=n(e["pin"])if not n then
return false,r.." "..i
end
n=l.set(t.."unlock",e["pin"])if not n then
return o(e["action"])end
return true
elseif e["action"]=="unblock"then
local n,i=n(e["pin"])if not n then
return false,r.." "..i
end
n,i=c(e["puk"])if not n then
return false,i
end
n=l.set(t.."unblock",e["pin"]..','..e["puk"])if not n then
return o(e["action"])end
return true
end
return false
end
local e=ngx.req.get_post_args()setmetatable(e,{__index=function()return""end})local n,l=s(e)local e=r.getContent(t)e['pin_state_hr']=r.pin_state_map[e['pin_state']]local t=r.getContent(string.format("rpc.mobiled.device.@%d.sim.imsi",d))local t={status=n,error=l,pin_info=e,sim_info=t}local e={}n=u.encode(t,{indent=false,buffer=e})if n then
r.sendResponse(e)end
r.sendResponse("{}")