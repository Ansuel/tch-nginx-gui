gettext.textdomain('webui-core')local a=require("web.content_helper")local p=require("web.ui_helper")local e=require("datamodel")local w=require("dkjson")local _=require("web.post_helper")local s=ngx
if s.req.get_method()=="POST"then
datatype=s.req.get_uri_args().datatype
end
local e={}if datatype and datatype=="xdsl"then
local s,t,n=string.sub,string.format,math.floor
e={status="sys.class.xdsl.@line0.LinkStatus",dsl_linerate_up_max="sys.class.xdsl.@line0.UpstreamMaxRate",dsl_linerate_down_max="sys.class.xdsl.@line0.DownstreamMaxRate",dsl_linerate_up="sys.class.xdsl.@line0.UpstreamCurrRate",dsl_linerate_down="sys.class.xdsl.@line0.DownstreamCurrRate",dsl_margin_up="sys.class.xdsl.@line0.UpstreamNoiseMargin",dsl_margin_down="sys.class.xdsl.@line0.DownstreamNoiseMargin",dsl_attenuation_up="sys.class.xdsl.@line0.UpstreamAttenuation",dsl_attenuation_down="sys.class.xdsl.@line0.DownstreamAttenuation",dsl_power_up="sys.class.xdsl.@line0.UpstreamPower",dsl_power_down="sys.class.xdsl.@line0.DownstreamPower",dsl_type="sys.class.xdsl.@line0.ModulationType",dsl_margin_SNRM_up="sys.class.xdsl.@line0.UpstreamSNRMpb",dsl_margin_SNRM_down="sys.class.xdsl.@line0.DownstreamSNRMpb",dslam_chipset="rpc.xdslctl.DslamChipset",dslam_version="rpc.xdslctl.DslamVersion",dsl_profile="rpc.xdslctl.DslProfile",dsl_port="rpc.xdslctl.DslamPort",dslam_version_raw="rpc.xdslctl.DslamVersionRaw",dsl_serial="rpc.xdslctl.DslamSerial",}a.getExactContent(e)if not(e.dsl_linerate_down=="0")then
e.dsl_linerate_up=e.dsl_linerate_up and(n(tonumber(e.dsl_linerate_up)/10)/100 .." Mbps")or"Can't recover data"e.dsl_linerate_down=e.dsl_linerate_down and(n(tonumber(e.dsl_linerate_down)/10)/100 .." Mbps")or"Can't recover data"e.dsl_linerate_up_max=e.dsl_linerate_up_max and(n(tonumber(e.dsl_linerate_up_max)/10)/100 .." Mbps")or"Can't recover data"e.dsl_linerate_down_max=e.dsl_linerate_down_max and(n(tonumber(e.dsl_linerate_down_max)/10)/100 .." Mbps")or"Can't recover data"if not(e.dsl_type:match("ADSL"))then
e.dsl_margin_down=e.dsl_margin_SNRM_down
e.dsl_margin_up=e.dsl_margin_SNRM_up
end
if e.dslam_chipset:match("BDCM")then
e.dslam_chipset="Broadcom".." ( "..e.dslam_chipset.." )"elseif e.dslam_chipset:match("IFTN")then
e.dslam_chipset="Infineon".." ( "..e.dslam_chipset.." )"end
if not(e.dslam_version_raw:sub(0,2)=="0x")then
if e.dslam_version_raw==""then
e.dslam_chipset=T"Can't recover DSLAM version."else
e.dslam_chipset=t(T"Invalid version, can't convert. Raw value: %s",e.dslam_version_raw)end
end
e.dslam_version_raw=nil
if e["status"]:match("Showtime")then
e["status"]=T"Connected"elseif e["status"]==""then
e["status"]=T"Disconnected"else
e["status"]=T(e.status)end
else
for n in pairs(e)do
if not(n=="status")then
e[n]="N/A"end
end
end
else
local u,n,n
local n=table
local r=string.format
local t={wan_proto="uci.network.interface.@wan.proto",wan_auto="uci.network.interface.@wan.auto",wan_ipv6="uci.network.interface.@wan.ipv6",wan_ifname="uci.network.interface.@wan.ifname",wan_mode="uci.network.config.wan_mode",}a.getExactContent(t)local n="wan"if wan_mode=="bridge"then
n=t.wan_ifname
end
local n={wan_ppp_state="rpc.network.interface.@wan.ppp.state",wan_ppp_error="rpc.network.interface.@wan.ppp.error",ipaddr="rpc.network.interface.@wan.ipaddr",wan_uptime="rpc.network.interface.@wan.uptime",up="rpc.network.interface.@"..n..".up",nexthop="rpc.network.interface.@wan.nexthop",dns_wan="rpc.network.interface.@wan.dnsservers",concentrator_name="rpc.network.interface.@wan.ppp.access_concentrator_name",}local s=require("internethelper")for t,e in pairs(s.getIpv6Content())do
n[t]=e
end
a.getExactContent(n)if n.dns_wan:match(",")then
n.dns_wan=n.dns_wan:gsub(","," , ")end
if n.up=="1"then
n.up=T"Connected"else
n.up=T"Disconnected"end
local a="none"if t.wan_ipv6~="1"then
a="disabled"elseif n.ip6prefix~=""then
a="prefix"elseif n.ip6prefix==""then
a="noprefix"end
local s=require("web.taint").untaint_mt
local o={none=T"IPv6 Disabled",noprefix=T"IPv6 Connecting",prefix=T"IPv6 Connected",}setmetatable(o,s)local d={none="off",noprefix="orange",prefix="green",}setmetatable(d,s)local l
local c={light={},span={}}if t.wan_mode=="pppoe"then
local s={disabled=T"PPP disabled",disconnecting=T"PPP disconnecting",connected=T"PPP connected",connecting=T"PPP connecting",disconnected=T"PPP disconnected",error=T"PPP error",AUTH_TOPEER_FAILED=T"PPP authentication failed",NEGOTIATION_FAILED=T"PPP negotiation failed",}local e=require("web.taint").untaint_mt
setmetatable(s,e)local i={disabled="0",disconnected="4",disconnecting="2",connecting="2",connected="1",error="4",AUTH_TOPEER_FAILED="4",NEGOTIATION_FAILED="4",}setmetatable(i,e)local e
if t.wan_auto~="0"then
t.wan_auto="1"e=r("%s",n.wan_ppp_state)if e==""or e=="authenticating"then
e="connecting"elseif not s[e]then
e="error"end
if not(n.wan_ppp_error==""or n.wan_ppp_error=="USER_REQUEST")then
if s[n.wan_ppp_error]then
e=n.wan_ppp_error
else
e="error"end
end
else
e="disabled"end
local m,w,t,r,_
if e then
m=i[e]w=s[e]if n["ipaddr"]and n["ipaddr"]:len()>0 then
t=n["ipaddr"]elseif n["ip6addr"]and n["ip6addr"]:len()>0 then
t=n["ip6addr"]end
if e=="connected"and a~="disabled"then
r=d[a]_=o[a]end
end
l=p.createSimpleLight(i[e],s[e],c,"fa-at")elseif t.wan_mode=="static"then
local e="disabled"local s={disabled=T"Static disabled",connected=T"Static on",}local a={disabled="0",connected="1",}if t.wan_auto~="0"and n["ipaddr"]:len()>0 then
e="connected"end
l=p.createSimpleLight(a[e],s[e],c,"fa-at")end
local a=n["wan_uptime"]local t=_.secondsToTimeShort(a)e={status_light=l or"",WAN_IP_text=not(n["ipaddr"]=="")and r(T'WAN IP is <strong>%s</strong>'..'<br/>',n["ipaddr"])or"",WAN_IPv6_text=not(n["ip6addr"]=="")and r(T'WAN IPv6 is <strong>%s</strong>'..'<br/>',n["ip6addr"])or"",uptime_text=t and r(T"Uptime"..": <strong>%s</strong>",t)or"",wan_uptime=t or"",wan_uptime_extended=_.secondsToTime(a)or"",ppp_status=u or"",ppp_light=ppp_light or"",ppp_state=ppp_state or"",WAN_IP=n["ipaddr"]or"",WAN_IPv6=n["ip6addr"]or"",concentrator_name=n["concentrator_name"]or"",ipv6_light=ipv6_light or"",ipv6_state=ipv6_state or"",status=n["up"],wangateway=n["nexthop"],wandns=n["dns_wan"]}end
local n={}if w.encode(e,{indent=false,buffer=n})then
s.say(n)else
s.say("{}")end
s.exit(s.HTTP_OK)