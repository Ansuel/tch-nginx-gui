gettext.textdomain('webui-core')local S=require("dkjson")local m=require("datamodel")local l=ngx
local n=require("web.content_helper")local c=require("web.post_helper")local t=require("web.ui_helper")local e=require("web.taint").untaint_mt
local r={{header=T"Line Status",name="sipRegisterState",param="sipRegisterState",type="text",},{header=T"Number",name="uri",param="uri",type="text",},{header=T"Call State",name="callState",param="callState",type="text",},}local a={status="rpc.mmpbx.state",emission="rpc.mmpbx.dectemission.state",}n.getExactContent(a)local i={STARTING=T"Starting",RUNNING=T"Running",STOPPING=T"Stopping",NA=T"Not Available",}setmetatable(i,e)local p=a.status=="NA"and"0"or"1"local R=i[a.status]or a.status
local o={MMPBX_CALLSTATE_IDLE=T"Idle",MMPBX_CALLSTATE_DIALING=T"Dialing",MMPBX_CALLSTATE_CALL_DELIVERED=T"Delivered/In Progress",MMPBX_CALLSTATE_CONNECTED=T"In Progress/Connected",MMPBX_CALLSTATE_ALERTING=T"Ringing"}setmetatable(o,e)local i={Registered=T"Registered",Registering=T"Registering"}setmetatable(i,e)local s={MMPBX_REG_CLIENT_REASON_RESPONSE_REQUEST_FAILURE_RECVD=T"Registration refused",MMPBX_REG_CLIENT_REASON_NETWORK_ERROR=T"Network error",MMPBX_REG_CLIENT_REASON_TRANSACTION_TIMEOUT=T"Registration Timeout"}setmetatable(s,e)local e={}local function d(t)t=string.untaint(t)e.year,e.month,e.day,e.hour,e.min,e.sec=t:match("(%d+)-(%d+)-(%d+)%s+(%d+):(%d+):(%d+)")if e.year then
return os.time(e)end
return 0
end
local a=function(e)if(e.enable=="false")or(e.sipRegisterState=="")then
return false
end
local r=e.uri
if e.uri and e.uri:match("+")then
e.uri=e.uri:sub(4)end
local l="off"local a
if e.sipRegisterState then
a=i[e.sipRegisterState]or e.sipRegisterState
if e.sipRegisterState=="Registered"then
l="green"end
if e.failReason~=""then
l="red"a=s[e.failReason]or e.failReason
end
e.sipRegisterState=t.createSimpleLight(nil,a,{light={class=l}})end
if e.callState then
local a=o[e.callState]or e.callState
if(e.callState~="MMPBX_CALLSTATE_IDLE")then
local t=m.get("rpc.mmpbx.calllog.info.")local t=n.convertResultToObject("rpc.mmpbx.calllog.info.",t)for l=#t,1,-1 do
v=t[l]if v.Localparty==r then
a=a.."\n"..v.Remoteparty
if(e.callState=="MMPBX_CALLSTATE_CONNECTED")then
local e=""if v.connectedTime~="0"then
local t=d(v.connectedTime)if v.endTime~='0'then
local a=d(v.endTime)e=c.secondsToTimeShort(a-t)else
e=c.secondsToTimeShort(os.time()-t)end
end
a=a.." "..e
end
break
end
end
end
e.callState=t.createSimpleLight(e.callState=="MMPBX_CALLSTATE_IDLE"and"0"or"1",a,nil,"fa fa-phone")end
return true
end
local e={canEdit=false,canAdd=false,canDelete=false,tableid="mmpbxd",basepath="rpc.mmpbx.profile.",}local a=n.loadTableData(e.basepath,r,a,nil)local n=t.createTable(r,a,e,nil,nil)local e={}local function a(t)for l,t in pairs(t)do
if type(t)=="table"then
a(t)elseif type(t)=="userdata"then
e[#e+1]=string.untaint(t)else
e[#e+1]=t
end
end
end
a(n)local t={mmpbx_status=t.createLabel(T"Service",t.createSimpleLight(p,R),basic),mmpbx_table=table.concat(e)or""}local e={}if S.encode(t,{indent=false,buffer=e})then
l.say(e)else
l.say("{}")end
l.exit(l.HTTP_OK)