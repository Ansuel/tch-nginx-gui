gettext.textdomain('webui-mobiled')local s=require("web.content_helper")local d=require("web.lte-utils")local t=require("datamodel")local u=require("dkjson")local o=ngx.req.get_post_args()local c=tonumber(o.max_age)or 5
local l=tonumber(o.dev_idx)or 1
local function i(e,t,n)for t,r in string.gmatch(t,"([%w_]+)(.?)")do
if r=="."then
e[t]=e[t]or{}e=e[t]else
e[t]=n
end
end
end
local function p(t,r,e)if not e then e={}end
if t and r then
for n,t in pairs(t)do
local r=t.path:gsub(r,'')if r and r~=''then
i(e,r..t.param,t.value)else
e[t.param]=t.value
end
end
end
return e
end
if not o.data_period then
d.sendResponse({'{ error : "Invalid data_period" }'})return
end
if not o.request_data then
d.sendResponse({'{ error : "Invalid request_data" }'})return
end
local i=u.decode(string.untaint(o.request_data))local e
local n
if i.history then
n={}e=string.format("rpc.ltedoctor.signal_quality.@%s.",o.data_period)t.set(e.."dev_idx",tostring(l))local r={period_seconds=e..'period_seconds',current_uptime=e..'current_uptime'}s.getExactContent(r)n.period_seconds=tonumber(r.period_seconds)n.current_uptime=tonumber(r.current_uptime)if i.history.last_uptime then
e="rpc.ltedoctor.signal_quality.@diff."t.set(e.."since_uptime",tostring(i.history.last_uptime))t.apply()end
n.starting_uptime=0
if n.period_seconds and n.current_uptime>n.period_seconds then
n.starting_uptime=n.current_uptime-n.period_seconds
end
e=e..'entries.'n.data=s.convertResultToObject(e,t.get(e))end
local a
if i.current then
a={}local r=string.format('rpc.mobiled.device.@%d.',l)t.set(r..'radio.signal_quality.max_age',tostring(c))e=r..'radio.signal_quality.'local n=t.get(e)p(n,e,a)e=r..'radio.signal_quality.additional_carriers.'a.additional_carriers=s.convertResultToObject(e,t.get(e))t.set(r..'network.serving_system.max_age',tostring(c))e=r..'network.serving_system.'local n=t.get(e)p(n,e,a)e=r..'leds.bars'local e=t.get(e)if e then
a['bars']=e[1].value
end
local e={"AdditionalCarriersNumberOfEntries","NeighbourCellsNumberOfEntries"}for t,e in pairs(e)do
a[e]=nil
end
end
local r
if i.alarms then
r={}e=string.format("rpc.ltedoctor.alarms.@%s.",o.data_period)t.set(e.."dev_idx",tostring(l))local n={period_seconds=e..'period_seconds',current_uptime=e..'current_uptime'}s.getExactContent(n)r.period_seconds=tonumber(n.period_seconds)r.current_uptime=tonumber(n.current_uptime)if i.alarms.last_uptime then
e="rpc.ltedoctor.alarms.@diff."t.set(e.."since_uptime",tostring(i.alarms.last_uptime))t.apply()end
r.starting_uptime=0
if r.period_seconds and r.current_uptime>r.period_seconds then
r.starting_uptime=r.current_uptime-r.period_seconds
end
e=e..'entries.'r.data=s.convertResultToObject(e,t.get(e))for t,e in pairs(r.data)do
e.uptime=tonumber(e.uptime)end
end
local l
if i['stats']then
l={network={}}local r=t.get("rpc.mobiled.device.@1.stats.network.")if r then
for t,e in pairs(r)do
l.network[e.param]=e.value
end
end
e="rpc.mobiled.device.@1.stats.sessions."l.sessions=s.convertResultToObject(e,t.get(e))end
local t={current=a,history=n,alarms=r,stats=l,data_period=o.data_period}local e={}local t=u.encode(t,{indent=false,buffer=e})if t and e then
d.sendResponse(e)end
d.sendResponse({'{ error : "Failed to encode data" }'})