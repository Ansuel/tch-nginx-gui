gettext.textdomain('webui-core')local i=require("dkjson")local t=ngx
local l=require("web.ui_helper")local r=require("web.content_helper")local a=string.match
local n={{header=T"Hostname",name="FriendlyName",param="FriendlyName",type="text",additional_class='data-toggle="tooltip_mac"',},{header=T"IPv4",name="ipv4",param="IPv4",type="text",},{header=T"InterfaceType",name="interfacetype",param="InterfaceType",type="text",},{header=T"SSID",name="ssid",param="SSID",type="text",},}local a=function(e)if e["State"]and e["State"]=="0"then
return false
end
if a(e["L2Interface"],"^wl0")then
e["InterfaceType"]="Wireless - 2.4GHz"elseif a(e["L2Interface"],"^wl1")then
e["InterfaceType"]="Wireless - 5GHz"elseif a(e["L2Interface"],"eth*")then
e["InterfaceType"]="Ethernet - "..e.Port
elseif a(e["L2Interface"],"moca*")then
e["InterfaceType"]="MoCA"end
e["FriendlyName"]=e["FriendlyName"]..'<div id="mac_data" style="display:none">'..e["MACAddress"]..'</div>'return true
end
local e={canEdit=false,canAdd=false,canDelete=false,tableid="devices",basepath="rpc.hosts.host.",}local a=r.loadTableData(e.basepath,n,a,nil)local l=l.createTable(n,a,e,nil,nil)local e={}local function n(a)for t,a in pairs(a)do
if type(a)=="table"then
n(a)elseif type(a)=="userdata"then
e[#e+1]=string.untaint(a)else
e[#e+1]=a
end
end
end
n(l)local a={device_table=table.concat(e)or""}local e={}if i.encode(a,{indent=false,buffer=e})then
t.say(e)else
t.say("{}")end
t.exit(t.HTTP_OK)