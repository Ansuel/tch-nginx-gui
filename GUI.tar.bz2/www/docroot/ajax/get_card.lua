local e=ngx
local l=e.ctx.session
local a=require("cards")local o=require("web.lp")local l
if e.req.get_method()=="GET"then
l=e.req.get_uri_args().modal or false
end
local l=a.get_card_from_modal(l)or nil
if not l then
e.status=403
else
o.include(l)end
e.exit(e.HTTP_OK)