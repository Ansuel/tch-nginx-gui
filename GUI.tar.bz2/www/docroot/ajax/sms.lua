gettext.textdomain('webui-mobiled')local t=require("dkjson")local l=require("datamodel")local n=require("web.lte-utils")local s=require("web.content_helper")local e=ngx.req.get_post_args()if e["id"]~=nil and e["id"]~=""and e["action"]~=nil and e["action"]~=""then
local n=e["action"]if n=='read'then
l.set("rpc.mobiled.sms.markread",e["id"])elseif n=='unread'then
l.set("rpc.mobiled.sms.markunread",e["id"])elseif n=='delete'then
l.set("rpc.mobiled.sms.delete",e["id"])end
end
local o={info=n.getContent("rpc.mobiled.sms.info.")}local e="rpc.mobiled.sms.message."local l=l.get(e)o.messages=s.convertResultToObject(e,l)local e={}local l=t.encode(o,{indent=false,buffer=e})if l then
n.sendResponse(e)end
n.sendResponse("{}")