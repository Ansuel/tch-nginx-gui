gettext.textdomain('webui-core')local o=require("dkjson")local s=ngx
local n=require("datamodel")local t=require("web.ui_helper")local d=require("web.content_helper")local i=n.get("uci.env.var.qtn_eth_mac")i=((i and i[1].value~="")and true or false)local a=n.get("sys.eth.port.@eth4.status")if a and a[1].value then
a="eth4"else
a="eth3"end
local r={{header=T"Type",name="type",param="paramindex",type="text",readonly=true,},{header=T"Status",name="status",param="status",type="text",readonly=true,},{header=T"Speed",name="speed",param="speed",type="text",readonly=true,},{header=T"Mode",name="mode",param="mode",type="text",readonly=true,},}local l={canEdit=false,canAdd=false,canDelete=false,tableid="port",basepath="sys.eth.port.@.",}local e=function(e)e.status_light="1"if e.speed=="1000"then
e.status_light="1"e.speed="1 Gbps"elseif e.speed=="100"then
e.status_light="2"e.speed="100 Mbps"elseif e.speed=="10"then
e.status_light="3"e.speed="10 Mbps"elseif e.speed==""then
e.status_light="0"end
e.status=t.createSimpleLight(e.status_light,"",{},"fas fa-ethernet")if i and e.paramindex:match("eth5")then
return false
elseif e.paramindex:match(a)and(n.get("uci.ethernet.port.@"..a..".wan")[1].value=="1")then
e.paramindex="WAN"else
port=e.paramindex:gsub("eth","")e.paramindex="LAN - "..tonumber(port)+1
end
return true
end
local a=d.loadTableData(l.basepath,r,e,nil)local e={wifi24_status="rpc.wireless.radio.@radio_2G.admin_state",wifi24_speed="rpc.wireless.radio.@radio_2G.phy_rate",wifi24_mode="rpc.wireless.radio.@radio_2G.standard",wifi5_status="rpc.wireless.radio.@radio_5G.admin_state",wifi5_speed="rpc.wireless.radio.@radio_5G.phy_rate",wifi5_mode="rpc.wireless.radio.@radio_5G.standard",}d.getExactContent(e)if e.wifi24_mode=="bgn"then
e.wifi24_mode="b/g/n"elseif e.wifi24_mode=="gn"then
e.wifi24_mode="g/n"end
if e.wifi5_mode=="anac"then
e.wifi5_mode="a/n/ac"elseif e.wifi5_mode=="an"then
e.wifi5_mode="a/n"end
a[#a+1]={"Wi-Fi 2.4 Ghz",t.createSimpleLight(e.wifi24_status,"",{},"fa fa-wifi"),(e.wifi24_status=="1")and(e.wifi24_speed/1000 .." Mbps")or"",(e.wifi24_status=="1")and e.wifi24_mode or"",}a[#a+1]={"Wi-Fi 5 Ghz",t.createSimpleLight(e.wifi5_status,"",{},"fa fa-wifi"),(e.wifi5_status=="1")and(e.wifi5_speed/1000 .." Mbps")or"",(e.wifi5_status=="1")and e.wifi5_mode or"",}table.sort(a,function(a,e)return a[1]<e[1]end)local i=t.createTable(r,a,l,nil,nil)local a={}local function t(e)for i,e in pairs(e)do
if type(e)=="table"then
t(e)elseif type(e)=="userdata"then
a[#a+1]=string.untaint(e)else
a[#a+1]=e
end
end
end
t(i)local a={port_table=table.concat(a)or""}local e={}if o.encode(a,{indent=false,buffer=e})then
s.say(e)else
s.say("{}")end
s.exit(s.HTTP_OK)