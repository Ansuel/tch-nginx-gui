gettext.textdomain('webui-mobiled')local a=require("dkjson")local e=require("web.content_helper")local e=ngx
local l=require("datamodel")local l=require("web.content_helper")local l=require("web.ui_helper")local l=require("web.post_helper")local l,e,r=string,e,os
local r=tonumber
local t,l=l.format,l.match
local o
local r
local l
if e.req.get_method()=="POST"then
o=e.req.get_uri_args().oldrx or"1000"r=e.req.get_uri_args().oldtx or"1000"l=e.req.get_uri_args().interface
end
local c=t("/sys/class/net/%s/statistics/rx_bytes",l or"ptm0")local s=t("/sys/class/net/%s/statistics/tx_bytes",l or"ptm0")local t=io.open(c,"r")local c=t:read()t:close()local t=io.open(s,"r")local s=t:read()t:close()local o={old_rx_traffic=o,old_tx_traffic=r,rx_traffic=c,tx_traffic=s}local r={}if not l then
e.say("Invalid interface in args")elseif a.encode(o,{indent=false,buffer=r})then
e.say(r)else
e.say("{}")end
e.exit(e.HTTP_OK)