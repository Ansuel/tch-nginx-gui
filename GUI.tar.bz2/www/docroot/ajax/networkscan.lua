gettext.textdomain('webui-mobiled')local l=require("dkjson")local e=require("datamodel")local t=require("web.lte-utils")local o=require("web.content_helper")local c=ngx.req.get_post_args()local n={}if c["action"]=="scan"then
e.set("rpc.mobiled.device.@1.network.scan.start","true")e.apply()elseif c["action"]=="selectplmn"then
local t=t.get_uci_device_path()e.set(t.."mcc",c["mcc"])e.set(t.."mnc",c["mnc"])e.set(t.."network_selection","manual")e.apply()elseif c["action"]=="getcurrentplmn"then
local e=t.get_uci_device_path()local c=t.getContent(e.."mcc")local e=t.getContent(e.."mnc")n={mcc=c['mcc'],mnc=e['mnc']}elseif c["action"]=="getscanresults"then
local t="rpc.mobiled.device.@1.network.scanresults."local e=e.get(t)if e then
n=o.convertResultToObject(t,e)end
else
n=t.getContent("rpc.mobiled.device.@1.network.scan.")end
local e={}local c=l.encode(n,{indent=false,buffer=e})if c then
t.sendResponse(e)end
t.sendResponse("[]")