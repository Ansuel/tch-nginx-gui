local t=require("dkjson")local l=require("datamodel")local o=require("web.content_helper").readfile
local r=require("web.post_helper")local e=ngx
local a=tonumber(l.get("sys.mem.RAMFree")[1].value or 0)or 0
local l=l.get("sys.proc.CPUUsage")[1].value or"0"local l={cpuusage=l.."%"or"0",ram_free=math.floor(a/1024),uptime=r.secondsToTime(o("/proc/uptime","number",floor)),connection=o("/proc/sys/net/netfilter/nf_conntrack_count"),system_time=os.date("%d/%m/%Y %Hh:%Mm:%Ss",os.time()),cpuload=o("/proc/loadavg","string"):sub(1,14),}local o={}if t.encode(l,{indent=false,buffer=o})then
e.say(o)else
e.say("{}")end
e.exit(e.HTTP_OK)