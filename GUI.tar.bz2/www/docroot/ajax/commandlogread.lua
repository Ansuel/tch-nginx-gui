local l=require("dkjson")local t=require("datamodel")local n=ngx
local e={}local a=t.get("rpc.system.modgui.executeCommand.state")e["state"]=a and a[1]and a[1].value or"Mapper Error"local a={Checking=function()local n={}local e=t.get("uci.modgui.gui.new_ver")if e and not(e[1].value=="")then
n["new_version_text"]=e[1].value
end
return n
end,}if a[string.untaint(e.state)]then
for n,a in pairs(a[string.untaint(e.state)]())do
e[n]=a
end
else
local n=io.open("/tmp/command_log","r")if n then
e["log"]=n:read('*a')n:close()end
end
local a={}if l.encode(e,{indent=false,buffer=a})then
n.say(a)else
n.say("{}")end
n.exit(n.HTTP_OK)