gettext.textdomain('webui-mobiled')local i=require("dkjson")local e=require("web.lte-utils")local s=setmetatable
local t=e.getContent("rpc.mobiled.device.@1.sim.sim_state")local o=e.getContent("rpc.mobiled.device.@1.leds.")local n=e.getContent("rpc.mobiled.device.@1.network.serving_system.network_desc")local o={indicator_info=o}if(n.network_desc=="")then
n.network_desc=T"None"end
o['network_info']=n
s(t,{__index=function()return""end})t['status']=e.sim_state_map[t['sim_state']]o['sim_info']=t
local t={}local n=i.encode(o,{indent=false,buffer=t})if n then
e.sendResponse(t)end
e.sendResponse("{}")