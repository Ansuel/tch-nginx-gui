#! /usr/bin/lua
local c=require("lfs")local u=require("transformer.shared.processinfo")local d=require("uloop")local t="/tmp/trafficmon/"local s=145
local function m()local n="0"local e=io.open("/proc/meminfo","r")if e then
for o in e:lines()do
if o:match("MemTotal")then
n=o:gsub("MemTotal:%s*",""):gsub("[A-z]+%s*","")break
end
end
e:close()end
return n
end
local function h()local n="0"local e=io.open("/proc/meminfo","r")if e then
for o in e:lines()do
if o:match("MemFree")then
n=o:gsub("MemFree:%s*",""):gsub("[A-z]+%s*","")break
end
end
e:close()end
return n
end
local function r(e,o,n,l)local e=io.open(e,"w")if e then
e:write(o.."\n")if n then
e:write(n.." "..l.."\n")end
e:close()end
end
local function a(i,o,e)local n=t..i
local l
if i:match("mem")then
l=m()else
l="100"end
if binit then
r(n,l,o,e)else
f=io.open(n,"r")if not f then
r(n,l,o,e)f=io.open(n,"r")end
if f then
local i={}for e in f:lines()do
i[#i+1]=e
end
f:close()f=io.open(n,"w")if f then
f:write(l.."\n")local n=false
for i,l in ipairs(i)do
if i>1 and i<=s then
local i=tonumber((l:gsub("[0-9]+%s",""):gsub(":","")))local t=tonumber((e:gsub(":","")))if i==t then
if not n then
f:write(o.." "..e.."\n")n=true
end
elseif i>t then
if not n then
f:write(o.." "..e.."\n")n=true
end
f:write(l.."\n")else
f:write(l.."\n")end
end
end
if not n then
f:write(o.." "..e.."\n")n=true
end
f:close()end
end
end
end
local function m(m,w)local f="/sys/class/net/"local b="/statistics/"local p={"tx_bytes","rx_bytes"};local l=os.date('%H:%M')local i,o=0,0
local e,n=nil,""for t in c.dir(f)do
if t~="."and t~=".."then
for d,c in ipairs(p)do
n=f..t..b..c
e=io.open(n,"r")if e then
i=e:read("*line")e:close()end
n=m..t.."_"..c
if w then
r(n,i)else
e=io.open(n,"r")if not e then
r(n,i)e=io.open(n,"r")end
if e then
local t={}for n in e:lines()do
t[#t+1]=n
end
e:close()o=tonumber(i)-t[1]if(o<0)then
o=0
end
e=io.open(n,"w")if e then
e:write(i.."\n")local n=false
for t,i in ipairs(t)do
if t>1 and t<=s then
local t=tonumber((i:gsub("[0-9]+%s",""):gsub(":","")))local r=tonumber((l:gsub(":","")))if t==r then
if not n then
e:write(o.." "..l.."\n")n=true
end
elseif t>r then
if not n then
e:write(o.." "..l.."\n")n=true
end
e:write(i.."\n")else
e:write(i.."\n")end
end
end
if not n then
e:write(o.." "..l.."\n")n=true
end
e:close()end
end
end
end
end
end
a("stats_cpu",u.getCPUUsage(),l)a("stats_mem",h(),l)end
d.init()local function n(n)local e=c.lock_dir(t)if e then
pcall(m,t,n)e:free()end
end
local o=600000
local function e()d.timer(function()n()e()end,o)end
local o=c.chdir(t)and true or false
if not o then
c.mkdir(t)end
n(true)e()d.run()