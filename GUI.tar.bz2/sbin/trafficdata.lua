#! /usr/bin/lua
local l=require("uloop")local a=require("web.content_helper")local s=string.format
local i=require("datamodel")local d="/var/state/traffic_data_file"local function o(e)local t=io.open(e,"r")local e={}if t then
for n in t:lines()do
e[#e+1]=n
end
t:close()return e
else
return nil
end
end
local function r(e,n)local r=e.lastnumber
local t=e.period
if n and r then
if(tonumber(n)<tonumber(r))then
t=t+1
end
if tonumber(t)>256 then
t=0
end
e={t,n}else
e={0,n}end
return e
end
local function f(e,n)local t=o(e)local e=io.open(e,"w")if e then
if t then
local a={period=t[1],lastnumber=t[2],}local c={period=t[3],lastnumber=t[4],}local l={period=t[5],lastnumber=t[6],}local s={period=t[7],lastnumber=t[8],}local i={period=t[9],lastnumber=t[10],}local t={period=t[11],lastnumber=t[12],}local o=r(a,n.wan_rx)local c=r(c,n.wan_tx)local l=r(l,n.lan_rx)local a=r(s,n.lan_tx)local i=r(i,n.wifi_rx)local t=r(t,n.wifi_tx)e:write(tostring(o[1]).."\n")e:write(tostring(o[2]).."\n")e:write(tostring(c[1]).."\n")e:write(tostring(c[2]).."\n")e:write(tostring(l[1]).."\n")e:write(tostring(l[2]).."\n")e:write(tostring(a[1]).."\n")e:write(tostring(a[2]).."\n")e:write(tostring(i[1]).."\n")e:write(tostring(i[2]).."\n")e:write(tostring(t[1]).."\n")e:write(tostring(t[2]))e:close()else
e:write(string.rep("0\n",12))e:close()end
end
end
local function e(e)return tonumber(e)or 0
end
local function t(e)return s("%.3f",e/1048576)end
local t=i.get("uci.env.var.qtn_eth_mac")t=((t and t[1].value~="")and true or false)local function s()local n={tx_bytes="rpc.network.interface.@lan.tx_bytes",rx_bytes="rpc.network.interface.@lan.rx_bytes",ifname="uci.network.interface.@lan.ifname",}a.getExactContent(n)local d=e(n.tx_bytes)local f=e(n.rx_bytes)local n="wan"local r=i.get("rpc.network.interface.@wwan.ipaddr")if r and r[1].value:len()~=0 then
n="wwan"end
local n={tx_bytes="rpc.network.interface.@"..n..".tx_bytes",rx_bytes="rpc.network.interface.@"..n..".rx_bytes",ifname="uci.network.interface.@"..n..".ifname",}a.getExactContent(n)local u=e(n.tx_bytes)local s=e(n.rx_bytes)local n="uci.wireless.wifi-iface."local n=a.convertResultToObject(n.."@.",i.get(n))local r={}for n,e in ipairs(n)do
r[#r+1]={radio=e.device,ssid=e.ssid,iface=e.paramindex}if e.paramindex==getiface then
curiface=e.paramindex
if t and curiface=="wl1"then
curiface="eth5"end
curssid=e.ssid
end
end
table.sort(r,function(e,t)if e.radio==t.radio then
return e.iface<t.iface
else
return e.radio<t.radio
end
end)local o,c=0,0
local n={}for l,r in ipairs(r)do
if i.get("sys.class.net.@"..r.iface..".")then
if t and r.iface=="wl1"then
r.iface="eth5"end
n["tx_bytes"]="sys.class.net.@"..r.iface..".statistics.tx_bytes"n["rx_bytes"]="sys.class.net.@"..r.iface..".statistics.rx_bytes"a.getExactContent(n)o=o+e(n.tx_bytes)c=c+e(n.rx_bytes)end
end
local e={wan_tx=u,wan_rx=s,lan_tx=d,lan_rx=f,wifi_tx=o,wifi_rx=c,}return e
end
l.init()local t=180000
local function e()l.timer(function()f(d,s())e()end,t)end
f(d,s())e()l.run()