local r={}r.SenseEventSet={'xdsl_0','network_device_eth4_down','network_interface_wan_ifup','network_interface_wan_ifdown',}local t=require('transformer.shared.xdslctl')local o=require('transformer.shared.sfp')local e=require('datamodel')local a=string.match
function r.check(n)local c=n.scripth
local l=n.ubus
local e=n.logger
local n=n.uci
local t=t.infoValue("tpstc")if not n then
return false
end
local n=n.cursor()local r=n:get("ethernet","eth4","wan")if c.l2HasCarrier("eth4")and not(r=="0")then
e:notice("SFP connection: "..o.getSfpPhyState())if o.getSfpPhyState()=="connect"and o.getSfpVendName()~=""then
e:notice("SFP connected")return"L3Sense","SFP"else
e:notice("Ethernet wan connected")return"L3Sense","ETH"end
else
if t then
if a(t,"ATM")then
return"L3Sense","ADSL"elseif a(t,"PTM")then
return"L3Sense","VDSL"end
end
end
local t=n:get("network","wwan","auto")e:notice("WAN Sensing Mobile: "..t)if t=="0"then
e:notice("WAN Sensing - Enabling Mobile interface")n:set("network","wwan","auto","1")n:commit("network")l:call("network.interface.wwan","up",{})end
return"L2Sense"end
return r