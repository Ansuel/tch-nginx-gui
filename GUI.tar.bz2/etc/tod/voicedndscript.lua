local d={}local c=pairs
local a=string.find
local l=string.sub
local n
local o={on="off",off="on"}local t={on='1',off='0'}local function r(e,n)if(n~=nil)then
for o,n in c(n)do
if n==e then
return true
end
end
end
return false
end
local function n(n)local e=false
n:foreach("tod","action",function(n)if(n.object:match("^voicednd"))then
if(n.timers)then
for o,n in ipairs(n.timers)do
if(n~='')then
e=true
return
end
end
end
end
end)if(e==true)then
return false
end
return true
end
local function f(e,n,t)local n=n:get("tod","voicednd","ringing")if(e=="start")then
n=o[n]end
return n
end
local function u(n,e,o)local t=nil
local o,r=a(n,"%.")if o then
local d=l(n,1,o-1)local o=l(n,r+1,-1)e:foreach("tod",d,function(n)if n['.name']==o then
t=n['profile']return true
end
end)e:unload("tod")return t
end
end
local function a(e,n,a,l)local o=n.logger
local d=n.uci
local i=n.ubus
local n=d.cursor()o:warning("execute_action: "..e.." for "..a.." on "..l)local d=u(l,n,o)if not d then
o:warning("there is no profile instance to operate")return true
end
local e=f(e,n,o)local l=false
o:debug("ringing state value %s",e)if e and t[e]then
if r("All",d)then
i:send("mmpbx.profile.dnd",{dnd=e})n:foreach("mmpbx","service",function(o)if o["type"]=="DND"then
n:set("mmpbx",o['.name'],"activated",t[e])l=true
end
end)else
for o,a in c(d)do
local d=nil
i:send("mmpbx.profile.dnd",{profile=a,dnd=e})n:foreach("mmpbx","service",function(o)if(o["type"]=="DND")and((r(a,o["profile"]))==true)then
d=n:get("mmpbx",o['.name'],"activated")if(d~=nil)and(d~=t[e])then
n:set("mmpbx",o['.name'],"activated",t[e])l=true
end
end
end)end
end
end
if l then
n:commit("mmpbx")end
n:unload("mmpbx")end
function d.start(n,t,o)local e=n.logger
local e=n.uci
local e=e.cursor()local l=e:get("tod","voicednd","enabled")if l=="1"then
a("start",n,t,o)end
e:unload("tod")return true
end
function d.stop(n,t,o)local e=n.uci
local e=e.cursor()local l=e:get("tod","voicednd","enabled")if l=="1"then
a("stop",n,t,o)end
e:unload("tod")return true
end
return d