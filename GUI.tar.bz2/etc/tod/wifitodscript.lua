local c={}local s=pairs
local o=string.find
local l=string.sub
local e=table.remove
local u
local f=false
local function g(n,e)for t,e in s(e)do
if e==n then
return true
end
end
return false
end
local function b(e)if not o(e,"%.")and not o(e,"%_orig%_")and e~="ap"then
return true
else
return false
end
end
local function m(e,n,r)local t=nil
local o,i=o(e,"%.")if o then
local o=l(e,1,o-1)local l=l(e,i+1,-1)r:debug("type="..o..", instance="..l)n:foreach("tod",o,function(e)if e['.name']==l then
t=e['ap']return false
end
end)else
n:foreach("tod",e,function(e)if e['.index']==0 then
t=e['ap']return false
end
end)end
n:unload("tod")return t
end
local function w(o,t,e)local n
local e={}for l,o in s(o)do
n=t:get("tod",o,"ap")if n then
e[#e+1]=n
end
end
t:unload("tod")return e
end
local function _(t,n,o)local e={}t:foreach(n,o,function(n)e[#e+1]=n['.name']end)t:unload(n)return e
end
local function p(d,a,i,c,h,r,e)local n,l
local o
e:debug("execute_operation: "..d)for t,s in s(i)do
if type(s)~="boolean"then
e:debug(i['.name'].."."..t.."="..s)end
if b(t)then
l=r:get("wireless",a,t)if l then
if h then
o=a.."_"..c.."_orig_"..t
else
o=c.."_orig_"..t
end
e:debug(t.." is an option to operate, operate_option is "..o)if d=="backup_and_set"then
n=s
e:debug(d.." option to set "..(n or"NONE"))r:set("tod",i['.name'],o,l)elseif d=="remove_and_restore"then
n=i[o]e:debug(d.." option to set "..(n or"NONE"))if not n then
e:debug("Missing orig state, inverting ap state in config")local t=i["state"]if not t then
e:error("Invalid config. Aborting.")return true
end
if t=="1"then
n="0"elseif t=="0"then
n="1"end
else
r:set("tod",i['.name'],o,"")end
else
e:debug("operation is not expected, do nothing")return true
end
if n=="0"then
e:debug("wifi_OFF due to scheduling")u:send("wifitod",{event="wifi_off_tod_scheduler_start"})else
e:debug("wifitod schedule period ends")u:send("wifitod",{event="wifi_tod_scheduler_stop"})end
if l~=n then
e:debug("values differ between wireless and to_operate: "..l.." and "..n)r:set("wireless",a,t,n)if t=="state"then
local o="radio_2G"local e=r:get("wireless",a,"iface")if string.match(e,"wl1")then
o="radio_5G"end
r:set("wireless",e,t,n)end
f=true
else
e:debug("values are the same between wireless and to_operate: "..l)end
else
e:notice(t.." does NOT exist in wireless."..a)end
end
end
return true
end
local function h(r,e,o,d)local n=e.logger
local e=e.uci
local e=e.cursor()n:debug("enter call_operation: "..r.." "..o.." on "..d)local i
if r=="start"then
i="backup_and_set"elseif r=="stop"then
i="remove_and_restore"else
return true
end
local l=m(d,e,n)if not l then
n:warning("there is no ap instance to operate")return true
end
local t=w(l,e,n)if#t==0 then
n:warning("there is no ap to operate")return true
end
local a=_(e,"wireless","wifi-ap")if#a==0 then
n:warning("there is no ap in wireless")return true
end
f=false
if g("all",t)then
local t=true
n:debug("'all' is in aps_to_operate")local l=e:get_all("tod",l[1])for a,r in s(a)do
p(i,r,l,o,t,e,n)end
else
local d=false
local t,r
for s,l in s(l)do
t=e:get("tod",l,"ap")if t and g(t,a)then
r=e:get_all("tod",l)p(i,t,r,o,d,e,n)end
end
end
e:commit("tod")e:commit("wireless")e:unload("tod")e:unload("wireless")if f then
n:debug("reload wireless")os.execute("/etc/init.d/hostapd reload")os.execute("/etc/init.d/network reload")end
n:debug("exit call_operation: "..r.." "..o.." on "..d)return true
end
function c.start(e,t,n)u=e.ubus
u:send("wifitod",{event="wifitod_started"})h("start",e,t,n)return true
end
function c.stop(e,t,n)u=e.ubus
h("stop",e,t,n)return true
end
return c